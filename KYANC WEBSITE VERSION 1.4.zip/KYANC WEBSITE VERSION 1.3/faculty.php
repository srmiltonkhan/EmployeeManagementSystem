<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
    <div class="text-center mt-4 w-90 mx-auto">
      <h4>Faculty Members</h4>
       <hr class="w-75 mx-auto">
    </div>
    <div class="row w-90 mx-auto">
      <?php 
    $query = "SELECT * FROM facultystaff WHERE type = 'Faculty' and id_status = 'active' ORDER BY serial_number ASC"; 
    $stat = $pdo_conn->prepare($query);
    $stat->execute();
    $rowCount = $stat->rowCount();

    $facultyMember = '';
      if($rowCount > 0){
        foreach ($stat->fetchAll() as $row) {
          $facultyMember .= '<div class="col-lg-3">
        <div class="facultyMem border mb-4">
          <div class="facMImg">
            <img src="admin/Files/WebContentsFiles/'.$row['file'].'">
          </div>
          <div class="facMName mr-2">
            <p class="text-right"><a href="faculty_details.php?id='.$row['id'].'" class="text-dark" title="Please, Click to see details.">'.$row['name'].'</a></p>
            <smal style="float:right;">'.$row['designation'].'</smal>
          </div>
          <div class="memInfo p-3 border-top">
            <br>
            <div style="display: flex;" class="mb-1">          
            <div class="fltyicon border text-center"><i class="fas fa-graduation-cap center text-primary"></i></div><div class="qlyTitle" style="flex-grow: 1"><p>'.$row['qualification'].'</p></div>
          </div>

            <div style="display: flex;" class="mb-1">          
            <div class="fltyicon border text-center"><i class="fas fa-mobile-alt center text-info"></i></div><div class="qlyTitle" style="flex-grow: 1"><p>'.$row['mobile'].'</p></div>
          </div>

            <div style="display: flex;">          
            <div class="fltyicon border text-center"><i class="fas fa-envelope text-success"></i></div><div class="qlyTitle" style="flex-grow: 1"><p>'.$row['email'].'</p></div>
            </div> 
<br>
            <div style="display: flex;" class="socailIcon">          
              <a href="'.$row['website'].'" target="_blank"><div class="socailIcon border text-center mr-2"><i class="fas fa-globe-asia text-success"></i></div></a>
              <a href="'.$row['linkedin'].'" target="_blank"><div class="socailIcon border text-center mr-2"><i class="fab fa-linkedin-in text-info"></i></div></a>
              <a href="'.$row['facebook'].'" target="_blank"><div class="socailIcon border text-center mr-2"><i class="fab fa-facebook text-primary"></i></div></a>
              <a href="'.$row['youtube'].'" target="_blank"><div class="socailIcon border text-center mr-2"><i class="fab fa-youtube-square text-danger"></i></div></a>
              <a href="'.$row['twitter'].'" target="_blank"><div class="socailIcon border text-center mr-2"><i class="fab fa-twitter-square text-primary"></i></div></a>
            </div> 

          </div>
        </div>
      </div>';
        }
      }else{
        echo "There is no record!";
      }
        echo $facultyMember;
      ?>    

    </div>
<?php $webContentsClass->footerSection();?>