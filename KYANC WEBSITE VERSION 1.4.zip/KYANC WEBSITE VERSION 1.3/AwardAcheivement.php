<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
  <div class="text-center mt-4">
    <h4>Awards & Acheivement</h4>
   <hr>
  </div>
  <?php
$query = "SELECT * FROM awprojectjournal WHERE type = 'AwardAchievement' and id_status = 'active' ORDER BY serial_number ASC";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$award = '';
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
    $award .='<tr>'.     
                '<td><a href="award_acheivement_detail.php?id='.$row['id'].'" class="text-dark" title="Please, Click for details">'.$row['title'].'</a></td>'.
                '<td><img src="admin/Files/WebContentsFiles/'.$row['file'].'" width="200" class="mx-auto d-block"></td>'.
                '<td>'.$row['details'].'</td>'.
                '<td>'.$row['award_date'].'</td>'
              .'</tr>';
   }  
 }   
$awardRslt =  $award;
?>
  <div class="table-responsive">
    <table class="table table-sm table-bordered">
      <thead>
        <th width="20%">Awards & Acheivement</th>
        <th width="20%">Photos</th>
        <th width="50%">Description</th>
        <th width="10%">Date</th>
      </thead>
    <body>
      <?php echo $awardRslt;?>
    </body>
  </table>
  </div>
<?php $webContentsClass->footerSection();?>