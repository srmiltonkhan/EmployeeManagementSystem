<!-- Side Navbar Items Includes -->
<?php require 'side_nav_item_and_brand_name.php';?>
<?php $html_and_head_section = "
<!DOCTYPE html>
<html lang='en'>
<head>
    <title>KYANC WEB ADMIN</title>
    <link rel='shortcut icon' href='Files/favicon/kyanc.ico'>
    <meta charset='utf-16'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' href='vendor/bootstrap/css/bootstrap.min.css'>
    <link rel='stylesheet' href='css/dataTables.bootstrap4.min.css'>
    <link href='vendor/fontawesome/css/font-awesome.min.css' rel='stylesheet'> 
    <link href='vendor/fontawesome/css/all.css' rel='stylesheet'>
    <link rel='stylesheet' href='css/style.default.css' id='theme-stylesheet'>
    <script src='vendor/jquery/jquery.min.js'></script>
</head>
";
?>
<?php $body_and_header_section_start = "
<body>
      <div class='page'>
      <header class='header fixed-top'>
        <nav class='navbar'>      
          <div class='container-fluid'> 
            <div class='row navbar-holder d-flex align-items-center justify-content-between'> 
                <div class='navbar-header col-3'>
                    <a href='../index.php' class='navbar-brand d-none d-sm-inline-block'>
                      <div class=' pl-5 brand-text d-none d-lg-inline-block'><span>$brand_name</span></div>
                    </a>
                    <div class='pl-5 d-lg-inline-block'>
                    <a id='toggle-btn' href='#' class='menu-btn active'><span></span><span></span><span></span></a>
                    </div>
                </div>
                <div class='col-7'>
                    <marquee>$header_mqrquee_title</marquee>
                </div>
                ";?>
            <?php $body_and_header_section_end="
            </div>
          </div>
        </nav>
      </header>
      ";
      ?>
      <!-- Side Navbar Section -->
      <?php 
      $side_nabar_and_content_inner_section = "
      <div class='page-content d-flex align-items-stretch page-margin'>

        <nav class='side-navbar'>
          <ul class='list-unstyled'>
            <li><a href='dashboard.php'><i class='fas fa-tachometer-alt fa-lg'></i></i>$dashboard</a></li>
            <li><a href='#misDropdownItem' aria-expanded='false' data-toggle='collapse'><i class='fas fa-laptop fa-lg'></i>$mis</a>
              <ul id='misDropdownItem' class='collapse list-unstyled'>
                <li><a href='#'><i class='fas fa-warehouse fa-lg'></i>$student_report</a></li>
                <li><a href='#'><i class='fas fa-warehouse fa-lg'></i>$student_report2</a></li>
              </ul>
            </li>
            <li><a href='#'>$nav3</a></li>
            <li title='All Carousel, Notice, News Management'><a href='homePage.php'>$nav4</a></li>
            <li title='File Management'><a href='file_mgt.php'>$nav5</a></li>
            <li title='Authorithy Message'><a href='authority.php'>$nav6</a></li>
            <li title='Governing Body'><a href='governing_body.php'>$nav7</a></li>
            <li title='Award,Acheivement,Project and Journal'><a href='awardProjectJournal.php'>$nav8</a></li>
            <li title='Faculty & Staff'><a href='faculty_staff.php'>$nav9</a></li>
            <li title='Manage Subject'><a href='subject.php'>$nav10</a></li>
            <li title='Manage E-Recruitment'><a href='recruitment.php'>$nav11</a></li>
            <li title='Manage Gallery'><a href='gallery.php'>$nav12</a></li>
            <li title='Manage Contents'><a href='contents.php'>$nav13</a></li>          
            ";
           if(isset( $_SESSION['type'] ) && ( $_SESSION['type'] == "Registrar")) {
            $side_nabar_and_content_inner_section .= " 

            ";
            }
           if(isset( $_SESSION['type'] ) && ( $_SESSION['type'] == "super_admin")) {
            $side_nabar_and_content_inner_section .= " 
            <li><a href='user_control.php'> <i class='fa fa-user-lock fa-lg'></i></i>$user_control</a></li>";
            }
            $side_nabar_and_content_inner_section .="
          </ul>
        </nav>
    
        <div class='content-inner'>
              ";?>
          <!-- Start Page Footer Section-->
  <?php $end_page_sidenav_content_footer_section = "
          <footer class='main-footer'>
            <div class='container-fluid'>
              <div class='row'>
                <div class='col-sm-6'>
                  <p>$footer_policy_name</p>
                </div>
                <div class='col-sm-6 text-right'>
                  <p>DESIGN AND DEVELOPED BY <a href='https://sites.google.com/view/miltonkhan' class='external'>$developer_and_designer_name</a></p>
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
  ";?>
 <!-- JavaScript files-->
 <!-- jQuery library -->
 <?php $end_body_html_and_java_script_section = "
    <script src='js/jquery.dataTables.min.js'></script> 
    <script src='js/dataTables.bootstrap4.min.js'></script> 
    <script src='vendor/popper.js/popper.min.js'></script>
    <script src='vendor/bootstrap/js/bootstrap.min.js'></script>
  
    <script src='js/custom.js'></script>
    </body>
</html>
  ";?>
<?php

  