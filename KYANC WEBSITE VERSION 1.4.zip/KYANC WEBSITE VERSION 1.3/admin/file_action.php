<?php
	include 'db_config.php';
	session_start();
	include 'function.php';
	$table="file_mgt";
	$published_date="";
	if (isset($_POST['action_hidden'])) {
		if ($_POST['action_hidden'] == 'Add') {
				$file = '';
					if($_FILES["file"]["name"] != ''){
					$file = upload_file();
				}
				$query = "INSERT INTO `$table`(`user_id`, `course_id`, `type`, `title`,`batch`,`semester`,`file`,`link`,`year`,`duration`,`num_of_seat`,`session_start`,`published_date`,`posting_date`) VALUES (:user_id,:course_id,:type,:title,:batch,:semester,:file,:link,:year,:duration,:num_of_seat,:session_start,:published_date,:posting_date)";
				$statement = $pdo_conn->prepare($query);
				$result = $statement->execute(
					array(
	            ':user_id' => $_SESSION["user_id"],
	            ':course_id' => $_POST["course_id"],
	            ':type' => $_POST["type"],
	            ':title' => $_POST["title"],
 				':batch' => $_POST["batch"],
	            ':semester' => $_POST["semester"],
	            ':file' => $file,
	            ':link' => $_POST["link"],
	            ':year' => $_POST["year"],
	            ':duration' => $_POST["duration"],
	            ':num_of_seat' => $_POST["num_of_seat"],
	            ':session_start' => $_POST["session_start"],
	            ':published_date' => $_POST["published_date"],
	            ':posting_date' => posting_date()
				));
				$result = $statement->fetchAll();
				if (isset($result)) {
					echo "Data has been saved successfully.";
				}
	     	}	
		}
		//Fetch Data from DB in Modal
		if ($_POST['action_hidden']=='fetch_single') {
			$query = "SELECT * FROM `$table` WHERE id = :id LIMIT 1";
			$statement = $pdo_conn->prepare($query);
			$statement->execute(
				array(':id' => $_POST['id'])
			);
			$result = $statement->fetchAll();
			foreach ($result as $row) {
				$output['type'] = $row['type'];
				$output['course_id'] = $row['course_id'];
				$output['title'] = $row['title'];
				$output['batch'] = $row['batch'];
				$output['semester'] = $row['semester'];
				if($row["file"] != ''){
						$output['file'] = '<img src="Files/WebContentsFiles/'.$row["file"].'" class="img-thumbnail" width="50" height="35" /><input type="hidden" name="hidden_image" value="'.$row["file"].'" />';
					}
				$output['link'] = $row['link'];		
				$output['year'] = $row['year'];		
				$output['duration'] = $row['duration'];		
				$output['num_of_seat'] = $row['num_of_seat'];		
				$output['session_start'] = $row['session_start'];		
				$output['published_date'] = $row['published_date'];		
			}
			echo json_encode($output);
		}
   		// Update Section Action
      if ($_POST['action_hidden'] == 'Edit') {
      		$upload_file =''; 
      		$file_row = get_file($pdo_conn,$_POST["id"],$table);
     		if($_FILES["file"]["name"] != '' && $file_row == ''){
     			$upload_file = upload_file();
     		}else if($_FILES["file"]["name"] == '' && $file_row != ''){
     			$upload_file = $file_row;
     		}else if($_FILES["file"]["name"] != '' && $file_row != ''){
     			unlink("Files/WebContentsFiles/" . $file_row);
     			$upload_file = upload_file();
     		}else{
     			$upload_file = $file_row;
     		}

      $query = "UPDATE `$table` SET `user_id`=:user_id,`course_id`=:course_id,`type`=:type,`title`=:title,`batch`=:batch,`semester`=:semester,`file`=:file,`link`=:link,`year`=:year,`duration`=:duration,`num_of_seat`=:num_of_seat,`session_start`=:session_start,`published_date`=:published_date,`posting_date`=:posting_date WHERE `id`=:id";
      $statement = $pdo_conn->prepare($query);
      $statement->execute(
         array(
			':id' => $_POST['id'],
			':user_id' => $_SESSION["user_id"],
			':course_id' => $_POST["course_id"],
			':type' => $_POST["type"],
			':title' => $_POST["title"],
			':batch' => $_POST["batch"],
			':semester' => $_POST["semester"],
			':file' => $upload_file,
			':link' => $_POST["link"],
			':year' => $_POST["year"],
			':duration' => $_POST["duration"],
			':num_of_seat' => $_POST["num_of_seat"],
			':session_start' => $_POST["session_start"],
			':published_date' => $_POST["published_date"],
			':posting_date' => posting_date()
       ));
      		$result = $statement->fetchAll();
      		if (isset($result)) {
        		echo "Data has been edited.";
      		}
    	}
  // Change Status Data from DB
    if ($_POST['action_hidden']=='active_inactive') {
      $row_status = 'active';
      if ($_POST['row_status']=='active') {
        $row_status = 'inactive';
      }
      $query = "UPDATE $table SET row_status = :row_status WHERE id = :id";
      $statement = $pdo_conn->prepare($query);
      $statement->execute(
         array(
          ':row_status' => $row_status,
          ':id'  => $_POST['id']
         )
        );
      $result = $statement->fetchAll();
      if ($row_status == 'active') {
      	$status_result = '<span class="badge badge-success">Actived</span>';
      }else{
      	$status_result = '<span class="badge badge-danger">Inactived</span>';
      }
      if(isset($result)){
        echo 'Item Status has been '.$status_result;
      }
    } 
    		// Delete Section Action
	if($_POST["action_hidden"] == 'delete'){
		$file = get_file($pdo_conn,$_POST["id"],$table);
		if($file != '')
		{
			unlink("Files/WebContentsFiles/" . $file);
		}		
		$query = "DELETE FROM $table WHERE id = :id";	
		 $statement = $pdo_conn->prepare($query);
		 $result = $statement->execute(
		  array(
		   ':id' => $_POST["id"]
		  ));
		 	if (isset($result)) {
				echo "Data has been deleted.";
			}
	   }

?>		