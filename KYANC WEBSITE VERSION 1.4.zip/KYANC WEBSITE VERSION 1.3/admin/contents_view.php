<?php
 include 'db_config.php';
if($_POST['btn_action'] == 'btn_view'){
		$query = "SELECT * FROM `contents` INNER JOIN users ON users.user_id = contents.user_id WHERE id  = '".$_POST["id"]."'";
        $statement = $pdo_conn->prepare($query);
        $statement->execute();
        $result = $statement->fetchAll();
        $output = '';
         foreach($result as $row){
           $id_status = '';
          if($row['id_status'] == 'active'){
            $id_status = '<h2><span class="badge badge-success">Active</span></h2>';
           }else{
            $id_status = '<h2><span class="badge badge-danger">Inactive</span</h2>';
          } 
         $web_file_nam = '';
        if ($row['file'] !='') {
          $web_file_nam = '<img src="Files/WebContentsFiles/'.$row["file"].'" alt="'.$row["file"].'" class="thumbnail" width="100" height="100" />';
        }else{
          $web_file_nam = '';
        }                   
         	$output .='
         	<div class="table-responsive">
         		<table class="table table-bordered table-sm">               
                    <tr>
                        <td>Authority Type</td>
                        <td>'.$row['type'].'</td>
                    </tr> 
                     <tr>
                        <td>Content Title</td>
                        <td>'.$row['content_title'].'</td>
                    </tr>    
                     <tr>
                        <td>Contents</td>
                        <td>'.$row['content'].'</td>
                    </tr>             
                     <tr>
                        <td>Background Image</td>
                        <td>'.$web_file_nam.'</td>
                    </tr> 
                    <tr>
                        <td>Status</td>
                        <td>'.$row['id_status'].'</td>
                    </tr>                                                                                                
                     <tr>
                        <td>Date</td>
                        <td>'.$row['posting_date'].'</td>
                    </tr>                      
                    <tr>
                        <td>Entered By</td>
                        <td>'.$row['user_name'].'</td>
                    </tr>                                                                                                                                                                   		
                 </table>
         	</div>	
         	';
         }
         echo $output;
    }; 

 
?>