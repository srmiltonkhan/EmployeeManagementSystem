<?php 
//Date Function
function posting_date(){
	date_default_timezone_set('Asia/Dhaka');
	$currentDateTime=date('m/d/Y H:i:s');
	$posting_date = date("h:i:s A, d-M-Y", strtotime($currentDateTime));	
	return $posting_date;
}	
function upload_file(){
	if(isset($_FILES["file"])){
		// $bner_img_tle = $_POST["bner_img_tle"];
		$cur_date = date('Ymdhis');
		$extension = explode('.', $_FILES['file']['name']);
		$new_name = $cur_date . '.' . $extension[1];// extension 1 means after file name . file extention like .jpg
		$destination = './Files/WebContentsFiles/' . $new_name;
		move_uploaded_file($_FILES['file']['tmp_name'], $destination);
		return $new_name;
	}
}
function upload_user_img(){
	if(isset($_FILES["user_image"])){
		// $bner_img_tle = $_POST["bner_img_tle"];
		$cur_date = date('Ymdhis');
		$extension = explode('.', $_FILES['user_image']['name']);
		$new_name = $cur_date . '.' . $extension[1];// extension 1 means after file name . file extention like .jpg
		$destination = './Files/WebContentsFiles/' . $new_name;
		move_uploaded_file($_FILES['user_image']['tmp_name'], $destination);
		return $new_name;
	}
}
function get_file($pdo_conn,$id,$table){  // get banner image 
	$statement = $pdo_conn->prepare("SELECT file FROM $table WHERE id = '$id'");
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row){
		return $row["file"];
	}
}
function get_user_img($pdo_conn,$id,$table){
	$statement = $pdo_conn->prepare("SELECT user_image FROM $table WHERE user_id = '$id'");
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row){
		return $row["user_image"];
	}
}
function get_name_list($pdo_conn){
	$query = "SELECT * FROM `courses` ORDER BY course_id ASC";
	$statement = $pdo_conn->prepare($query);
	$statement->execute();
	$output .= '<option value="" selected="selected">Please Select Course Name</option>';
	foreach($statement->fetchAll() as $row){
		 
		 $output .= '<option value="'.$row["course_id"].'">'.$row["course_name"].'</option>';
	}
	return $output;
}	
?>


