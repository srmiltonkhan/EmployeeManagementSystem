<?php
	include 'db_config.php';
		session_start();
		require_once("function.php");	
$table = "awprojectjournal";
	if (isset($_POST['action_hidden'])) {
		if ($_POST['action_hidden'] == 'Add') {
			//This function will included within Add section
				$file = '';
					if($_FILES["file"]["name"] != ''){
					$file = upload_file();
				}
			
				$query = "INSERT INTO `$table`(`user_id`, `type`,`serial_number`,`title`, `details`, `file`, `link`,`award_date`,`posting_date`) VALUES (:user_id,:type,:serial_number,:title,:details,:file,:link,:award_date,:posting_date)";
				$statement = $pdo_conn->prepare($query);
				$result = $statement->execute(
					array(
	            ':user_id' => $_SESSION["user_id"],
	            ':type' => $_POST["type"],
	            ':serial_number' => $_POST["serial_number"],
	            ':title' => $_POST["title"],
	            ':details' => $_POST["details"],
	            ':file' => $file,
	            ':link' => $_POST["link"],
	            ':award_date' => $_POST["award_date"],
	            ':posting_date' => posting_date()
				));
				$result = $statement->fetchAll();
				if (isset($result)) {
					echo "Data has been saved successfully.";
				}
	     	}	
		}
		//Fetch Data from DB in Modal
		if ($_POST['action_hidden']=='fetch_single') {
			$query = "SELECT * FROM `$table` WHERE id = :id LIMIT 1";
			$statement = $pdo_conn->prepare($query);
			$statement->execute(
				array(':id' => $_POST['id'])
			);
			$result = $statement->fetchAll();
			foreach ($result as $row) {
				$output['type'] = $row['type'];
				$output['serial_number'] = $row['serial_number'];
				$output['title'] = $row['title'];
				$output['details'] = $row['details'];
				if($row["file"] != ''){
					$output['file'] = '<img src="Files/WebContentsFiles/'.$row["file"].'" class="img-thumbnail" width="50" height="35" /><input type="hidden" name="hidden_image" value="'.$row["file"].'" />';
				}
				$output['link'] = $row['link'];
				$output['award_date'] = $row['award_date'];
			}
			echo json_encode($output);
		}

		   		// Update Section Action
      if ($_POST['action_hidden'] == 'Edit') {
      		$upload_file ='';
      		$file_hidden = '';
      		$file_row = get_file($pdo_conn,$_POST["id"],$table);
     		if($_FILES["file"]["name"] != '' && $file_row == ''){
     			$upload_file = upload_file();
     		}else if($_FILES["file"]["name"] == '' && $file_row != ''){
     			$upload_file = $file_row;
     		}else if($_FILES["file"]["name"] != '' && $file_row != ''){
     			unlink("Files/WebContentsFiles/" . $file_row);
     			$upload_file = upload_file();
     		}else{
     			$upload_file = $file_row;
     		}

      $query = "UPDATE `$table` SET `user_id`=:user_id,`type`=:type,`serial_number`=:serial_number,`title`=:title,`details`=:details,`file`=:file,`link`=:link,`award_date`=:award_date,`posting_date`=:posting_date WHERE `id`=:id";
      $statement = $pdo_conn->prepare($query);
      $statement->execute(
         array(
          ':id' => $_POST['id'],
	      ':user_id' => $_SESSION["user_id"],
	      ':type' => $_POST['type'],
	      ':serial_number' => $_POST['serial_number'],
	      ':title' => $_POST['title'],
	      ':details' => $_POST['details'],
          ':file' => $upload_file,
          ':link' => $_POST['link'],
          ':award_date' => $_POST['award_date'],
	      ':posting_date' => posting_date()
       ));
      		$result = $statement->fetchAll();
      		if (isset($result)) {
        		echo "Data has been edited.";
      		}
    	}

    	// Change Status Data from DB
    if ($_POST['action_hidden']=='active_inactive') {
      $status = 'active';
      if ($_POST['id_status']=='active') {
        $status = 'inactive';
      }
      $query = "UPDATE $table SET id_status = :id_status WHERE id = :id";
      $statement = $pdo_conn->prepare($query);
      $statement->execute(
         array(
          ':id_status' => $status,
          ':id'  => $_POST['id']
         )
        );
      $result = $statement->fetchAll();
      if ($status == 'active') {
      	$status_result = '<span class="badge badge-success">Actived</span>';
      }else{
      	$status_result = '<span class="badge badge-danger">Inactived</span>';
      }
      if(isset($result)){
        echo 'Item Status has been '.$status_result;
      }
    } 
    		// Delete Section Action
	if($_POST["action_hidden"] == 'delete'){
		$snfilename = get_file($pdo_conn,$_POST["id"],$table);
		if($snfilename != '')
		{
			unlink("Files/WebContentsFiles/" . $snfilename);
		}		
		$query = "DELETE FROM $table WHERE id = :id";	
		 $statement = $pdo_conn->prepare($query);
		 $result = $statement->execute(
		  array(
		   ':id' => $_POST["id"]
		  ));
		 	if (isset($result)) {
				echo "Data has been deleted.";
			}
	   }

	?>