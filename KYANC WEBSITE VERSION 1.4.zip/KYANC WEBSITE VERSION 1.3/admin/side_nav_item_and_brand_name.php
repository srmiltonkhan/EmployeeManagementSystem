<?php
    // Brand Name
    $brand_name = "<img style = 'margin-left: 20px;' src='Files/user_image/KyancLogo.png' width = '35' height= '35'> <span style = 'font-weight: bold;  margin-left: 10px;letter-spacing: 5px;'>KYANC</span>";
    // Header Marquee Title
    $header_mqrquee_title = "WELCOME TO KHWAJA YUNUS ALI NURSING COLLEGE ADMIN PANEL";
    // Side Navbar Items Name
    $dashboard = "Dashboard";
    $mis = "MIS";
        $student_report = "Student Report";
        $student_report2 = "Student Report2";
    $nav3 = "<i class='fas fa-user-md fa-lg'></i> Teacher";
    $nav4 = "<i class='fas fa-flag fa-lg'></i> Home Page";
    $nav5 = "<i class='fas fa-file fa-lg'></i> Manage File";
    $nav6 = "<i class='fas fa-spa fa-lg'></i> Authority Message";
    $nav7 = "<i class='fas fa-user-friends fa-lg'></i> Governing Body";
    $nav8 = "<i class='fas fa-award fa-lg'></i> Award,Project & Journal";
    $nav9 = "<i class='fas fa-chalkboard-teacher fa-lg'></i> Faculty & Staff";
    $nav10 = "<i class='fas fa-book fa-lg'></i> Manage Subject";
    $nav11 = "<i class='fas fa-briefcase fa-lg'></i> Manage E-Rcruitment";
    $nav12 = "<i class='fas fa-image fa-lg'></i> Gallery";
    $nav13 = "<i class='fas fa-newspaper fa-lg'></i> Manage Contents";
    $user_control = "User Control";
    // Footer Policy Name
    $footer_policy_name = "Copyright &copy "."2005"."-".Date("Y")." All Rights Reserved by KYANC";
    // Developer & Designer Name
    $developer_and_designer_name = "KYAU IT DEPARTMENT";
?>

