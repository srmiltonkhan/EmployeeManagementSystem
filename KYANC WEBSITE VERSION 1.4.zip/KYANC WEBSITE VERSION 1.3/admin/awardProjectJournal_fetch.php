<?php
include 'db_config.php';
$table="";
$table .="awprojectjournal";
$column = array('awprojectjournal.id ');
$query = "SELECT * FROM `$table`";
if(isset($_POST['search']['value'])){
 $query .= '
 WHERE awprojectjournal.id LIKE "%'.$_POST["search"]["value"].'%"    
 OR awprojectjournal.type LIKE "%'.$_POST["search"]["value"].'%"     
 OR awprojectjournal.title LIKE "%'.$_POST["search"]["value"].'%"     
 OR awprojectjournal.posting_date LIKE "%'.$_POST["search"]["value"].'%"     
 ';
}
if(isset($_POST['order'])){
 $query .= 'ORDER BY '.$column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
}
else{
 $query .= 'ORDER BY awprojectjournal.id DESC';
}
$query1 = '';
if($_POST['length'] != -1){
 $query1 = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}
$statement = $pdo_conn->prepare($query);
$statement->execute();
$number_filter_row = $statement->rowCount();
$statement = $pdo_conn->prepare($query . $query1);
$statement->execute();
$result = $statement->fetchAll();
$data = array();
foreach($result as $row){	

$file = '';
if ($row['file'] !='') {
	$file_name = $row['file'];
	$temp = explode('.', $file_name);
	$extension = end($temp);
	if ($extension == 'pdf') {
		$file= '<a href="Files/WebContentsFiles/'.$row['file'].'" target="_blank" title="click to download"> <i class="fas fa-file-pdf"></i></a>';
	}else{
		$file = '<img src="Files/WebContentsFiles/'.$row["file"].'" class="rounded-circle" width="50" height="50" />';
	}


}else{
	$file = '';
}

$id_status = '';
 if($row['id_status'] == 'active'){
  $id_status = '<span class="badge badge-success">Active</span>';
 }else{
  $id_status = '<span class="badge badge-danger">Inactive</span>';
 }			
$sub_array = array();
$sub_array[] = $row['id'];
$sub_array[] = $row['serial_number'];
$sub_array[] = $row['type'];
$sub_array[] = $row['title'];
 $sub_array[] ='<div class="text-center">'.$file.'</div>';
 $sub_array[] ='<div class="text-center">'.$id_status.'</div>';
$sub_array[] = $row['posting_date'];
 $sub_array[] = '<div class="text-center"><button type="button" name="view" id="'.$row["id"].'" class="btn btn-info btn-sm view mr-2"><i class="fas fa-eye"></i></button>'.'<button type="button" name="update" id="'.$row["id"].'" class="btn btn-primary btn-sm update mr-2"><i class="fas fa-edit"></i></button>'.'<button type="button" name="active_inactive_btn" id="'.$row["id"].'" class="btn btn-info btn-sm btn_active_inactive" data-status="'.$row["id_status"].'"><i class="fas fa-check-circle"></i></button>'.'<button type="button" name="delete" id="'.$row["id"].'" class="btn btn-danger btn-sm delete ml-2"><i class="fas fa-trash"></i></button></div>';
 $data[] = $sub_array;
}
function count_all_data($pdo_conn){
 $query = "SELECT * FROM awprojectjournal";
 $statement = $pdo_conn->prepare($query);
 $statement->execute();
 return $statement->rowCount();
}
$output = array(
 'draw'    => intval($_POST['draw']),
 'recordsTotal'  => count_all_data($pdo_conn),
 'recordsFiltered' => $number_filter_row,
 'data'    => $data
);
echo json_encode($output);
?>