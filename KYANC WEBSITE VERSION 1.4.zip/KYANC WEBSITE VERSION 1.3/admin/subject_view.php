<?php
 include 'db_config.php';
if($_POST['btn_action'] == 'btn_view'){
		$query = "SELECT * FROM `subjects` 
        INNER JOIN users ON users.user_id = subjects.user_id 
        INNER JOIN courses ON courses.course_id = subjects.course_id  
        WHERE id  = '".$_POST["id"]."'";
        $statement = $pdo_conn->prepare($query);
        $statement->execute();
        $result = $statement->fetchAll();
        $output = '';
         foreach($result as $row){
           $id_status = '';
          if($row['id_status'] == 'active'){
            $id_status = '<h2><span class="badge badge-success">Active</span></h2>';
           }else{
            $id_status = '<h2><span class="badge badge-danger">Inactive</span</h2>';
          }                   
         	$output .='
         	<div class="table-responsive">
         		<table class="table table-bordered table-sm">               
                    <tr>
                        <td>Serial Number</td>
                        <td>'.$row['serial_number'].'</td>
                    </tr>
                    <tr>
                        <td>Course Name</td>
                        <td>'.$row['course_name'].'</td>
                    </tr>
                    <tr>
                        <td>Year</td>
                        <td>'.$row['year_type'].'</td>
                    </tr>

                    <tr>
                        <td>Subject Code</td>
                        <td>'.$row['subject_code'].'</td>
                    </tr>
                    <tr>
                        <td>Subject Name</td>
                        <td>'.$row['subject_name'].'</td>
                    </tr>                                                                              
                     <tr>
                        <td>Status</td>
                        <td>'.$id_status.'</td>
                    </tr>                      
                    <tr>
                        <td>Entered By</td>
                        <td>'.$row['user_name'].'</td>
                    </tr>                                                                                                                                                                   		
                 </table>
         	</div>	
         	';
         }
         echo $output;
    }; 

 
?>