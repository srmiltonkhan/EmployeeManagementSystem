<?php
	include 'db_config.php';
	session_start();
	include 'function.php';
	$table="facultystaff";
	if (isset($_POST['action_hidden'])) {
		if ($_POST['action_hidden'] == 'Add') {

				$file = '';
					if($_FILES["file"]["name"] != ''){
					$file = upload_file();
				}

				$query = "INSERT INTO `$table`(`user_id`, `type`, `serial_number`, `mem_id_num`, `name`, `file`, `designation`, `mobile`, `email`, `qualification`, `short_biography`, `research_interest`, `research_and_publication`, `academic_info`, `experience`, `linkedin`, `website`, `twitter`, `facebook`, `youtube`, `gender`, `blood_group`, `nid`,`posting_date`) VALUES (:user_id,:type,:serial_number,:mem_id_num,:name,:file,:designation,:mobile,:email,:qualification,:short_biography,:research_interest,:research_and_publication,:academic_info,:experience,:linkedin,:website,:twitter,:facebook,:youtube,:gender,:blood_group,:nid,:posting_date)";
				$statement = $pdo_conn->prepare($query);
				$result = $statement->execute(
					array(
	            ':user_id' => $_SESSION["user_id"],
	            ':type' => $_POST["type"],
	            ':serial_number' => $_POST["serial_number"],
	            ':mem_id_num' => $_POST["mem_id_num"],
	            ':name' => $_POST["name"],
	            ':file' => $file,
	            ':designation' => $_POST["designation"],
	            ':mobile' => $_POST["mobile"],
	            ':email' => $_POST["email"],
	            ':qualification' => $_POST["qualification"],
	            ':short_biography' => $_POST["short_biography"],
	            ':research_interest' => $_POST["research_interest"],
	            ':research_and_publication' => $_POST["research_and_publication"],
	            ':academic_info' => $_POST["academic_info"],
	            ':experience' => $_POST["experience"],
	            ':linkedin' => $_POST["linkedin"],
	            ':website' => $_POST["website"],
	            ':twitter' => $_POST["twitter"],
	            ':facebook' => $_POST["facebook"],
	            ':youtube' => $_POST["youtube"],
	            ':gender' => $_POST["gender"],
	            ':blood_group' => $_POST["blood_group"],
	            ':nid' => $_POST["nid"],
	            ':posting_date' => posting_date()
				));
				$result = $statement->fetchAll();
				if (isset($result)) {
					echo "Data has been saved successfully.";
				}
	     	}	
		}

		//Fetch Data from DB in Modal
		if ($_POST['action_hidden']=='fetch_single') {
			$query = "SELECT * FROM `$table` WHERE id = :id LIMIT 1";
			$statement = $pdo_conn->prepare($query);
			$statement->execute(
				array(':id' => $_POST['id'])
			);
			$result = $statement->fetchAll();
			foreach ($result as $row) {
				$output['type'] = $row['type'];
				$output['serial_number'] = $row['serial_number'];
				$output['mem_id_num'] = $row['mem_id_num'];
				$output['name'] = $row['name'];
				if($row["file"] != ''){
					$output['file'] = '<img src="Files/WebContentsFiles/'.$row["file"].'" class="img-thumbnail" width="50" height="35" /><input type="hidden" name="hidden_image" value="'.$row["file"].'" />';
				}
				$output['designation'] = $row['designation'];
				$output['mobile'] = $row['mobile'];
				$output['email'] = $row['email'];
				$output['qualification'] = $row['qualification'];
				$output['short_biography'] = $row['short_biography'];
				$output['research_interest'] = $row['research_interest'];
				$output['research_and_publication'] = $row['research_and_publication'];
				$output['academic_info'] = $row['academic_info'];
				$output['experience'] = $row['experience'];
				$output['linkedin'] = $row['linkedin'];
				$output['website'] = $row['website'];
				$output['twitter'] = $row['twitter'];
				$output['facebook'] = $row['facebook'];
				$output['youtube'] = $row['youtube'];
				$output['gender'] = $row['gender'];
				$output['blood_group'] = $row['blood_group'];
				$output['nid'] = $row['nid'];
			}
			echo json_encode($output);
		}

		   		// Update Section Action
      if ($_POST['action_hidden'] == 'Edit') {
      		$upload_file ='';
      		$file_row = get_file($pdo_conn,$_POST["id"],$table);
     		if($_FILES["file"]["name"] != '' && $file_row == ''){
     			$upload_file = upload_file();
     		}else if($_FILES["file"]["name"] == '' && $file_row != ''){
     			$upload_file = $file_row;
     		}else if($_FILES["file"]["name"] != '' && $file_row != ''){
     			unlink("Files/WebContentsFiles/" . $file_row);
     			$upload_file = upload_file();
     		}else{
     			$upload_file = $file_row;
     		}

      $query = "UPDATE `$table` SET `user_id`=:user_id,`type`=:type,`serial_number`=:serial_number,`mem_id_num`=:mem_id_num,`name`=:name,`file`=:file,`designation`=:designation,`mobile`=:mobile,`email`=:email,`qualification`=:qualification,`short_biography`=:short_biography,`research_interest`=:research_interest,`research_and_publication`=:research_and_publication,`academic_info`=:academic_info,`experience`=:experience,`linkedin`=:linkedin,`website`=:website,`twitter`=:twitter,`facebook`=:facebook,`youtube`=:youtube,`gender`=:gender,`blood_group`=:blood_group,`nid`=:nid,`posting_date`=:posting_date WHERE `id`=:id";
      $statement = $pdo_conn->prepare($query);
      $statement->execute(
         array(
          ':id' => $_POST['id'],
	      ':user_id' => $_SESSION["user_id"],
	      ':type' => $_POST['type'],
	      ':serial_number' => $_POST['serial_number'],
	      ':mem_id_num' => $_POST['mem_id_num'],
	      ':name' => $_POST['name'],
          ':file' => $upload_file,
          ':designation' => $_POST['designation'],
          ':mobile' => $_POST['mobile'],
          ':email' => $_POST['email'],
          ':qualification' => $_POST['qualification'],
          ':short_biography' => $_POST['short_biography'],
          ':research_interest' => $_POST['research_interest'],
          ':research_and_publication' => $_POST['research_and_publication'],
          ':academic_info' => $_POST['academic_info'],
          ':experience' => $_POST['experience'],
          ':linkedin' => $_POST['linkedin'],
          ':website' => $_POST['website'],
          ':twitter' => $_POST['twitter'],
          ':facebook' => $_POST['facebook'],
          ':youtube' => $_POST['youtube'],
          ':gender' => $_POST['gender'],
          ':blood_group' => $_POST['blood_group'],
          ':nid' => $_POST['nid'],
	      ':posting_date' => posting_date()
       ));
      		$result = $statement->fetchAll();
      		if (isset($result)) {
        		echo "Data has been edited.";
      		}
    	}
  // Change Status Data from DB
    if ($_POST['action_hidden']=='active_inactive') {
      $status = 'active';
      if ($_POST['id_status']=='active') {
        $status = 'inactive';
      }
      $query = "UPDATE $table SET id_status = :id_status WHERE id = :id";
      $statement = $pdo_conn->prepare($query);
      $statement->execute(
         array(
          ':id_status' => $status,
          ':id'  => $_POST['id']
         )
        );
      $result = $statement->fetchAll();
      if ($status == 'active') {
      	$status_result = '<span class="badge badge-success">Actived</span>';
      }else{
      	$status_result = '<span class="badge badge-danger">Inactived</span>';
      }
      if(isset($result)){
        echo 'Item Status has been '.$status_result;
      }
    } 
    		// Delete Section Action
	if($_POST["action_hidden"] == 'delete'){
		$file_row = get_file($pdo_conn,$_POST["id"],$table);
		if($file_row != '')
		{
			unlink("Files/WebContentsFiles/" . $file_row);
		}		
		$query = "DELETE FROM $table WHERE id = :id";	
		 $statement = $pdo_conn->prepare($query);
		 $result = $statement->execute(
		  array(
		   ':id' => $_POST["id"]
		  ));
		 	if (isset($result)) {
				echo "Data has been deleted.";
			}
	   }

	?>