<?php
 include 'db_config.php';
if($_POST['btn_action'] == 'btn_view'){
		$query = "SELECT * FROM `users`  WHERE user_id  = '".$_POST["id"]."'";
        $statement = $pdo_conn->prepare($query);
        $statement->execute();
        $result = $statement->fetchAll();
        $output = '';
         foreach($result as $row){
           $id_status = '';
          if($row['user_status'] == 'active'){
            $id_status = '<h2><span class="badge badge-success">Active</span></h2>';
           }else{
            $id_status = '<h2><span class="badge badge-danger">Inactive</span</h2>';
          } 
         $file = '';
        if ($row['user_image'] !='') {
          $file = '<img src="Files/WebContentsFiles/'.$row["user_image"].'" alt="'.$row["user_image"].'" class="thumbnail" width="200" height="100" />';
        }else{
          $file = '';
        }                   
         	$output .='
         	<div class="table-responsive">
         		<table class="table table-bordered table-sm">   
                     <tr>
                        <td>ID Number</td>
                        <td>'.$row['user_id_num'].'</td>
                    </tr> 
                    <tr>
                        <td>Image</td>
                        <td>'.$file.'</td>
                    </tr>                                                
                    <tr>
                        <td>Name</td>
                        <td>'.$row['user_name'].'</td>
                    </tr> 
                    <tr>
                        <td>Email</td>
                        <td>'.$row['user_email'].'</td>
                    </tr>                                                                                              
                    <tr>
                        <td>Mobile</td>
                        <td>'.$row['user_mobile'].'</td>
                    </tr> 
                    <tr>
                        <td>Department</td>
                        <td>'.$row['user_department'].'</td>
                    </tr> 
                    <tr>
                        <td>Designation</td>
                        <td>'.$row['user_designation'].'</td>
                    </tr> 

                     <tr>
                        <td>User Password</td>
                        <td>'.$row['user_password'].'</td>
                    </tr>   

                    <tr>
                        <td>User Type</td>
                        <td>'.$row['user_type'].'</td>
                    </tr>  
                    <tr>
                        <td>User Status</td>
                        <td>'.$id_status.'</td>
                    </tr> 
                    <tr>
                        <td>Posting Date</td>
                        <td>'.$row['user_reg_date'].'</td>
                    </tr>  
                 </table>
         	</div>	
         	';
         }
         echo $output;
    }; 

 
?>

