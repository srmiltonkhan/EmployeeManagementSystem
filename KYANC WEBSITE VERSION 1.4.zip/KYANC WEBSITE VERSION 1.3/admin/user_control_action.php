<?php
	include 'db_config.php';
	session_start();
	include 'function.php';
	$table="users";
	if (isset($_POST['action_hidden'])) {
		if ($_POST['action_hidden'] == 'Add') {

			$user_email = $_POST['user_email'];
				$user_mobile = $_POST['user_mobile'];
				$finder_query = "SELECT * FROM $table WHERE user_email = '$user_email' OR user_mobile ='$user_mobile'";
				$statement = $pdo_conn->prepare($finder_query);
				$statement->execute();
				$row_count = $statement->fetch();
				if ($row_count > 0) {
				echo "Your Email: "."<span class = 'badge badge-warning'>".$_POST['user_email']."</span>"." and Mobile Number: "."<span class='badge badge-warning'>".$_POST['user_mobile']."</span>"." already exist.";	
				}else{
				$file = '';
					if($_FILES["user_image"]["name"] != ''){
					$file = upload_user_img();
				}
				$query = "INSERT INTO `$table`(`user_id_num`, `user_name`, `user_email`, `user_mobile`, `user_department`, `user_designation`, `user_password`, `user_type`,`user_image`,`user_reg_date`) VALUES (:user_id_num,:user_name,:user_email,:user_mobile,:user_department,:user_designation,:user_password,:user_type,:user_image,:user_reg_date)";
				$statement = $pdo_conn->prepare($query);
				$result = $statement->execute(
					array(
	            ':user_id_num' => $_POST["user_id_num"],
	            ':user_name' => $_POST["user_name"],
	            ':user_email' => $_POST["user_email"],
	            ':user_mobile' => $_POST["user_mobile"],
	            ':user_department' => $_POST["user_department"],
	            ':user_designation' => $_POST["user_designation"],
	            ':user_password' => password_hash($_POST["user_password"], PASSWORD_DEFAULT),
	            ':user_type' => $_POST["user_type"],
	            ':user_image' => $file,
	            ':user_reg_date' => posting_date()
				));
				$result = $statement->fetchAll();
				if (isset($result)) {
					echo "Data has been saved successfully.";
				}
			  }
	     	}	
		}

		//Fetch Data from DB in Modal
		if ($_POST['action_hidden']=='fetch_single') {
			$query = "SELECT * FROM `$table` WHERE user_id = :id LIMIT 1";
			$statement = $pdo_conn->prepare($query);
			$statement->execute(
				array(':id' => $_POST['id'])
			);
			$result = $statement->fetchAll();
			foreach ($result as $row) {
				$output['user_id_num'] = $row['user_id_num'];		
				$output['user_name'] = $row['user_name'];		
				$output['user_email'] = $row['user_email'];		
				$output['user_mobile'] = $row['user_mobile'];		
				$output['user_department'] = $row['user_department'];		
				$output['user_designation'] = $row['user_designation'];		
				$output['user_password'] = $row['user_password'];		
				$output['user_type'] = $row['user_type'];			
			}
			echo json_encode($output);
		}

   		// Update Section Action
      if ($_POST['action_hidden'] == 'Edit') {
      		$upload_file ='';
      		$file_row = get_user_img($pdo_conn,$_POST["id"],$table);
     		if($_FILES["user_image"]["name"] != '' && $file_row == ''){
     			$upload_file = upload_user_img();
     		}else if($_FILES["user_image"]["name"] == '' && $file_row != ''){
     			$upload_file = $file_row;
     		}else if($_FILES["user_image"]["name"] != '' && $file_row != ''){
     			unlink("Files/WebContentsFiles/" . $file_row);
     			$upload_file = upload_user_img();
     		}else{
     			$upload_file = $file_row;
     		}

      $query = "UPDATE `$table` SET `user_id_num`=:user_id_num,`user_name`=:user_name,`user_email`=:user_email,`user_mobile`=:user_mobile,`user_department`=:user_department,`user_designation`=:user_designation,`user_password`=:user_password,`user_type`=:user_type,`user_image`=:user_image,`user_reg_date`=:user_reg_date WHERE `user_id`=:user_id";
      $statement = $pdo_conn->prepare($query);
      $statement->execute(
         array(
          ':user_id' => $_POST['id'],
			':user_id_num' => $_POST["user_id_num"],
			':user_name' => $_POST["user_name"],
			':user_email' => $_POST["user_email"],
			':user_mobile' => $_POST["user_mobile"],
			':user_department' => $_POST["user_department"],
			':user_designation' => $_POST["user_designation"],
			':user_password' => password_hash($_POST["user_password"], PASSWORD_DEFAULT),
			':user_type' => $_POST["user_type"],
			':user_image' => $upload_file,
			':user_reg_date' => posting_date()
       ));
      		$result = $statement->fetchAll();
      		if (isset($result)) {
        		echo "Data has been edited.";
      		}
    	}
  // Change Status Data from DB
    if ($_POST['action_hidden']=='active_inactive') {
      $status = 'active';
      if ($_POST['id_status']=='active') {
        $status = 'inactive';
      }
      $query = "UPDATE $table SET user_status = :id_status WHERE user_id = :id";
      $statement = $pdo_conn->prepare($query);
      $statement->execute(
         array(
          ':id_status' => $status,
          ':id'  => $_POST['id']
         )
        );
      $result = $statement->fetchAll();
      if ($status == 'active') {
      	$status_result = '<span class="badge badge-success">Actived</span>';
      }else{
      	$status_result = '<span class="badge badge-danger">Inactived</span>';
      }
      if(isset($result)){
        echo 'Item Status has been '.$status_result;
      }
    }  


	?>