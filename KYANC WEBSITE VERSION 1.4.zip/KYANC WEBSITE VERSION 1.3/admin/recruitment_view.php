<?php
 include 'db_config.php';
if($_POST['btn_action'] == 'btn_view'){
		$query = "SELECT * FROM `erecruitement` INNER JOIN users ON users.user_id = erecruitement.user_id WHERE id  = '".$_POST["id"]."'";
        $statement = $pdo_conn->prepare($query);
        $statement->execute();
        $result = $statement->fetchAll();
        $output = '';
         foreach($result as $row){
           $id_status = '';
          if($row['id_status'] == 'active'){
            $id_status = '<h2><span class="badge badge-success">Active</span></h2>';
           }else{
            $id_status = '<h2><span class="badge badge-danger">Inactive</span</h2>';
          } 
$file = '';
if ($row['file'] !='') {
    $file_name = $row['file'];
    $temp = explode('.', $file_name);
    $extension = end($temp);
    if ($extension == 'pdf') {
        $file= '<a href="Files/WebContentsFiles/'.$row['file'].'" target="_blank" title="click to download"> <i class="fas fa-file-pdf"></i></a>';
    }else{
        $file = '<img src="Files/WebContentsFiles/'.$row["file"].'" class="rounded-circle" width="50" height="50" />';
    }
}else{
    $file = '';
}                  
         	$output .='
         	<div class="table-responsive">
         		<table class="table table-bordered table-sm">               
                    <tr>
                        <td>Job Id</td>
                        <td>'.$row['Job_id'].'</td>
                    </tr>
                     <tr>
                        <td>Position</td>
                        <td>'.$row['position'].'</td>
                    </tr>
                     <tr>
                        <td>Title</td>
                        <td>'.$row['title'].'</td>
                    </tr>
                      <tr>
                        <td>File</td>
                        <td>'.$file.'</td>
                    </tr>                   
                     <tr>
                        <td>Details</td>
                        <td>'.$row['details'].'</td>
                    </tr>
                     <tr>
                        <td>No. of Post</td>
                        <td>'.$row['num_of_post'].'</td>
                    </tr>
                      <tr>
                        <td>Age On Calculated</td>
                        <td>'.$row['age_cal_on'].'</td>
                    </tr>                                            
                    <tr>
                        <td>Academic Requirement</td>
                        <td>'.$row['academic_requirement'].'</td>
                    </tr>                                            
                    <tr>
                        <td>Deadline</td>
                        <td>'.$row['deadline'].'</td>
                    </tr>                                                                                                                                 
                     <tr>
                        <td>Status</td>
                        <td>'.$id_status.'</td>
                    </tr>                      
                    <tr>
                        <td>Entered By</td>
                        <td>'.$row['user_name'].'</td>
                    </tr>                                                                                                                                                                   		
                 </table>
         	</div>	
         	';
         }
         echo $output;
    }; 

 
?>