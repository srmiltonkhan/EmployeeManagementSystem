<?php
	include 'db_config.php';
	session_start();
	include 'function.php';
	$table="subjects";
	if (isset($_POST['action_hidden'])) {
		if ($_POST['action_hidden'] == 'Add') {

				$query = "INSERT INTO `$table`(`user_id`, `course_id`, `year_type`,`serial_number`,`subject_code`, `subject_name`,`posting_date`) VALUES (:user_id,:course_id,:year_type,:serial_number,:subject_code,:subject_name,:posting_date)";
				$statement = $pdo_conn->prepare($query);
				$result = $statement->execute(
					array(
	            ':user_id' => $_SESSION["user_id"],
	            ':course_id' => $_POST["course_id"],
	            ':year_type' => $_POST["year_type"],
	            ':serial_number' => $_POST["serial_number"],
	            ':subject_code' => $_POST["subject_code"],
	            ':subject_name' => $_POST["subject_name"],
	            ':posting_date' => posting_date()
				));
				$result = $statement->fetchAll();
				if (isset($result)) {
					echo "Data has been saved successfully.";
				}
	     	}	
		}

		//Fetch Data from DB in Modal
		if ($_POST['action_hidden']=='fetch_single') {
			$query = "SELECT * FROM `$table` WHERE id = :id LIMIT 1";
			$statement = $pdo_conn->prepare($query);
			$statement->execute(
				array(':id' => $_POST['id'])
			);
			$result = $statement->fetchAll();
			foreach ($result as $row) {
				$output['course_id'] = $row['course_id'];	
				$output['year_type'] = $row['year_type'];	
				$output['serial_number'] = $row['serial_number'];
				$output['subject_code'] = $row['subject_code'];
				$output['subject_name'] = $row['subject_name'];
			}
			echo json_encode($output);
		}

   		// Update Section Action
      if ($_POST['action_hidden'] == 'Edit') {
      $query = "UPDATE `$table` SET `user_id`=:user_id,`course_id`=:course_id,`serial_number`=:serial_number,`year_type`=:year_type,`subject_code`=:subject_code,`subject_name`=:subject_name,`posting_date`=:posting_date WHERE `id`=:id";
      $statement = $pdo_conn->prepare($query);
      $statement->execute(
         array(
          ':id' => $_POST['id'],
	      ':user_id' => $_SESSION["user_id"],
	      ':course_id' => $_POST['course_id'],
	      ':serial_number' => $_POST['serial_number'],
	      ':year_type' => $_POST['year_type'],
          ':subject_code' => $_POST['subject_code'],
          ':subject_name' => $_POST['subject_name'],
	      ':posting_date' => posting_date()
       ));
      		$result = $statement->fetchAll();
      		if (isset($result)) {
        		echo "Data has been edited.";
      		}
    	}
  // Change Status Data from DB
    if ($_POST['action_hidden']=='active_inactive') {
      $status = 'active';
      if ($_POST['id_status']=='active') {
        $status = 'inactive';
      }
      $query = "UPDATE $table SET id_status = :id_status WHERE id = :id";
      $statement = $pdo_conn->prepare($query);
      $statement->execute(
         array(
          ':id_status' => $status,
          ':id'  => $_POST['id']
         )
        );
      $result = $statement->fetchAll();
      if ($status == 'active') {
      	$status_result = '<span class="badge badge-success">Actived</span>';
      }else{
      	$status_result = '<span class="badge badge-danger">Inactived</span>';
      }
      if(isset($result)){
        echo 'Item Status has been '.$status_result;
      }
    }  
    		// Delete Section Action
	if($_POST["action_hidden"] == 'delete'){		
		$query = "DELETE FROM $table WHERE id = :id";	
		 $statement = $pdo_conn->prepare($query);
		 $result = $statement->execute(
		  array(
		   ':id' => $_POST["id"]
		  ));
		 	if (isset($result)) {
				echo "Data has been deleted.";
			}
	   }

	?>