<?php 
include 'db_config.php';
session_start();
if(!isset($_SESSION["type"])){
    header("location: index.php");
    exit;
}
?>
<?php require 'function.php';?>
<!-- Add Dashboard Parent File -->
<?php require 'dashboard_parent_file.php';?>
 <!-- HTML and Head Taq Section -->
<?php echo $html_and_head_section; ?>
      <!-- Body and Header Section -->
       <?php echo $body_and_header_section_start; ?>
    <!-- Navigation Menu Bar -->
    <?php include("navigation_bar_menu.php"); ?>
    <?php echo $body_and_header_section_end; ?>
      <!-- Side Navbar Section -->
    <?php echo $side_nabar_and_content_inner_section; ?>
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Home Page Information</h2>
            </div>
          </header>
          <!-- Dashboard Counts Section-->
          <section class="dashboard-counts no-padding-bottom">
            <div class="container-fluid">
              <!-- Alert Section -->     
              <p id="alert_action" class="mb-0"></p>     
              <!-- Table Section -->
               <div class="row border">
               <div class="col p-1" >Home Page Information List</div>
                <div class="col p-1" align="right">
                  <button class="btn btn-primary btn-sm launch-modal" data-toggle="modal" data-target="#form_modal" id="add_button"><i class="fas fa-plus-square"></i> Add</button>
                </div>
               </div>
              <div class="row bg-light border border-top-0 p-2">
                  <div class="table-responsive">
                    <table id="view_table" class="table table-bordered table-hover table-striped table-sm">
                      <thead class="thead-dark">
                        <tr>
                          <th>SL</th>
                          <th>Serial</th>
                          <th>Type</th>
                          <th>Title</th>
                          <th>Files</th>
                          <th>Status</th>
                          <th>Post Date</th>
                          <th width="15%">Action</th>
                        </tr>
                      </thead>
                    </table>
                  </div>
               </div>
            </div>          
          </section> 
<div class="modal fade" id="form_modal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title"></h6>
         <button type="button" class="close" data-dismiss="modal">&times;</button>
       </div>
         <form method="post" id="data_form" enctype="multipart/form-data">
            <div class="modal-body">    
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Type:</label>
                  <div class="col-sm-9">
                    <select id="type" name="type" class="form-control form-control-sm" required>
                      <option value="">Please Select Type</option>
                      <option value="Carousel">Carousel</option>
                      <option value="NIE">National International Event</option>
                      <option value="LatestNotice">Latest Notice</option>
                      <option value="Notice">Notice</option>
                      <option value="Event">Event</option>
                      <option value="Conferences">Conferences</option>
                      <option value="WCU">Why Choose Us</option>
                      <option value="SC">Sister Concern</option>
                    </select>
                  </div>
                </div>    
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Serial Number:</label>
                  <div class="col-sm-9">
                    <input type="number" name="serial_number" id="serial_number" class="form-control form-control-sm" required="1">
                  </div>
                </div>                                      
                <div class="row p-1">
                  <label class="col-sm-3" align="right">Title:</label>
                  <div class="col-sm-9">
                    <input type="text" name="title" id="title" class="form-control form-control-sm" maxlength="200" required="1">
                  </div>
                </div>   

                <div class="row p-1">
                  <label class="col-sm-3" align="right">Description/Details:</label>
                  <div class="col-sm-9">
                    <textarea rows="5" name="details" id="details" class="form-control form-control-sm">
                    </textarea>
                  </div>
                </div>   
                <div class="row p-1">
                  <label class="col-sm-3" align="right">File:</label>
                  <div class="col-sm-9">
                    <input type="file" name="file" id="file" value="text" class="form-control form-control-sm">
                     <small class="text-danger" id="vald_ntc">*Carousel(1920&times;620),NIE/WCU(1200&times;500),Conference(1120&times;500),Sister Logo(268&times;264)</small><br>     
                     <small class="text-danger">*File Less than 1 MB</small>        
                  </div>                    
                </div>
                <div class="row p-1">
                  <label class="col-sm-3" align="right">Link:</label>
                  <div class="col-sm-9">
                    <input type="text" name="link" id="link" class="form-control form-control-sm">
                  </div>
                </div>
                <div class="row p-1">
                  <label class="col-sm-3" align="right">Conference Date:</label>
                  <div class="col-sm-9">
                    <input type="date" name="conference_date" id="conference_date" class="form-control form-control-sm">
                  </div>
                </div>
                <span id="file_view"></span>
            </div>                                                                                           
            <div class="modal-footer">
            <input type="hidden" name="id" id="id" >
            <input type="hidden" name="action_hidden" id="action_hidden">
            <input type="submit" name="action_submit" id="action_submit"  class="btn btn-primary btn-sm mb-0">
            <button type="button" class="btn btn-info btn-sm mb-0" class="close" data-dismiss="modal">Close</button>
            </div>
          </form>
    </div>
  </div>
</div> 
           <div id="view_modal" class="modal fade">
            <div class="modal-dialog modal-lg">
                <form method="post">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Information View Details</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <Div id="view_data_modal"></Div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>        
          <!-- end Page Side Navbar Content Inner and Page Footer Section-->
    <?php echo $end_page_sidenav_content_footer_section; ?>
    <!-- End Body and HTML TaqJavaScript Section-->
    <?php echo $end_body_html_and_java_script_section; ?>    
<script>
  $(document).ready(function(){
        $("#add_button").click(function(){
          $('.modal-title').html("Add Authority");
          $('#alert_action').empty();
          $('#data_form')[0].reset();
          $('#action_hidden').val('Add');
          $('#action_submit').val('Save'); 
  });
  $(document).on('submit','#data_form',function(event){
    event.preventDefault(); 
      $.ajax({
        url:"home_action.php",
        method:'POST',
        data:new FormData(this),
        contentType:false,
        processData:false,
        success:function(data){
          $('#form_modal').modal("hide");
          $('#alert_action').fadeIn().html('<div class = "alert alert-success">'+data+'</div>'); 
          dataTable.ajax.reload();
        }
      });
  }); 
   // fetch data from database
    var dataTable = $('#view_table').DataTable({
     "processing" : true,
     "serverSide" : true,
     "order": [[ 0, "desc" ]],
     "ajax" : {
      url:"home_fetch.php",
      type:"POST"   
     },
     "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
    });
 // // Update Section
 $(document).on('click', '.update', function(){
  var id = $(this).attr("id");
  var action_hidden = 'fetch_single';
  $.ajax({
   url:"home_action.php",
   method:"POST",
   data:{id:id, action_hidden:action_hidden},
   dataType:"json",
   success:function(data){
    $('#form_modal').modal('show');
    $('.modal-title').html("Edit Information");    
    $('#type').val(data.type);
    $('#serial_number').val(data.serial_number);
    $('#title').val(data.title);
    $('#file_view').html(data.file);
    $('#details').val(data.details);
    $('#link').val(data.link);
    $('#id').val(id); // this id go to form id
    $('#action_submit').val('Edit');
    $('#action_hidden').val("Edit");
    $('#alert_action').empty();
   }
  })
 });  

    // view data from Database 
      $(document).on('click', '.view', function(){
          var id = $(this).attr("id");
          var btn_action = 'btn_view';
          $.ajax({
              url:"home_view.php",
              method:"POST",
              data:{id:id, btn_action:btn_action}, // pass variable to $_POST[] method in banwnotevt_view .php
              success:function(data){
                  $('#view_modal').modal('show');
                  $('#view_data_modal').html(data);
              }
          })
      });

  //Active and Inactive Section
   $(document).on('click', '.btn_active_inactive', function(){
  var id = $(this).attr('id');
  var id_status = $(this).data("status"); // fetch status value from $row ['teacher_status']
  var action_hidden = 'active_inactive';
  if(confirm("Are you sure you want to active or inactive this ID?")){
     $.ajax({
      url:"home_action.php",
      method:"POST",
      data:{id:id, id_status:id_status, action_hidden:action_hidden},
      success:function(data){
        $('#alert_action').fadeIn().html('<div class="alert alert-info">'+data+'</div>');
         dataTable.ajax.reload();
      }
     })
  }
  else{
   return false;
  }
 });
 // Delte Section
 $(document).on('click', '.delete', function(){
  var id = $(this).attr("id");
   var action_hidden = 'delete';
  if(confirm("Are you sure you want to delete this item?")){
   $.ajax({
    url:"home_action.php",
    method:"POST",
    data:{id:id,action_hidden:action_hidden},
    success:function(data){
      $('#alert_action').fadeIn().html('<div class="alert alert-danger">'+data+'</div>');
      dataTable.ajax.reload();
    }
   });
  }
  else{
   return false; 
  }
 });

  });
</script>
