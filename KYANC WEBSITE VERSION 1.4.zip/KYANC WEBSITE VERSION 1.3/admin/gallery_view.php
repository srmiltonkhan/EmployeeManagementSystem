<?php
 include 'db_config.php';
if($_POST['btn_action'] == 'btn_view'){
		$query = "SELECT * FROM `gallery` INNER JOIN users ON users.user_id = gallery.user_id WHERE id  = '".$_POST["id"]."'";
        $statement = $pdo_conn->prepare($query);
        $statement->execute();
        $result = $statement->fetchAll();
        $output = '';
         foreach($result as $row){
           $id_status = '';
          if($row['id_status'] == 'active'){
            $id_status = '<h2><span class="badge badge-success">Active</span></h2>';
           }else{
            $id_status = '<h2><span class="badge badge-danger">Inactive</span</h2>';
          } 
         $file = '';
        if ($row['file'] !='') {
          $file = '<img src="Files/WebContentsFiles/'.$row["file"].'" alt="'.$row["file"].'" class="thumbnail" width="200" height="100" />';
        }else{
          $file = '';
        }                   
         	$output .='
         	<div class="table-responsive">
         		<table class="table table-bordered table-sm">               
                    <tr>
                        <td>Type</td>
                        <td>'.$row['type'].'</td>
                    </tr> 
                     <tr>
                        <td>Title</td>
                        <td>'.$row['title'].'</td>
                    </tr>  
                       <tr>
                        <td>File</td>
                        <td>'.$file.'</td>
                    </tr>                                        
                     <tr>
                        <td>Link</td>
                        <td>'.$row['link'].'</td>
                    </tr>                   
                    <tr>
                        <td>Status</td>
                        <td>'.$id_status.'</td>
                    </tr>                                                                              
                                             
                     <tr>
                        <td>Date</td>
                        <td>'.$row['posting_date'].'</td>
                    </tr>                      
                    <tr>
                        <td>Entered By</td>
                        <td>'.$row['user_name'].'</td>
                    </tr>                                                                                                                                                                   		
                 </table>
         	</div>	
         	';
         }
         echo $output;
    }; 

 
?>