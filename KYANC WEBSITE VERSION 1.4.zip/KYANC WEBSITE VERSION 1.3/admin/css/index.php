<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
  <center><a href="https://kyanc.edu.bd/">Clik to go Home Page</a></center>
  <center>Error 404</center>
</body>
</html>