<?php 
include 'db_config.php';
// Check if the user is logged in, if not then redirect him to login page
session_start();
if(!isset($_SESSION["type"])){
    header("location: index.php");
    exit;
}
?>

<?php require 'function.php';?>
<!-- Add Dashboard Parent File -->
<?php require 'dashboard_parent_file.php';?>
 <!-- HTML and Head Taq Section -->
<?php echo $html_and_head_section; ?>
      <!-- Body and Header Section -->
       <?php echo $body_and_header_section_start; ?>
    <!-- Navigation Menu Bar -->
    <?php include("navigation_bar_menu.php"); ?>
    <?php echo $body_and_header_section_end; ?>
      <!-- Side Navbar Section -->
    <?php echo $side_nabar_and_content_inner_section; ?>
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">E-Recruitment Information</h2>
            </div>
          </header>
          <!-- Dashboard Counts Section-->
          <section class="dashboard-counts no-padding-bottom">
            <div class="container-fluid">
              <!-- Alert Section -->     
              <p id="alert_action" class="mb-0"></p>     
              <!-- Table Section -->
               <div class="row border">
               <div class="col p-1" >E-Recruitment Information List</div>
                <div class="col p-1" align="right">
                  <button class="btn btn-primary btn-sm launch-modal" data-toggle="modal" data-target="#form_modal" id="add_button"><i class="fas fa-plus-square"></i> Add</button>
                </div>
               </div>
              <div class="row bg-light border border-top-0 p-2">
                  <div class="table-responsive">
                    <table id="view_table" class="table table-bordered table-hover table-striped table-sm">
                      <thead class="thead-dark">
                        <tr>
                         <th>Serial</th>
                          <th>Job ID</th>
                          <th>Position</th>
                          <th>Title</th>
                          <th>No. of Post</th>
                          <th>File</th>
                          <th>Status</th>
                          <th>Deadline</th>
                          <th width="15%">Action</th>
                        </tr>
                      </thead>
                    </table>
                  </div>
               </div>
            </div>          
          </section> 
<div class="modal fade" id="form_modal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title"></h6>
         <button type="button" class="close" data-dismiss="modal">&times;</button>
       </div>
         <form method="post" id="data_form" enctype="multipart/form-data">
            <div class="modal-body">      
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Job ID:</label>
                  <div class="col-sm-9">
                    <input type="number" name="Job_id" id="Job_id" class="form-control form-control-sm" required="1">
                  </div>
                </div>  

                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Position:</label>
                  <div class="col-sm-9">
                    <input type="text" name="position" id="position" class="form-control form-control-sm"required="1">
                  </div>
                </div>           

                  <div class="row p-1">
                  <label class="col-sm-3" align="right">Title:</label>
                  <div class="col-sm-9">
                    <input type="text" name="title" id="title" class="form-control form-control-sm" required="1">
                  </div>
                </div>   
                  <div class="row p-1">
                  <label class="col-sm-3" align="right">File:</label>
                  <div class="col-sm-9">
                    <input type="file" name="file" id="file" class="form-control form-control-sm">
                    <small class="text-danger">*File Less than 1 MB</small> 
                  </div>
                </div>  
                  <div class="row p-1">
                  <label class="col-sm-3" align="right">details:</label>
                  <div class="col-sm-9">
                    <textarea rows="5" name="details" id="details" class="form-control form-control-sm"></textarea>
                  </div>
                </div>  
                  <div class="row p-1">
                  <label class="col-sm-3" align="right">Number of Post:</label>
                  <div class="col-sm-9">
                    <input type="number" name="num_of_post" id="num_of_post" class="form-control form-control-sm">
                  </div>
                </div> 

                  <div class="row p-1">
                  <label class="col-sm-3" align="right">Age On Calculated:</label>
                  <div class="col-sm-9">
                    <input type="date" name="age_cal_on" id="age_cal_on" class="form-control form-control-sm">
                  </div>
                </div> 
                  <div class="row p-1">
                  <label class="col-sm-3" align="right">Academic Requirement:</label>
                  <div class="col-sm-9">
                    <input type="text" name="academic_requirement" id="academic_requirement" class="form-control form-control-sm" required>
                  </div>
                </div> 
                  <div class="row p-1">
                  <label class="col-sm-3" align="right">Deadline:</label>
                  <div class="col-sm-9">
                    <input type="date" name="deadline" id="deadline" class="form-control form-control-sm" required="1">
                  </div>
                </div>
            </div>                                                                                               
            <div class="modal-footer">
            <input type="hidden" name="id" id="id" >
            <input type="hidden" name="action_hidden" id="action_hidden">
            <input type="submit" name="action_submit" id="action_submit"  class="btn btn-primary btn-sm mb-0">
            <button type="button" class="btn btn-info btn-sm mb-0" class="close" data-dismiss="modal">Close</button>
            </div>
          </form>
    </div>
  </div>
</div> 
<div id="view_modal" class="modal fade">
<div class="modal-dialog modal-lg">
  <form method="post">
      <div class="modal-content">
          <div class="modal-header">
              <h4 class="modal-title">Information View Details</h4>
              <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
              <Div id="view_data_modal"></Div>
          </div>
          <div class="modal-footer">
              <button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>
          </div>
      </div>
  </form>
</div>
</div>         
          <!-- end Page Side Navbar Content Inner and Page Footer Section-->
    <?php echo $end_page_sidenav_content_footer_section; ?>
    <!-- End Body and HTML TaqJavaScript Section-->
    <?php echo $end_body_html_and_java_script_section; ?>    
<script>
  $(document).ready(function(){
        $("#add_button").click(function(){
          $('.modal-title').html("Add E-Recruitment");
          $('#alert_action').empty();
          $('#data_form')[0].reset();
          $('#action_hidden').val('Add')
          $('#action_submit').val('Save') 
  });
  $(document).on('submit','#data_form',function(event){
    event.preventDefault(); 
      $.ajax({
        url:"recruitment_action.php",
        method:'POST',
        data:new FormData(this),
        contentType:false,
        processData:false,
        success:function(data){
          $('#form_modal').modal("hide");
          $('#alert_action').fadeIn().html('<div class = "alert alert-success">'+data+'</div>'); 
          dataTable.ajax.reload();
        }
      });
  }); 
 // fetch data from database
    var dataTable = $('#view_table').DataTable({
     "processing" : true,
     "serverSide" : true,
     "order": [[ 0, "desc" ]],
     "ajax" : {
      url:"recruitment_fetch.php",
      type:"POST"   
     },
     "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
    });
  // view data from Database 
      $(document).on('click', '.view', function(){
          var id = $(this).attr("id");
          var btn_action = 'btn_view';
          $.ajax({
              url:"recruitment_view.php",
              method:"POST",
              data:{id:id, btn_action:btn_action}, // pass variable to $_POST[] method in banwnotevt_view .php
              success:function(data){
                  $('#view_modal').modal('show');
                  $('#view_data_modal').html(data);
              }
          })
      }); 

 // // Update Section
 $(document).on('click', '.update', function(){
  var id = $(this).attr("id");
  var action_hidden = 'fetch_single';
  $.ajax({
   url:"recruitment_action.php",
   method:"POST",
   data:{id:id, action_hidden:action_hidden},
   dataType:"json",
   success:function(data){
    $('#form_modal').modal('show');
    $('.modal-title').html("Edit Information");    
    $('#Job_id').val(data.Job_id);
    $('#position').val(data.position);
    $('#title').val(data.title);
    $('#details').val(data.details);
    $('#num_of_post').val(data.num_of_post);
    $('#age_cal_on').val(data.age_cal_on);
    $('#academic_requirement').val(data.academic_requirement);
    $('#deadline').val(data.deadline);
    $('#id').val(id); // this id go to form id
    $('#action_submit').val('Edit');
    $('#action_hidden').val("Edit");
    $('#alert_action').empty();
   }
  })
 });  
      //Active and Inactive Section
   $(document).on('click', '.btn_active_inactive', function(){
  var id = $(this).attr('id');
  var id_status = $(this).data("status"); // fetch status value from $row ['teacher_status']
  var action_hidden = 'active_inactive';
  if(confirm("Are you sure you want to active or inactive this ID?")){
     $.ajax({
      url:"recruitment_action.php",
      method:"POST",
      data:{id:id, id_status:id_status, action_hidden:action_hidden},
      success:function(data){
        $('#alert_action').fadeIn().html('<div class="alert alert-info">'+data+'</div>');
         dataTable.ajax.reload();
      }
     })
  }
  else{
   return false;
  }
 });
 // Delete Section
 $(document).on('click', '.delete', function(){
  var id = $(this).attr("id");
   var action_hidden = 'delete';
  if(confirm("Are you sure you want to delete this item?")){
   $.ajax({
    url:"recruitment_action.php",
    method:"POST",
    data:{id:id,action_hidden:action_hidden},
    success:function(data){
      $('#alert_action').fadeIn().html('<div class="alert alert-danger">'+data+'</div>');
      dataTable.ajax.reload();
    }
   });
  }
  else{
   return false; 
  }
 });
  });
</script>
