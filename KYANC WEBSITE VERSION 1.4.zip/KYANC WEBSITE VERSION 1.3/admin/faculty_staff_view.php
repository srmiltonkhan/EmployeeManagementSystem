<?php
 include 'db_config.php';
if($_POST['btn_action'] == 'btn_view'){
		$query = "SELECT * FROM `facultystaff` INNER JOIN users ON users.user_id = facultystaff.user_id WHERE id  = '".$_POST["id"]."'";
        $statement = $pdo_conn->prepare($query);
        $statement->execute();
        $result = $statement->fetchAll();
        $output = '';
         foreach($result as $row){
           $id_status = '';
          if($row['id_status'] == 'active'){
            $id_status = '<h2><span class="badge badge-success">Active</span></h2>';
           }else{
            $id_status = '<h2><span class="badge badge-danger">Inactive</span</h2>';
          } 
         $web_file_nam = '';
        if ($row['file'] !='') {
          $web_file_nam = '<img src="Files/WebContentsFiles/'.$row["file"].'" alt="'.$row["file"].'" class="thumbnail" width="100" height="100" />';
        }else{
          $web_file_nam = '';
        }                   
         	$output .='
         	<div class="table-responsive">
         		<table class="table table-bordered table-sm">    
                    <tr>
                        <td>Type</td>
                        <td>'.$row['type'].'</td>
                    </tr>                           
                    <tr>
                        <td>Serial Number</td>
                        <td>'.$row['serial_number'].'</td>
                    </tr>
                    <tr>
                        <td>ID NO.</td>
                        <td>'.$row['mem_id_num'].'</td>
                    </tr>
                    <tr>
                        <td>Name</td>
                        <td>'.$row['name'].'</td>
                    </tr>
                    <tr>
                        <td>Profile</td>
                        <td>'.$web_file_nam.'</td>
                    </tr>
                    <tr>
                        <td>Designation</td>
                        <td>'.$row['designation'].'</td>
                    </tr>   
                    <tr>
                        <td>Mobile</td>
                        <td>'.$row['mobile'].'</td>
                    </tr>   
                    <tr>
                        <td>Email</td>
                        <td>'.$row['email'].'</td>
                    </tr>  
                     <tr>
                        <td>Qualification</td>
                        <td>'.$row['qualification'].'</td>
                    </tr>  

                     <tr>
                        <td>Short Biography</td>
                        <td>'.$row['short_biography'].'</td>
                    </tr>      

                     <tr>
                        <td>Research Interest</td>
                        <td>'.$row['research_interest'].'</td>
                    </tr> 

                     <tr>
                        <td>Research and Publication</td>
                        <td>'.$row['research_and_publication'].'</td>
                    </tr>    

                     <tr>
                        <td>Academic Information</td>
                        <td>'.$row['academic_info'].'</td>
                    </tr>                                       
                     <tr>
                        <td>Experience</td>
                        <td>'.$row['experience'].'</td>
                    </tr>   
                     <tr>
                        <td>Linkedin</td>
                        <td>'.$row['linkedin'].'</td>
                    </tr> 
                     <tr>
                        <td>Website</td>
                        <td>'.$row['website'].'</td>
                    </tr> 
                     <tr>
                        <td>Twitter</td>
                        <td>'.$row['twitter'].'</td>
                    </tr> 
                     <tr>
                        <td>Facebook</td>
                        <td>'.$row['facebook'].'</td>
                    </tr> 
                     <tr>
                        <td>Youtube</td>
                        <td>'.$row['youtube'].'</td>
                    </tr>   
                     <tr>
                        <td>Gender</td>
                        <td>'.$row['gender'].'</td>
                    </tr>  
                     <tr>
                        <td>Blood Group</td>
                        <td>'.$row['blood_group'].'</td>
                    </tr>
                     <tr>
                        <td>National ID</td>
                        <td>'.$row['nid'].'</td>
                    </tr>
                     <tr>
                        <td>Status</td>
                        <td>'.$id_status.'</td>
                    </tr>                      
                    <tr>
                        <td>Entered By</td>
                        <td>'.$row['user_name'].'</td>
                    </tr>                                                                                                                                                                   		
                 </table>
         	</div>	
         	';
         }
         echo $output;
    }; 

 
?>