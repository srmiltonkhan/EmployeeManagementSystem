<?php 
include 'db_config.php';
// Check if the user is logged in, if not then redirect him to login page
session_start();
if(!isset($_SESSION["type"])){
    header("location: index.php");
    exit;
}
?>

<?php require 'function.php';?>
<!-- Add Dashboard Parent File -->
<?php require 'dashboard_parent_file.php';?>
 <!-- HTML and Head Taq Section -->
<?php echo $html_and_head_section; ?>
      <!-- Body and Header Section -->
       <?php echo $body_and_header_section_start; ?>
    <!-- Navigation Menu Bar -->
    <?php include("navigation_bar_menu.php"); ?>
    <?php echo $body_and_header_section_end; ?>
      <!-- Side Navbar Section -->
    <?php echo $side_nabar_and_content_inner_section; ?>
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Manage Faculty and Staff</h2>
            </div>
          </header>
          <!-- Dashboard Counts Section-->
          <section class="dashboard-counts no-padding-bottom">
            <div class="container-fluid">
              <!-- Alert Section -->     
              <p id="alert_action" class="mb-0"></p>     
              <!-- Table Section -->
               <div class="row border">
               <div class="col p-1" >Faculty and Staff Information List</div>
                <div class="col p-1" align="right">
                  <button class="btn btn-primary btn-sm launch-modal" data-toggle="modal" data-target="#form_modal" id="add_button"><i class="fas fa-plus-square"></i> Add</button>
                </div>
               </div>
              <div class="row bg-light border border-top-0 p-2">
                  <div class="table-responsive">
                    <table id="view_table" class="table table-bordered table-hover table-striped table-sm">
                      <thead class="thead-dark">
                        <tr>
                          <th>Serial</th>
                          <th>Type</th>
                          <th>ID NO.</th>
                          <th>Image</th>
                          <th>Name</th>
                          <th>Designation</th>
                          <th>Mobile</th>
                          <th>Status</th>
                          <th width="15%">Action</th>
                        </tr>
                      </thead>
                    </table>
                  </div>
               </div>
            </div>          
          </section> 
<div class="modal fade" id="form_modal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title"></h6>
         <button type="button" class="close" data-dismiss="modal">&times;</button>
       </div>
         <form method="post" id="data_form" enctype="multipart/form-data">
            <div class="modal-body">    
                  <div class="row p-1">
                  <label class="col-sm-3" align="right">Type:</label>
                  <div class="col-sm-9">
                    <select id="type" name="type" class="form-control form-control-sm" required>
                      <option value="">Please Select Type</option>
                      <option value="Faculty">Faculty</option>
                      <option value="Staff">Staff</option>
                    </select>
                  </div>
                </div>              
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Serial Number:</label>
                  <div class="col-sm-9">
                    <input type="number" name="serial_number" id="serial_number" class="form-control form-control-sm" required="1">
                  </div>
                </div> 
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">ID NO.:</label>
                  <div class="col-sm-9">
                    <input type="text" name="mem_id_num" id="mem_id_num" class="form-control form-control-sm">
                  </div>
                </div> 

                  <div class="row p-1">
                  <label class="col-sm-3" align="right">Name:</label>
                  <div class="col-sm-9">
                    <input type="text" name="name" id="name" class="form-control form-control-sm">
                  </div>
                </div>   

                <div class="row p-1">
                  <label class="col-sm-3" align="right">Profile Image:</label>
                  <div class="col-sm-9">
                    <input type="file" name="file" id="file" value="text" class="form-control form-control-sm">  
                     <small class="text-danger" id="vald_ntc">*Faculty Staff Image Dimension should be(400&times;350)</small>           
                  </div>                    
                </div>
        
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Designation:</label>
                  <div class="col-sm-9">
                    <input type="text" name="designation" id="designation" class="form-control form-control-sm">
                  </div>
                </div> 

                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Mobile:</label>
                  <div class="col-sm-9">
                    <input type="text" name="mobile" id="mobile" class="form-control form-control-sm">
                  </div>
                </div> 
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">E-Mail:</label>
                  <div class="col-sm-9">
                    <input type="email" name="email" id="email" class="form-control form-control-sm">
                  </div>
                </div> 
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Qualification:</label>
                  <div class="col-sm-9">
                    <input type="text" name="qualification" id="qualification" class="form-control form-control-sm">
                  </div>
                </div> 
                  <div class="row p-1">
                  <label class="col-sm-3" align="right">Short Biography:</label>
                  <div class="col-sm-9">
                    <textarea rows="5" name="short_biography" id="short_biography" class="form-control form-control-sm"></textarea>
                  </div>
                </div>  

                  <div class="row p-1">
                  <label class="col-sm-3" align="right">Research Interest:</label>
                  <div class="col-sm-9">
                    <input type="text" name="research_interest" id="research_interest" class="form-control form-control-sm" maxlength="200">
                  </div>
                </div>  
                <div class="row p-1">
                  <label class="col-sm-3" align="right">Research and Publication:</label>
                  <div class="col-sm-9">
                    <textarea rows="5" name="research_and_publication" id="research_and_publication" class="form-control form-control-sm"></textarea>
                  </div>
                </div>   
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Academic Information:</label>
                  <div class="col-sm-9">
                    <textarea rows="5" name="academic_info" id="academic_info" class="form-control form-control-sm" placeholder="Institute: Rajshahi Medical University, Rajshahi&#x0a;Period:2010 to 2013&#x0a;MPH"></textarea>
                  </div>
                </div>   

                <div class="row p-1">
                  <label class="col-sm-3" align="right">Experience Information:</label>
                  <div class="col-sm-9">
                    <textarea rows="5" name="experience" id="experience" class="form-control form-control-sm" placeholder="Organization: Dhaka Medical College&#x0a;Possition:Professor&#x0a;Period:1ˢᵗ Janury,2020 to 1ˢᵗ Februry,2021 "></textarea>
                  </div>
                </div>    
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Linkedin</label>
                  <div class="col-sm-9">
                     <input type="text" name="linkedin" id="linkedin" class="form-control form-control-sm" maxlength="200">
                  </div>
                </div>                 

                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Website</label>
                  <div class="col-sm-9">
                     <input type="text" name="website" id="website" class="form-control form-control-sm" maxlength="200">
                  </div>
                </div>   
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Twitter</label>
                  <div class="col-sm-9">
                     <input type="text" name="twitter" id="twitter" class="form-control form-control-sm" maxlength="200">
                  </div>
                </div>  

                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Facebook</label>
                  <div class="col-sm-9">
                     <input type="text" name="facebook" id="facebook" class="form-control form-control-sm" maxlength="150">
                  </div>
                </div>  
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Youtube</label>
                  <div class="col-sm-9">
                     <input type="text" name="youtube" id="youtube" class="form-control form-control-sm" maxlength="150">
                  </div>
                </div>  

                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Gender</label>
                  <div class="col-sm-9">
                     <select id="gender" name="gender" class="form-control form-control-sm">
                       <option value="">Please Select One</option>
                       <option value="Male">Male</option>
                       <option value="Female">Female</option>
                     </select>
                  </div>
                </div>  

                  <div class="row p-1">
                  <label class="col-sm-3" align="right">Blood Group</label>
                  <div class="col-sm-9">
                      <select id="blood_group" name="blood_group" class="form-control form-control-sm">
                        <option value="">Select Blood Group</option>
                        <option value="A+">A+</option>
                        <option value="B+">B+</option>
                        <option value="AB+">AB+</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                        <option value="A-">A-</option>
                        <option value="B-">B-</option>
                        <option value="AB-">AB-</option>
                      </select>
                  </div>
                 </div>
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">National ID</label>
                  <div class="col-sm-9">
                     <input type="text" name="nid" id="nid" class="form-control form-control-sm" maxlength="17">
                  </div>
                </div>  

                                 
                <span id="file_view"></span>
            </div>                                                                                           
            <div class="modal-footer">
            <input type="hidden" name="id" id="id" >
            <input type="hidden" name="action_hidden" id="action_hidden">
            <input type="submit" name="action_submit" id="action_submit"  class="btn btn-primary btn-sm mb-0">
            <button type="button" class="btn btn-info btn-sm mb-0" class="close" data-dismiss="modal">Close</button>
            </div>
          </form>
    </div>
  </div>
</div> 
           <div id="view_modal" class="modal fade">
            <div class="modal-dialog modal-lg">
                <form method="post">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Information View Details</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <Div id="view_data_modal"></Div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>        
          <!-- end Page Side Navbar Content Inner and Page Footer Section-->
    <?php echo $end_page_sidenav_content_footer_section; ?>
    <!-- End Body and HTML TaqJavaScript Section-->
    <?php echo $end_body_html_and_java_script_section; ?>    
<script>

  // Picture upload validation
var _URL = window.URL && window.webkitURL;
$("#file").change(function (e) {
    var file, img;
    if (file = this.files[0]) {
        img = new Image();
        img.onload = function () {
        var width=this.width;
         var height=this.height;
         if(width != 400 && height != 350)
         {
           $('#vald_ntc').fadeIn(2000);
           $('#action_submit').prop("disabled",true);
           
         }else{
          $('#vald_ntc').fadeOut(1000);
          $('#action_submit').prop("disabled",false);
         }     
        };
        img.src = _URL.createObjectURL(file);
    }
});
  $(document).ready(function(){
        $("#add_button").click(function(){
          $('.modal-title').html("Add Authority");
          $('#alert_action').empty();
          $('#data_form')[0].reset();
          $('#action_hidden').val('Add');
          $('#action_submit').val('Save'); 
  });


  $(document).on('submit','#data_form',function(event){
    event.preventDefault(); 
      $.ajax({
        url:"faculty_staff_action.php",
        method:'POST',
        data:new FormData(this),
        contentType:false,
        processData:false,
        success:function(data){
          $('#form_modal').modal("hide");
          $('#alert_action').fadeIn().html('<div class = "alert alert-success">'+data+'</div>'); 
          dataTable.ajax.reload();
        }
      });
  }); 
   // fetch data from database
    var dataTable = $('#view_table').DataTable({
     "processing" : true,
     "serverSide" : true,
     "order": [[ 0, "desc" ]],
     "ajax" : {
      url:"faculty_staff_fetch.php",
      type:"POST"   
     },
     "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
    });
  // view data from Database 
      $(document).on('click', '.view', function(){
          var id = $(this).attr("id");
          var btn_action = 'btn_view';
          $.ajax({
              url:"faculty_staff_view.php",
              method:"POST",
              data:{id:id, btn_action:btn_action}, // pass variable to $_POST[] method in banwnotevt_view .php
              success:function(data){
                  $('#view_modal').modal('show');
                  $('#view_data_modal').html(data);
              }
          })
      }); 
 // // Update Section
 $(document).on('click', '.update', function(){
  var id = $(this).attr("id");
  var action_hidden = 'fetch_single';
  $.ajax({
   url:"faculty_staff_action.php",
   method:"POST",
   data:{id:id, action_hidden:action_hidden},
   dataType:"json",
   success:function(data){
    $('#form_modal').modal('show');
    $('.modal-title').html("Edit Information");    
    $('#type').val(data.type);
    $('#mem_id_num').val(data.mem_id_num);
    $('#serial_number').val(data.serial_number);
    $('#name').val(data.name);
    $('#file_view').html(data.file);
    $('#designation').val(data.designation);
    $('#mobile').val(data.mobile);
    $('#email').val(data.email);
    $('#qualification').val(data.qualification);
    $('#short_biography').val(data.short_biography);
    $('#research_interest').val(data.research_interest);
    $('#research_and_publication').val(data.research_and_publication);
    $('#academic_info').val(data.academic_info);
    $('#experience').val(data.experience);
    $('#linkedin').val(data.linkedin);
    $('#website').val(data.website);
    $('#twitter').val(data.twitter);
    $('#facebook').val(data.facebook);
    $('#youtube').val(data.youtube);
    $('#gender').val(data.gender);
    $('#blood_group').val(data.blood_group);
    $('#nid').val(data.nid);
    $('#id').val(id); // this id go to form id
    $('#action_submit').val('Edit');
    $('#action_hidden').val("Edit");
    $('#alert_action').empty();
   }
  })
 });   
  //Active and Inactive Section
   $(document).on('click', '.btn_active_inactive', function(){
  var id = $(this).attr('id');
  var id_status = $(this).data("status"); // fetch status value from $row ['teacher_status']
  var action_hidden = 'active_inactive';
  if(confirm("Are you sure you want to active or inactive this ID?")){
     $.ajax({
      url:"faculty_staff_action.php",
      method:"POST",
      data:{id:id, id_status:id_status, action_hidden:action_hidden},
      success:function(data){
        $('#alert_action').fadeIn().html('<div class="alert alert-info">'+data+'</div>');
         dataTable.ajax.reload();
      }
     })
  }
  else{
   return false;
  }
 });
 // Delte Section
 $(document).on('click', '.delete', function(){
  var id = $(this).attr("id");
   var action_hidden = 'delete';
  if(confirm("Are you sure you want to delete this item?")){
   $.ajax({
    url:"faculty_staff_action.php",
    method:"POST",
    data:{id:id,action_hidden:action_hidden},
    success:function(data){
      $('#alert_action').fadeIn().html('<div class="alert alert-danger">'+data+'</div>');
      dataTable.ajax.reload();
    }
   });
  }
  else{
   return false; 
  }
 });

  });
</script>
