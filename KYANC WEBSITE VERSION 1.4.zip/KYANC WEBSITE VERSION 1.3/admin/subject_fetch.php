<?php
include 'db_config.php';
$column = array('subjects.id ');
$query = "SELECT * FROM subjects
INNER JOIN users ON users.user_id = subjects.user_id
INNER JOIN courses ON courses.course_id = subjects.course_id
";
if(isset($_POST['search']['value'])){
 $query .= '
 WHERE subjects.id LIKE "%'.$_POST["search"]["value"].'%"   
 OR courses.course_name LIKE "%'.$_POST["search"]["value"].'%"      
 OR subjects.subject_name LIKE "%'.$_POST["search"]["value"].'%"      
 OR subjects.subject_code LIKE "%'.$_POST["search"]["value"].'%"      
 OR subjects.year_type LIKE "%'.$_POST["search"]["value"].'%"      
 ';
}
if(isset($_POST['order'])){
 $query .= 'ORDER BY '.$column[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
}
else{
 $query .= 'ORDER BY subjects.id DESC';
}
$query1 = '';
if($_POST['length'] != -1){
 $query1 = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}
$statement = $pdo_conn->prepare($query);
$statement->execute();
$number_filter_row = $statement->rowCount();
$statement = $pdo_conn->prepare($query . $query1);
$statement->execute();
$result = $statement->fetchAll();
$data = array();
foreach($result as $row){	
$id_status = '';
 if($row['id_status'] == 'active'){
  $id_status = '<span class="badge badge-success">Active</span>';
 }else{
  $id_status = '<span class="badge badge-danger">Inactive</span>';
 }			
$sub_array = array();
$sub_array[] = $row['serial_number'];
$sub_array[] = $row['year_type'];
$sub_array[] = $row['course_name'];

$sub_array[] = $row['subject_code'];
$sub_array[] = $row['subject_name'];
 $sub_array[] ='<div class="text-center">'.$id_status.'</div>';
 $sub_array[] = '<div class="text-center"><button type="button" name="view" id="'.$row["id"].'" class="btn btn-info btn-sm view mr-2"><i class="fas fa-eye"></i></button>'.'<button type="button" name="update" id="'.$row["id"].'" class="btn btn-primary btn-sm update mr-2"><i class="fas fa-edit"></i></button>'.'<button type="button" name="delete" id="'.$row["id"].'" class="btn btn-danger btn-sm delete ml-2"><i class="fas fa-trash"></i></button></div>';
 $data[] = $sub_array;
}
function count_all_data($pdo_conn){
 $query = "SELECT * FROM subjects";
 $statement = $pdo_conn->prepare($query);
 $statement->execute();
 return $statement->rowCount();
}
$output = array(
 'draw'    => intval($_POST['draw']),
 'recordsTotal'  => count_all_data($pdo_conn),
 'recordsFiltered' => $number_filter_row,
 'data'    => $data
);
echo json_encode($output);
?>