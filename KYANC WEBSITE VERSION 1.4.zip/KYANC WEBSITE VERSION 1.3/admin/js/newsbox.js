    $(function () {
        $(".notice_board_slider").bootstrapNews({
            newsPerPage: 4,
            autoplay: true,
            pauseOnHover: true,
            navigation: false,
            direction: 'down',
            newsTickerInterval: 3000,
            onToDo: function () {
                //console.log(this);
            }
        });
    });