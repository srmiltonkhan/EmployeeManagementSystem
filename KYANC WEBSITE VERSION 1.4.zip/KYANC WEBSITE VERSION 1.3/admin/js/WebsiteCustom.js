// Sister Concern Carousel
$(document).ready(function(){
$('.sisterconJS').slick({
    slidesToShow:5,
    slidesToScroll: 1,
    dots: true,
    autoplay: true,
    arrows: true,
    autoplaySpeed: 1000,
    infinite: true,
});
});

// Conferences & Metting 
    $(document).ready(function(){
      $('.confCarouselJS').slick({
          slidesToShow:2,
          slidesToScroll: 1,
          dots: true,
          autoplay: true,
          arrows: true,
          autoplaySpeed: 1000,
          infinite: true,
      });
    });


