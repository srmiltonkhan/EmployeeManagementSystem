<?php 
include 'db_config.php';
session_start();
if(!isset($_SESSION["type"])){
    header("location: index.php");
    exit;
}
?>
<?php require 'function.php';?>
<!-- Add Dashboard Parent File -->
<?php require 'dashboard_parent_file.php';?>
 <!-- HTML and Head Taq Section -->
<?php echo $html_and_head_section; ?>
      <!-- Body and Header Section -->
       <?php echo $body_and_header_section_start; ?>
    <!-- Navigation Menu Bar -->
    <?php include("navigation_bar_menu.php"); ?>
    <?php echo $body_and_header_section_end; ?>
      <!-- Side Navbar Section -->
    <?php echo $side_nabar_and_content_inner_section; ?>
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">User Control</h2>
            </div>
          </header>
          <!-- Dashboard Counts Section-->
          <section class="dashboard-counts no-padding-bottom">
            <div class="container-fluid">
              <!-- Alert Section -->     
              <p id="alert_action" class="mb-0"></p>     
              <!-- Table Section -->
               <div class="row border">
               <div class="col p-1" > User List</div>
                <div class="col p-1" align="right">
                  <button class="btn btn-primary btn-sm launch-modal" data-toggle="modal" data-target="#form_modal" id="add_button"><i class="fas fa-plus-square"></i> Add</button>
                </div>
               </div>
              <div class="row bg-light border border-top-0 p-2">
                  <div class="table-responsive">
                    <table id="view_table" class="table table-bordered table-hover table-striped table-sm">
                      <thead class="thead-dark">
                        <tr>
                          <th>ID</th>
                          <th>Image</th>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Mobile</th>
                          <th>Department</th>
                          <th>Status</th>
                          <th width="15%">Action</th>
                        </tr>
                      </thead>
                    </table>
                  </div>
               </div>
            </div>          
          </section> 
<div class="modal fade" id="form_modal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title"></h6>
         <button type="button" class="close" data-dismiss="modal">&times;</button>
       </div>
         <form method="post" id="data_form" enctype="multipart/form-data">
            <div class="modal-body">                                                                             
                <div class="row p-1">
                  <label class="col-sm-3" align="right">User ID:</label>
                  <div class="col-sm-9">
                    <input type="text" name="user_id_num" id="user_id_num" class="form-control form-control-sm" pattern="^[0-9]{2,11}$">
                  </div>
                </div>   

                <div class="row p-1">
                  <label class="col-sm-3" align="right">Name:</label>
                  <div class="col-sm-9">
                    <input type="text" name="user_name" id="user_name" class="form-control form-control-sm" required>
                  </div>
                </div> 

                <div class="row p-1">
                  <label class="col-sm-3" align="right">Email:</label>
                  <div class="col-sm-9">
                        <input type="email" name="user_email" id="user_email" class="form-control form-control-sm" required>
                  </div>
                </div>  

                <div class="row p-1">
                  <label class="col-sm-3" align="right">Mobile:</label>
                  <div class="col-sm-9">
                      <input type="text" name="user_mobile" id="user_mobile" class="form-control form-control-sm" required>
                  </div>
                </div>  

                <div class="row p-1">
                  <label class="col-sm-3" align="right">Department:</label>
                  <div class="col-sm-9">
                      <input type="text" name="user_department" id="user_department" class="form-control form-control-sm" required>
                  </div>
                </div>  

                <div class="row p-1">
                  <label class="col-sm-3" align="right">Designation:</label>
                  <div class="col-sm-9">
                      <input type="text" name="user_designation" id="user_designation" class="form-control form-control-sm" required>
                  </div>
                </div> 

                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Passowrd:</label>
                  <div class="col-sm-4">
                      <input type="password" name="user_password" id="user_password" class="password form-control form-control-sm" minlength="8" maxlength="50" required>
                  </div>
                   <div class="col-sm-4">
                      <input type="password" name="user_confirm_password" id="user_confirm_password" class="password form-control form-control-sm" required="1">
                      <small id="msg"></small> 
                  </div> 
                </div>  
                 <div class="row p-1">
                  <label class="col-sm-3 ml-4" align="right">Default Passowrd Setting:</label>
                  <div class="col-sm-4">
                    <input type="checkbox" class="form-check-input" value="" id="passChk" name="passChk" onclick="passInFnc()">Default Password
                  </div>
                   <div class="col-sm-4">
                    <input type="checkbox" class="form-check-input" value="" id="passChk" name="passChk" onclick="passShow()">Show Password
                  </div> 
                </div>  
                     <script type="text/javascript">
                      function passInFnc() { // input default password
                      var passChk = document.getElementById("passChk");
                      if (passChk.checked == true){
                      $('#user_password').val('12345678');
                      $('#user_confirm_password').val('12345678');
                      } else{
                      $('#user_password').val('');
                      $('#user_confirm_password').val('');
                      }
                      }

                      function passShow(){ // show default password
                      var psf = document.getElementById("user_password");
                      if (psf.type === "password") {
                      psf.type = "text";
                      }else{
                      psf.type = "password";
                      }
                    }
                    </script>    
  

                <div class="row p-1">
                  <label class="col-sm-3" align="right">User Type:</label>
                  <div class="col-sm-9">
                    <select name="user_type" id="user_type" class="form-control form-control-sm">
                      <option value="">Please Select User Type</option>
                      <option value="Admin">Admin</option>
                      <option value="StandardUser">Standard User</option>
                      <option value="EndUser">End User</option>                      
                    </select>
                  </div>
                </div>
                <div class="row p-1">
                  <label class="col-sm-3" align="right">Image:</label>
                  <div class="col-sm-9">
                    <input type="file" name="user_image" id="user_image" class="form-control form-control-sm">
                  </div>
                </div>


                <span id="file_view"></span>
            </div>                                                                                           
            <div class="modal-footer">
            <input type="hidden" name="id" id="id" >
            <input type="hidden" name="action_hidden" id="action_hidden">
            <input type="submit" name="action_submit" id="action_submit"  class="btn btn-primary btn-sm mb-0">
            <button type="button" class="btn btn-info btn-sm mb-0" class="close" data-dismiss="modal">Close</button>
            </div>
          </form>
    </div>
  </div>
</div> 
           <div id="view_modal" class="modal fade">
            <div class="modal-dialog modal-lg">
                <form method="post">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Information View Details</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <Div id="view_data_modal"></Div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>        
          <!-- end Page Side Navbar Content Inner and Page Footer Section-->
    <?php echo $end_page_sidenav_content_footer_section; ?>
    <!-- End Body and HTML TaqJavaScript Section-->
    <?php echo $end_body_html_and_java_script_section; ?>    
<script>
  $(document).ready(function(){
        $("#add_button").click(function(){
          $('.modal-title').html("Add User");
          $('#alert_action').empty();
          $('#data_form')[0].reset();
          $('#action_hidden').val('Add');
          $('#action_submit').val('Save'); 
  });
  //Password Matched verification
  $("#user_confirm_password").keyup(function(){
      if ($("#user_password").val() != $("#user_confirm_password").val()) {
        $("#msg").html("Password doesn't match.").css("color","red");
      }else{
        $("#msg").html("Password has been matched.").css("color","green");
      }
    });

  //Insert Section into DB                      
  $(document).on('submit','#data_form',function(event){
    event.preventDefault(); 
      $.ajax({
        url:"user_control_action.php",
        method:'POST',
        data:new FormData(this),
        contentType:false,
        processData:false,
        success:function(data){
          $('#form_modal').modal("hide");
          $('#alert_action').fadeIn().html('<div class = "alert alert-success">'+data+'</div>'); 
          dataTable.ajax.reload();
        }
      });
  }); 
   // fetch data from database
    var dataTable = $('#view_table').DataTable({
     "processing" : true,
     "serverSide" : true,
     "order": [[ 0, "desc" ]],
     "ajax" : {
      url:"user_control_fetch.php",
      type:"POST"   
     },
     "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
    });
 // // Update Section
 $(document).on('click', '.update', function(){
  var id = $(this).attr("id");
  var action_hidden = 'fetch_single';
  $.ajax({
   url:"user_control_action.php",
   method:"POST",
   data:{id:id, action_hidden:action_hidden},
   dataType:"json",
   success:function(data){
    $('#form_modal').modal('show');
    $('.modal-title').html("Edit Information");    
    $('#user_id_num').val(data.user_id_num);
    $('#user_name').val(data.user_name);
    $('#user_email').val(data.user_email);
    $('#user_mobile').val(data.user_mobile);
    $('#user_department').val(data.user_department);
    $('#user_designation').val(data.user_designation);
    $('#user_password').val(data.user_password);
    $('#user_confirm_password').val(data.user_password);
    $('#user_type').val(data.user_type);
    $('#id').val(id); // this id go to form id
    $('#action_submit').val('Edit');
    $('#action_hidden').val("Edit");
    $('#alert_action').empty();
   }
  })
 });  

    // view data from Database 
      $(document).on('click', '.view', function(){
          var id = $(this).attr("id");
          var btn_action = 'btn_view';
          $.ajax({
              url:"user_control_view.php",
              method:"POST",
              data:{id:id, btn_action:btn_action}, // pass variable to $_POST[] method in banwnotevt_view .php
              success:function(data){
                  $('#view_modal').modal('show');
                  $('#view_data_modal').html(data);
              }
          })
      });
  //Active and Inactive Section
   $(document).on('click', '.btn_active_inactive', function(){
  var id = $(this).attr('id');
  var id_status = $(this).data("status"); // fetch status value from $row ['teacher_status']
  var action_hidden = 'active_inactive';
  if(confirm("Are you sure you want to active or inactive this ID?")){
     $.ajax({
      url:"user_control_action.php",
      method:"POST",
      data:{id:id, id_status:id_status, action_hidden:action_hidden},
      success:function(data){
        $('#alert_action').fadeIn().html('<div class="alert alert-info">'+data+'</div>');
         dataTable.ajax.reload();
      }
     })
  }
  else{
   return false;
  }
 });
  });
</script>
