<?php 
include 'db_config.php';
session_start();
if(!isset($_SESSION["type"])){
    header("location: index.php");
    exit;
}
?>
<?php require 'function.php';?>
<!-- Add Dashboard Parent File -->
<?php require 'dashboard_parent_file.php';?>
 <!-- HTML and Head Taq Section -->
<?php echo $html_and_head_section; ?>
      <!-- Body and Header Section -->
       <?php echo $body_and_header_section_start; ?>
    <!-- Navigation Menu Bar -->
    <?php include("navigation_bar_menu.php"); ?>
    <?php echo $body_and_header_section_end; ?>
      <!-- Side Navbar Section -->
    <?php echo $side_nabar_and_content_inner_section; ?>
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">File Contents Information</h2>
            </div>
          </header>
          <!-- Dashboard Counts Section-->
          <section class="dashboard-counts no-padding-bottom">
            <div class="container-fluid">
              <!-- Alert Section -->     
              <p id="alert_action" class="mb-0"></p>     
              <!-- Table Section -->
               <div class="row border">
               <div class="col p-1" > File Contents Information List</div>
                <div class="col p-1" align="right">
                  <button class="btn btn-primary btn-sm launch-modal" data-toggle="modal" data-target="#form_modal" id="add_button"><i class="fas fa-plus-square"></i> Add</button>
                </div>
               </div>
              <div class="row bg-light border border-top-0 p-2">
                  <div class="table-responsive">
                    <table id="view_table" class="table table-bordered table-hover table-striped table-sm">
                      <thead class="thead-dark">
                        <tr>
                          <th>SL</th>
                          <th>Type</th>
                          <th>Course</th>
                          <th>Title</th>
                          <th>File</th>
                          <th>Status</th>
                          <th>Published Date</th>
                          <th width="15%">Action</th>
                        </tr>
                      </thead>
                    </table>
                  </div>
               </div>
            </div>          
          </section> 
<div class="modal fade" id="form_modal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title"></h6>
         <button type="button" class="close" data-dismiss="modal">&times;</button>
       </div>
         <form method="post" id="data_form" enctype="multipart/form-data">
            <div class="modal-body">    
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Type:</label>
                  <div class="col-sm-9">
                    <select id="type" name="type" class="form-control form-control-sm" required>
                      <option value="" selected="selected">Please, Select One</option>
                      <option value="ClassRoutine">Class Routine</option> 
                      <option value="ExamRoutine">Exam Routine</option> 
                      <option value="AcademicResult">Academic Result</option> 
                      <option value="Calendar">Calendar</option> 
                      <option value="Prospectus">Prospectus</option> 
                      <option value="AdmissionCircular">Admission Circular</option> 
                      <option value="CourseInformation" title="Course Information Page Setup">Course Information Page Setup</option> 
                    </select>
                  </div>
                </div> 
                <div class="row p-1">
                  <label class="col-sm-3" align="right">Course Name:</label>
                  <div class="col-sm-9">
                    <select name="course_id" id="course_id" class="form-control form-control-sm" required="1">
                      <?php echo get_name_list($pdo_conn);?>
                    </select>
                  </div>
                </div> 

                <div class="row p-1">
                  <label class="col-sm-3" align="right">Title:</label>
                  <div class="col-sm-9">
                    <input type="text" name="title" id="title" class="form-control form-control-sm">
                  </div>
                </div>   
 
                <div class="row p-1">
                  <label class="col-sm-3" align="right">Batch:</label>
                  <div class="col-sm-9">
                    <input type="text" name="batch" id="batch" class="form-control form-control-sm" maxlength="15">
                  </div>
                </div>   

                <div class="row p-1">
                  <label class="col-sm-3" align="right">Semester:</label>
                  <div class="col-sm-9">
                    <input type="text" name="semester" id="semester" class="form-control form-control-sm" maxlength="16">
                  </div>
                </div>   
                <div class="row p-1">
                  <label class="col-sm-3" align="right">File:</label>
                  <div class="col-sm-9">
                    <input type="file" name="file" id="file" class="form-control form-control-sm" maxlength="50">
                    <small class="text-danger">File Size Should be less than 1.5 MB</small>
                  </div>
                </div>   
                <div class="row p-1">
                  <label class="col-sm-3" align="right">Link:</label>
                  <div class="col-sm-9">
                    <input type="text" name="link" id="link" class="form-control form-control-sm" maxlength="200">
                  </div>
                </div>     
                <div class="row p-1">
                  <label class="col-sm-3" align="right">Year:</label>
                  <div class="col-sm-9">
                    <input type="number" name="year" id="year" class="form-control form-control-sm" maxlength="4 ">
                  </div>
                </div> 
                <div class="row p-1">
                  <label class="col-sm-3" align="right">Duration:</label>
                  <div class="col-sm-9">
                    <input type="text" name="duration" id="duration" class="form-control form-control-sm" maxlength="200">
                  </div>
                </div> 
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Number Of Seat:</label>
                  <div class="col-sm-9">
                    <input type="number" name="num_of_seat" id="num_of_seat" class="form-control form-control-sm" maxlength="5">
                  </div>
                </div> 
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Session Start:</label>
                  <div class="col-sm-9">
                    <input type="text" name="session_start" id="session_start" class="form-control form-control-sm" maxlength="16">
                  </div>
                </div> 
                 <div class="row p-1">
                  <label class="col-sm-3" align="right">Published/Deadline Date:</label>
                  <div class="col-sm-9">
                    <input type="date" name="published_date" id="published_date" class="form-control form-control-sm" maxlength="30" placeholder="Published and Deadline Date">
                  </div>
                </div> 
                <span id="file_view"></span>
            </div>                                                                                           
            <div class="modal-footer">
            <input type="hidden" name="id" id="id" >
            <input type="hidden" name="action_hidden" id="action_hidden">
            <input type="submit" name="action_submit" id="action_submit"  class="btn btn-primary btn-sm mb-0">
            <button type="button" class="btn btn-info btn-sm mb-0" class="close" data-dismiss="modal">Close</button>
            </div>
          </form>
    </div>
  </div>
</div> 
           <div id="view_modal" class="modal fade">
            <div class="modal-dialog modal-lg">
                <form method="post">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Information View Details</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <Div id="view_data_modal"></Div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary btn-sm" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>        
          <!-- end Page Side Navbar Content Inner and Page Footer Section-->
    <?php echo $end_page_sidenav_content_footer_section; ?>
    <!-- End Body and HTML TaqJavaScript Section-->
    <?php echo $end_body_html_and_java_script_section; ?>    
<script>
  $(document).ready(function(){
        $("#add_button").click(function(){
          $('.modal-title').html("Add Subject");
          $('#alert_action').empty();
          $('#data_form')[0].reset();
          $('#action_hidden').val('Add');
          $('#action_submit').val('Save'); 
  });
  $(document).on('submit','#data_form',function(event){
    event.preventDefault(); 
      $.ajax({
        url:"file_action.php",
        method:'POST',
        data:new FormData(this),
        contentType:false,
        processData:false,
        success:function(data){
          $('#form_modal').modal("hide");
          $('#alert_action').fadeIn().html('<div class = "alert alert-success">'+data+'</div>'); 
          dataTable.ajax.reload();
        }
      });
  }); 
   // fetch data from database
    var dataTable = $('#view_table').DataTable({
     "processing" : true,
     "serverSide" : true,
     "order": [[ 0, "desc" ]],
     "ajax" : {
      url:"file_fetch.php",
      type:"POST"   
     },
     "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
    });
 // // Update Section
 $(document).on('click', '.update', function(){
  var id = $(this).attr("id");
  var action_hidden = 'fetch_single';
  $.ajax({
   url:"file_action.php",
   method:"POST",
   data:{id:id, action_hidden:action_hidden},
   dataType:"json",
   success:function(data){
    $('#form_modal').modal('show');
    $('.modal-title').html("Edit Information");    
    $('#type').val(data.type);
    $('#course_id').val(data.course_id);
    $('#title').val(data.title);
    $('#batch').val(data.batch);
    $('#semester').val(data.semester);
    $('#link').val(data.link);
    $('#year').val(data.year);
    $('#duration').val(data.duration);
    $('#num_of_seat').val(data.num_of_seat);
    $('#session_start').val(data.session_start);
    $('#published_date').val(data.published_date);
    $('#file_view').html(data.file);
    $('#id').val(id); // this id go to form id
    $('#action_submit').val('Edit');
    $('#action_hidden').val("Edit");
    $('#alert_action').empty();
   }
  })
 });  

    // view data from Database 
      $(document).on('click', '.view', function(){
          var id = $(this).attr("id");
          var btn_action = 'btn_view';
          $.ajax({
              url:"file_view.php",
              method:"POST",
              data:{id:id, btn_action:btn_action}, // pass variable to $_POST[] method in banwnotevt_view .php
              success:function(data){
                  $('#view_modal').modal('show');
                  $('#view_data_modal').html(data);
              }
          })
      });

  //Active and Inactive Section
   $(document).on('click', '.btn_active_inactive', function(){
  var id = $(this).attr('id');
  var row_status = $(this).data("status"); // fetch status value from $row ['teacher_status']
  var action_hidden = 'active_inactive';
  if(confirm("Are you sure you want to active or inactive this ID?")){
     $.ajax({
      url:"file_action.php",
      method:"POST",
      data:{id:id, row_status:row_status, action_hidden:action_hidden},
      success:function(data){
        $('#alert_action').fadeIn().html('<div class="alert alert-info">'+data+'</div>');
         dataTable.ajax.reload();
      }
     })
  }
  else{
   return false;
  }
 });

 // Delte Section
 $(document).on('click', '.delete', function(){
  var id = $(this).attr("id");
   var action_hidden = 'delete';
  if(confirm("Are you sure you want to delete this item?")){
   $.ajax({
    url:"file_action.php",
    method:"POST",
    data:{id:id,action_hidden:action_hidden},
    success:function(data){
      $('#alert_action').fadeIn().html('<div class="alert alert-danger">'+data+'</div>');
      dataTable.ajax.reload();
    }
   });
  }
  else{
   return false; 
  }
 });

  });
</script>
