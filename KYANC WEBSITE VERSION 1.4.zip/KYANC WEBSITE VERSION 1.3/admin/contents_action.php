<?php
	include 'db_config.php';
	session_start();
	include 'function.php';
	$table="contents";
	if (isset($_POST['action_hidden'])) {
		if ($_POST['action_hidden'] == 'Add') {

				$file = '';
					if($_FILES["file"]["name"] != ''){
					$file = upload_file();
				}

				$query = "INSERT INTO `$table`(`user_id`, `type`, `content_title`, `content`, `file`,`posting_date`) VALUES (:user_id,:type,:content_title,:content,:file,:posting_date)";
				$statement = $pdo_conn->prepare($query);
				$result = $statement->execute(
					array(
	            ':user_id' => $_SESSION["user_id"],
	            ':type' => $_POST["type"],
	            ':content_title' => $_POST["content_title"],
	            ':content' => $_POST["content"],
	            ':file' => $file,
	            ':posting_date' => posting_date()
				));
				$result = $statement->fetchAll();
				if (isset($result)) {
					echo "Data has been saved successfully.";
				}
	     	}	
		}
		//Fetch Data from DB in Modal
		if ($_POST['action_hidden']=='fetch_single') {
			$query = "SELECT * FROM `$table` WHERE id = :id LIMIT 1";
			$statement = $pdo_conn->prepare($query);
			$statement->execute(
				array(':id' => $_POST['id'])
			);
			$result = $statement->fetchAll();
			foreach ($result as $row) {
				$output['type'] = $row['type'];
				$output['content_title'] = $row['content_title'];
				$output['content'] = $row['content'];
				if($row["file"] != ''){
						$output['file'] = '<img src="Files/WebContentsFiles/'.$row["file"].'" class="img-thumbnail" width="50" height="35" /><input type="hidden" name="hidden_image" value="'.$row["file"].'" />';
					}

			}
			echo json_encode($output);
		}
   		// Update Section Action
      if ($_POST['action_hidden'] == 'Edit') {
      		$upload_file ='';
      		$file_row = get_file($pdo_conn,$_POST["id"],$table);
     		if($_FILES["file"]["name"] != '' && $file_row == ''){
     			$upload_file = upload_file();
     		}else if($_FILES["file"]["name"] == '' && $file_row != ''){
     			$upload_file = $file_row;
     		}else if($_FILES["file"]["name"] != '' && $file_row != ''){
     			unlink("Files/WebContentsFiles/" . $file_row);
     			$upload_file = upload_file();
     		}else{
     			$upload_file = $file_row;
     		}

      $query = "UPDATE `$table` SET `user_id`=:user_id,`type`=:type,`content_title`=:content_title,`content`=:content,`file`=:file,`posting_date`=:posting_date WHERE `id`=:id";
      $statement = $pdo_conn->prepare($query);
      $statement->execute(
         array(
          ':id' => $_POST['id'],
	      ':user_id' => $_SESSION["user_id"],
	      ':type' => $_POST['type'],
	      ':content_title' => $_POST['content_title'],
	      ':content' => $_POST['content'],
          ':file' => $upload_file,
	      ':posting_date' => posting_date()
       ));
      		$result = $statement->fetchAll();
      		if (isset($result)) {
        		echo "Data has been edited.";
      		}
    	}
  // Change Status Data from DB
    if ($_POST['action_hidden']=='active_inactive') {
      $status = 'active';
      if ($_POST['id_status']=='active') {
        $status = 'inactive';
      }
      $query = "UPDATE $table SET id_status = :id_status WHERE id = :id";
      $statement = $pdo_conn->prepare($query);
      $statement->execute(
         array(
          ':id_status' => $status,
          ':id'  => $_POST['id']
         )
        );
      $result = $statement->fetchAll();
      if ($status == 'active') {
      	$status_result = '<span class="badge badge-success">Actived</span>';
      }else{
      	$status_result = '<span class="badge badge-danger">Inactived</span>';
      }
      if(isset($result)){
        echo 'Item Status has been '.$status_result;
      }
    } 
    		// Delete Section Action
	if($_POST["action_hidden"] == 'delete'){
		$file = get_file($pdo_conn,$_POST["id"],$table);
		if($file != '')
		{
			unlink("Files/WebContentsFiles/" . $file);
		}		
		$query = "DELETE FROM $table WHERE id = :id";	
		 $statement = $pdo_conn->prepare($query);
		 $result = $statement->execute(
		  array(
		   ':id' => $_POST["id"]
		  ));
		 	if (isset($result)) {
				echo "Data has been deleted.";
			}
	   }

?>		