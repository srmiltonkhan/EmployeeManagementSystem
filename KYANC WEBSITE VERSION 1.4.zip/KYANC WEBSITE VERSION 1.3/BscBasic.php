<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
	<div class="text-center mt-4">
		<h4>B.sc in Nursing (Basic)</h4>
		<hr class="w-75 mx-auto">
	</div>
	<div class="row">
		<?php $webContentsClass->courses(); ?>
		<div class="col-sm-9">
			<ul class="p-3">
				<li class="p-2">The candidates must have passed SSC and HSC within 2 years from Science group with Biology.</li>
				<li class="p-2">The candidates must ave a cumulative GPA(Both SSC & HSC) total 7.00 but not less than GPA 3.00 in either SSC or HSC Examination.</li>
			</ul>
			<br>
		</div>
	</div>
	<div class="text-center mt-4">
		<h4>Subject of B.sc in Nursing (Basic)</h4>
		<hr class="w-75 mx-auto">
	</div>
<?php
$table="subjects";
$column = '
<th width="10%">SL</th>
<th width="20%">Subject Code</th>
<th width="80%">Subject Name</th>
';

$query = "SELECT * FROM $table WHERE course_id='1' AND year_type = 'FirstYear' and id_status='active' ORDER BY serial_number ASC";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$subject = '';
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
    $subject .='<tr>'.     
                '<td>'.$row['serial_number'].'</td>'.
                '<td>'.$row['subject_code'].'</td>'.
                '<td>'.$row['subject_name'].'</td>'
              .'</tr>';
   }  
 }   
$subjectRslt =  $subject;
?>	
	<div class="table-responsive FirstYear w-75 mx-auto">
		<div class="text-center"><h4 class="text-primary">First Year</h4></div>
		<table class="table table-sm table-bordered">
			<thead>
				<?php echo $column;?>
			</thead>
			<tbody>
				<?php echo $subjectRslt;?>
			</tbody>
		</table>
	</div>




<?php
$query = "SELECT * FROM $table WHERE course_id='1' AND year_type = 'SecondYear' and id_status = 'active' ORDER BY serial_number ASC";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$subject = '';
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
    $subject .='<tr>'.     
                '<td>'.$row['serial_number'].'</td>'.
                '<td>'.$row['subject_code'].'</td>'.
                '<td>'.$row['subject_name'].'</td>'
              .'</tr>';
   }  
 }   
$subjectRslt =  $subject;
?>	
	<div class="table-responsive SecondYear w-75 mx-auto">
		<div class="text-center"><h4 class="text-primary">Second Year</h4></div>
		<table class="table table-sm table-bordered">
			<thead>
				<?php echo $column;?>
			</thead>
			<tbody>
				<?php echo $subjectRslt;?>
			</tbody>
		</table>
	</div>



<?php
$query = "SELECT * FROM $table WHERE course_id='1' AND year_type = 'ThirdYear' and id_status = 'active' ORDER BY serial_number ASC";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$subject = '';
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
    $subject .='<tr>'.     
                '<td>'.$row['serial_number'].'</td>'.
                '<td>'.$row['subject_code'].'</td>'.
                '<td>'.$row['subject_name'].'</td>'
              .'</tr>';
   }  
 }   
$subjectRslt =  $subject;
?>	
	<div class="table-responsive SecondYear w-75 mx-auto">
		<div class="text-center"><h4 class="text-primary">Third Year</h4></div>
		<table class="table table-sm table-bordered">
			<thead>
				<?php echo $column;?>
			</thead>
			<tbody>
				<?php echo $subjectRslt;?>
			</tbody>
		</table>
	</div>



	<?php
$query = "SELECT * FROM $table WHERE course_id='1' AND year_type = 'FourthYear' and id_status = 'active' ORDER BY serial_number ASC";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$subject = '';
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
    $subject .='<tr>'.     
                '<td>'.$row['serial_number'].'</td>'.
                '<td>'.$row['subject_code'].'</td>'.
                '<td>'.$row['subject_name'].'</td>'
              .'</tr>';
   }  
 }   
$subjectRslt =  $subject;
?>	
	<div class="table-responsive SecondYear w-75 mx-auto">
		<div class="text-center"><h4 class="text-primary">Fourth Year</h4></div>
		<table class="table table-sm table-bordered">
			<thead>
				<?php echo $column;?>
			</thead>
			<tbody>
				<?php echo $subjectRslt;?>
			</tbody>
		</table>
	</div>
<?php $webContentsClass->footerSection();?>

