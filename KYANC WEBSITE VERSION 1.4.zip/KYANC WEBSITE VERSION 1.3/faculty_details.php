<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
  <?php
  if (isset($_GET['id'])) {
    $query = "SELECT * FROM facultystaff WHERE id = '".$_GET['id']."'";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
  if($rowCount > 0){
    foreach ($stat->fetchAll() as $row) {
      $name = $row['name'];
      $file = $row['file'];
      $designation = $row['designation'];
      $short_biography = $row['short_biography'];
      $research_interest = $row['research_interest'];
      $research_and_publication = $row['research_and_publication'];
      $academic_info = $row['academic_info'];
      $experience = $row['experience'];
      $mobile = $row['mobile'];
      $email = $row['email'];
    }
  }else{
    echo "No";
  }
  }
  ?>
  <div class="w-90 mx-auto p-3 shadow-sm rounded">
	  <div class="row">
	  	<div class="col-sm-3 border p-3">
	  		<img src="admin/Files/WebContentsFiles/<?php echo $file;?>" alt="Profile Picture doesn't be found" class="mx-auto d-block img-thumbnail" width="180">
	  		<div class="text-center">
		   		<p class="font-weight-bold"><?php echo $name;?></p>
		  		<p><?php echo $designation;?></p> 			
	  		</div>
	  	</div>
	   	<div class="col-sm-9 border p-3">
	  		<div class=""><h3 class="text-secondary">PROFILE</h3></div>
	  		<hr>
	  		<div><h5 class="font-weight-bold">SHORT BIOGRAPHY</h5></div>
	  		<div><h5 style="line-height: 1.5;"class="text-justify"><?php echo $short_biography;?></h5></div>

	  		<div class="mt-4"><h5 class="font-weight-bold">RESEARCH INTEREST</h5></div>
	  		<div><h5 style="line-height: 1.5;" class="text-justify"><?php echo $research_interest;?></h5></div>
	  	</div>
	  	</div>

<div class="row mt-5">
        <div class="col-md-12">
            <ul id="tabs" class="nav nav-tabs">
                <li class="nav-item"><a href="" data-target="#tab-pane-1" data-toggle="tab" class="nav-link small text-uppercase active"><i class="fas fa-journal-whills text-success"></i> RESEARCH & PUBLICATION</a></li>
                <li class="nav-item"><a href="" data-target="#tab-pane-2" data-toggle="tab" class="nav-link small text-uppercase"><i class="fas fa-user-graduate text-success"></i> Academic Info</a></li>
                <li class="nav-item"><a href="" data-target="#tab-pane-3" data-toggle="tab" class="nav-link small text-uppercase"><i class="fas fa-birthday-cake text-success"></i> Experience</a></li>
                <li class="nav-item"><a href="" data-target="#tab-pane-4" data-toggle="tab" class="nav-link small text-uppercase"><i class="fas fa-address-card text-success"></i> CONTACT INFO</a></li>                
            </ul>
            <br>
            <div id="tabsContent" class="tab-content">
                <div id="tab-pane-1" class="tab-pane fade active show">
                   <h5><?php echo $research_and_publication;?></h5>
                </div>
                <div id="tab-pane-2" class="tab-pane fade">
                   <h5><?php echo $academic_info;?></h5>
                </div>
                <div id="tab-pane-3" class="tab-pane fade">
                    <h5><?php echo $experience;?></h5>
                </div>
                <div id="tab-pane-4" class="tab-pane fade">
                   <h5>Mobile: <?php echo $mobile;?></h5>
                   <h5>Email: <?php echo $email;?></h5>
                </div>                
            </div>
        </div>
    </div>
    	  	
	  </div>
<?php $webContentsClass->footerSection();?>