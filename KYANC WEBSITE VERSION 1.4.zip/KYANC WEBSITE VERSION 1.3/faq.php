<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
  <div class="text-center mt-4">
	  <h4 class="text-uppercase">Frequently Asked Questions (FAQ)</h4>
	    <hr class="w-75 mx-auto">
  </div>
  <div class="faq mx-auto w-75 mb-4 text-justify">
  	  <p class="font-weight-bold"><i class="fas fa-check-square text-success"></i> What is nursing ?</p>
  	  <br>
  	  <p>Nursing is a profession that deals with public health care and health awareness activities. This profession emphasizes on the importance of restoring the health and well-being of a patient or person personally, family or socially.</p>
  	  <br>
  	  <p class="font-weight-bold"><i class="fas fa-check-square text-success"></i> Why should one study Nursing?</p>
  	  <br>
  	  <p>After passing the high school, many of the students are all frustrated and worried about where we will they get admitted and which subject will they study in. most of them can’t make any fixed decisions and start buying all the university’s forms as usual and take exams from one end of the country to the other like crazy horses. As a result, except for a small number, everyone has to return empty-handed. A good number of students feel frustrated as they wonder if they will be able to face family and friends because they failed to get admitted in Public universities. Instead of talking it out some stop communicating regarding their issues. But at this time, if we give the right guidance to our students, they can each develop into a successful person by studying in their desired subject. Most of us don’t know if we will get a job related to the subject we are studying in, but there are some subjects that if you study in the subjects you can build a global career worldwide. Nursing is just the right path for those who want to work for the betterment of humanity, And that is possible by studying for a Diploma / B.Sc in Nursing, above all nursing is a profession whose needs are not limited.</p> 
  	  <br>
  	  <p class="font-weight-bold"><i class="fas fa-check-square text-success"></i> Why is Nursing a great profession?</p>	
  	  <br>
  	  <p>Nowadays nursing is quite popular as a profession. If you are determined to study nursing, I would say that you have made the right decision. A nurse engages herself in various medical services alongside with the doctor. Nurses heal a patient with their care. A nurse bears all the responsibilities of a patient as per the doctor’s advice. From giving medicines, feeding the patient and to patients to providing various services in the field of treatment with proper dedication as long as the patient is hospitalized, a nurse performs her service duties.</p> 
  	  <br>
  	  <p class="font-weight-bold"><i class="fas fa-check-square text-success"></i> What scopes of jobs are there for nursing students?</p> 
  	  <br>  
  	  <p>There are job opportunities for nurses in all government and private hospitals, clinics, community health care centers, urban maternity hospitals, diagnostic centers and other healthcare institutions. The number of private hospitals and clinics is increasing along with the government hospitals to ensure the health care of the large population of the country. The number of nurses is much less than the demand. In addition to clinical nursing, there are opportunities to work in various administrative positions in the Department of Nursing and Midwifery of the Ministry of Health and Family Welfare, Government of the People’s Republic of Bangladesh for government hospital and service activities and administrative management. These posts are for 1st class government officials:</p>	
  	  <br>
  	  <p>1. Director General</p>  
  	  <p>2. Director (Administration)</p>  
  	  <p>3. Director (Nursing Education)</p>  
  	  <p>4. irector (Midwifery Education)</p>  
  	  <p>5. Director (Discipline)</p>  
  	  <p>6. Deputy Director (Administration, Nursing Education, Midwifery Education, Discipline)</p>  
  	  <p>7. Assistant Director (Administration, Nursing Education, Midwifery Education, Discipline)</p>  
  	  <p>8. Divisional Director Nursing (6 Divisional Offices)</p>  
  	  <p>9. District Public Health Nurses (64 District Civil Surgeon Offices)</p>  
  </div>

<?php $webContentsClass->footerSection();?>