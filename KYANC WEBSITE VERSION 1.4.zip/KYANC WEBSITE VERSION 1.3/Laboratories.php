<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
<div class="row w-90 mx-auto">

<?php $webContentsClass->facility(); ?>
<?php
$query = "SELECT * FROM contents WHERE type = 'LaboratoryFacility' and id_status = 'active' ORDER BY id";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$laboratories = '';
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row){ 
	    	$laboratories .= '<div class="col-sm-6">
			    <div class="fundLab mx-auto">
			    	<img src="admin/Files/WebContentsFiles/'.$row['file'].'">
			    </div>
			    <div class="border p-3 mt-2 lab text-center mb-2">'.$row['content_title'].'</div>	    		
	    	</div>';
     }
}
?>

  <div class="col-sm-9">
	     <div class="text-center mt-4">
	      <h4>Practical Laboratories Facility</h4>
	          <hr class="w-75 mx-auto">
	    </div>
	    <div class="mx-auto mt-2 p-4 mb-2">
	    	<p>Modern and well equipped 7 (seven) practical laboratories are located in the first floor of the college building. A large well-equipped demonstration practical laboratory.</p>
	    </div>
	    <div class="row">
	    	<?php echo $laboratories;?>
  		</div>	
  </div>	
</div>
<?php $webContentsClass->footerSection();?>

