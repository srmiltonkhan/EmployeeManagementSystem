-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 05, 2021 at 12:45 PM
-- Server version: 5.6.51
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kyan1edu_newkyanc`
--

-- --------------------------------------------------------

--
-- Table structure for table `authority`
--

CREATE TABLE `authority` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `authority_type` varchar(30) NOT NULL,
  `name` varchar(80) DEFAULT NULL,
  `file` varchar(50) DEFAULT NULL,
  `designation` varchar(50) NOT NULL,
  `quotes` text,
  `messeage` text,
  `id_status` enum('active','inactive') NOT NULL,
  `posting_date` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `authority`
--

INSERT INTO `authority` (`id`, `user_id`, `authority_type`, `name`, `file`, `designation`, `quotes`, `messeage`, `id_status`, `posting_date`) VALUES
(1, 1, 'Founder', 'DR. MIR. MOHAMMAD AMJAD HUSSAIN', '20210823025826.jpg', 'Honourable Founder Chairman', 'Students who aspire to be nurses should possess nature of a caring mother while caring for patients in his/her day-to-day work life              ', '<p>An intuitive, untiring and compassionate personality, Dr. M. M. Amjad Hussain was born on 01 October 1925 in their native village, Enayetpur in the district of Sirajganj. He had completed his primary education from local Madrasa. He completed his secondary education at the Sthal Pakrashi Uchcha Vidyalay (high school). After successfully passing the Matriculation Examination in 1941, he got himself admitted into the Rajshahi College and obtained his Intermediate of Science certificate in 1943. Then he went to Kolkata to study medicine and was successfully enrolled himself into Kolkata Medical College. He graduated in medicine in 1948. Having awarded the degree in Bachelor of Medicine, he joined the Pakistan Army in its Medical Corps at the rank of Captain in 1952.</p><br>\r\n<p>After serving the Army for three years, he took self-retirement and turned out to be an entrepreneur. The Kapok Mills was established in 1955 in Chittagong and export of Kapok fiber to the United States of America.  Very soon, he established Al-Haj Cotton Mills at Ishwardi of Pabna in 1962. Following to it, the Al-Haj Jute Mills was then established in 1967 at Sarishabari of Jamalpur District. He was almost immediately elected Chairman of the Bangladesh Textile Mills Association.  In 1982, he established Drug International Limited pharmaceutical company, In 1994, he established an IT firm (Advance Technology and Innovation Ltd.(ATI). Afterwards, ATI Ceramics Ltd was launched in 2004 to make floor and wall tiles. This is one of the tiles factory company in Bangladesh. In addition, he became interested towards contributing to the development of tea industry in Bangladesh, he established M. M. Tea Estate Ltd. in Panchagarh district.  In 2006, he established M. M. Multi Fibers Ltd. As an entrepreneur of group of companies, he was a highest tax payer, he was nominated as Commercially Important Person (CIP) by the Ministry of Industries of the Bangladesh Government.</p><br>\r\n <p>Above and beyond of his being a pioneer in entrepreneur in many fields of trade and business, Dr. M. M. Amjad Hussain concentrated his strength and faculty towards helping the humanity. Realizing the importance of womenâ€™s empowerment, he thought of creating opportunities for womenâ€™s education and he established a girlsâ€™ school, Meher Un Nessa Girls High School in Enayetpur. For providing proper and modern health facilities, he established a non-profit hospital in the Enayetpur by the name of his Spiritual Leader (Peer) Hajrat Khwaja Yunus Ali (R).</p><br>\r\n  <p>In the same campus of approximately ninety acres of land, he established a 500 plus bed hospital, manned with specialists doctors, trained nurses along with utilization of modern equipment, the hospital is able to provide healthcare and treatment of all kinds of diseases including Cancer. The hospital is also equipped with instruments and trained hands like doctors, nurses and all other facilities to undertake cardiac thoracic surgery almost every week. A Medical College was founded to produce medical graduate at a private institution level that was able to attract students from home and abroad. Beside the Medical College, a Nursing College was established to produce skilled human resources for the demanding profession like, the nursing. A school-cum-college was brought into existence to facilitate childrenâ€™s education of those living inside the campus and the public living in the villages adjacent to it. The school is functioning with the national curricula of English version. Dr. M. M. Amjad Hussain had not stopped his journey until he could complete founding a World Class University at Enayetpur.</p><br>\r\n <p>This extra ordinarily brilliant, disciplined, educated, honest, and patriot person passed away on 11 September, 2012. May Allah bless his soul with eternal peace in Jannah.</p>    ', 'active', '11:48:15 AM, 03-Sep-2021'),
(2, 1, 'Chairman', 'M.A. HAIDER HUSSAIN', '20210924084513.jpg', 'Chairman, Board of Trustee.', '                    ', '<p class=\"text-justify\">This is truly a matter of immense pleasure to see the gradual development of Khwaja Yunus Ali Nursing College, which was a vision of our Founder Chairman Dr. M. M. Amjad Hussain to serve the society and empower the women of Bangladesh. May ALLAH(swt) grant him Jannah and help us to move forward serving the humanity. Nursing as a profession has a bright future not only in Bangladesh, but also practiced globally enhancing the honorable status of living.<p>\r\n<br>\r\n<p class=\"text-justify\">We provide all the facilities with modern technological support and better teaching media which will build them to grow there educational platform and follow the rules and regulation of the institution to become a skilled nurse of 21\' century.</p> \r\n<br>\r\n<p>May ALLAH(swt) accept all of our determined attempt.</p> ', 'active', '10:27:17 AM, 05-Oct-2021'),
(3, 1, 'DSK', 'MOHAMMAD YUSUF', '20210823025808.jpg', 'Director, Board of Trustee, KYAMCH', '                    ', ' <p>Very few people can materialize their dreams. My father, Dr. M. M. Amjad Hussain is the Founder of Khwaja Yunus Ali Nursing College . His dream was to provide excellent healthcare service and opportunity for the rural people specially for the women in this country. To materialize that he established Khwaja Yunus Ali Nursing College. The purpose of Khwaja Yunus Ali Nursing College is to train dedicated persons to manage, run and provide health care service.</p><br>\r\n        <p>My father struggled to bring success for other people where most of the people struggle for their own success. We are very keen to provide all facilities necessary for appropriate learning of modern nursing under the guidance of good teachers at Khwaja Yunus Ali Nursing College. We are following our father\'s dream to create skilled nurses with a good soul to serve the humanity. May Allah make it easy for us to move forward and to get success for Khwaja Yunus Ali Nursing College in future.</p>\r\n   ', 'active', '11:26:17 AM, 03-Sep-2021'),
(4, 1, 'DOK', 'Dr. Rubaiyat Farzana Hussain', '20210823025758.jpg', 'Director of KYAMCH', '                    ', '          ', 'active', '11:48:37 AM, 03-Sep-2021'),
(5, 1, 'Principal', 'Rowshonara Khatun', '20210823025737.jpg', 'Principal of KYANC', '                    ', '<p>This is the high time for young men and women to enter the profession of nursing. Day by day the demand for quality nurses is increasing and the opportunities for nursing profession are practically unlimited both in our country and abroad. In addition, it is such a profession that gives one the spiritual satisfaction that comes from providing nursing services to patients, families and communities.</p><br>\r\n        <p>At present there are both \"Diploma\" and \"B.Sc\" (Post Basic) in nursing courses in Bangladesh and after completion of these courses one can engaged oneself in varieties working field like critical care, neighborhood clinics, surgery, pediatrics or emergency rooms or so on like these. It is known that, a strong education is the foundation for any professional success</p><br>	\r\n  <p>That is why Khwaja Yunus Ali Nursing College ensures an excellent start for the lucrative nursing career. Khwaja Yunus Ali Nursing College has an ideal learning environment that helps to create ideal, energetic and quality nurses. The students of Khwaja Yunus Ali Nursing College are also being benefitted.</p><br>\r\n        <p>The committed faculty who are expert clinicians, teachers and mentors. The strong clinical program with experiences in diverse health care settings. The innovative and rich nursing curriculum with a community focus that reflects the best practices in an ever changing health care environment. The culture of respect and professionalism based on the KYANC tradition of service and commitment to its students and community.</p><br>\r\n        <p>The High-tech learning labs with the latest in teaching tools as well as sophisticated technology. Nurse is the on of the most important and key elements for the health care services. To manage as well as to run the nursing services smoothly quality nurses is a must. But unfortunately there is a huge lack of quality manpower in this sector both in home and abroad.</p>\r\n        <p>So, if you want to get the opportunity of a nice career, choose nursing. Take the chance of working within the country and abroad. Change your lifestyle by handsome earnings, live with honor, and play an important role in economy. Don\'t waste your time and let\'s start now. I invite you at Khwaja Yunus Ali Nursing College to become a quality nurse.</p><br>                    ', 'active', '11:52:02 AM, 03-Sep-2021');

-- --------------------------------------------------------

--
-- Table structure for table `awprojectjournal`
--

CREATE TABLE `awprojectjournal` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(70) NOT NULL,
  `serial_number` int(5) NOT NULL,
  `title` varchar(70) DEFAULT NULL,
  `details` text,
  `file` varchar(50) DEFAULT NULL,
  `link` text,
  `id_status` enum('active','inactive') NOT NULL,
  `award_date` varchar(30) NOT NULL,
  `posting_date` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `awprojectjournal`
--

INSERT INTO `awprojectjournal` (`id`, `user_id`, `type`, `serial_number`, `title`, `details`, `file`, `link`, `id_status`, `award_date`, `posting_date`) VALUES
(6, 2, 'AwardAchievement', 2, 'B.Sc in Nursing (post Basic)', '                  ', '20210927091442.jpg', '', 'active', '', '03:14:42 PM, 27-Sep-2021'),
(10, 2, 'AwardAchievement', 1, 'Diploma in Nursing Science & Midwifery', 'Take Place in Merit list Diploma in Nursing Science & Midwifery BNMC exam Students with Founder Dr. M.M.Amjad Hussain.', '20210824105554.jpg', '', 'active', '', '01:22:58 PM, 24-Sep-2021'),
(13, 1, 'Journal', 3, 'KYANC JOURNAL, Vol-2, Number- 1, January 2021	', '', '', '', 'active', '', '03:00:34 PM, 29-Aug-2021'),
(14, 1, 'Journal', 2, 'KYANC JOURNAL, Vol-1, Number- 1, January -2020 ', '', '', '', 'active', '', '02:55:00 PM, 31-Aug-2021'),
(16, 2, 'AwardAchievement', 3, 'B.Sc in Nursing (post Basic)', '', '20210927091540.jpg', '', 'active', '', '03:15:40 PM, 27-Sep-2021');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `contactID` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `contactType` varchar(30) NOT NULL,
  `DepartmentOffice` varchar(100) DEFAULT NULL,
  `Mobile` varchar(15) DEFAULT NULL,
  `WhatsApp` varchar(15) DEFAULT NULL,
  `Phone` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Fax` varchar(20) DEFAULT NULL,
  `ContactStatus` enum('active','inactive') DEFAULT NULL,
  `ContactDate` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`contactID`, `user_id`, `contactType`, `DepartmentOffice`, `Mobile`, `WhatsApp`, `Phone`, `Email`, `Fax`, `ContactStatus`, `ContactDate`) VALUES
(1, 1, 'ContactPage', 'Office of the Principal PS', '+8801915477962 ', '+8801915477962 ', '+880 751 63761-4', 'kyanc2013@gmail.com', '+880 247318040', 'active', '');

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE `contents` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(30) NOT NULL,
  `content_title` varchar(80) DEFAULT NULL,
  `content` text,
  `file` varchar(60) DEFAULT NULL,
  `id_status` enum('active','inactive') NOT NULL,
  `posting_date` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contents`
--

INSERT INTO `contents` (`id`, `user_id`, `type`, `content_title`, `content`, `file`, `id_status`, `posting_date`) VALUES
(3, 2, 'HostelRules', 'Rules for Hostel ', '<div class=\"w-75 mx-auto p-4 border m-4\" style=\"line-height: 1.5;\">\r\n  <h5 class=\"font-weight-bold\">Hostel Rules</h5>\r\n  <hr>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Khwaja Yunus Ali Nursing College is a residential college but it is not mandatory for all students studying at KYANC to stay at Girls hostel/female dormitories.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> No students are allowed to leave the hostel/dormitories without the permission of the hostel authority. For the safety of the students, they are not permitted to go outside the hall/dormitories after 6:00 PM.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> It is prohibited to move here and there in the campus after the certain allocated time.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> In any case of serious illness the hostel authority or the Principal should be reported through the housekeeper at once.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> To keep the environment of the campus clean and beautiful and for the sake of health issue everyoneâ€™s room should be neat and clean properly. Each resident student is responsible for the cleanliness and good upkeep of the room allotted to her.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> No visitors including father, brother, sister and friends is allowed to go or stay inside the hostel at night. Only studentâ€™s mother may go inside the hostel with the permission of housekeeper for some emergency cases but canâ€™t stay at night.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Meals (breakfast, lunch, and dinner) should be taken in time at the dining hall.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Any sort of cooking is strongly prohibited inside the room or in any place of the hall. Electric stoves, room hitter is not allowed to be used.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Hostel authorities will not be responsible for any loss of money, jewelry or personal belongings of any student. Students are advised not to keep any cash/jewelry or any costly items in the room.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Personal TV, fridge, pets must be prohibited in the hostel.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Any misleading or false statement or information in the application form shall render the admission for termination and on such termination students shall stay at hostel.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> It is the duty of the students to keep their room, toilet and bathroom neat and clean and donâ€™t put the sanitary napkin, cotton etc in the commode; put them into the dustbin. </h5>\r\n <h5><i class=\"fas fa-check-square text-success\"></i> Donâ€™t throw anything like paper, wastage, shampoo, chocolate, chips â€˜packet through the window, grill or anywhere else rather put them into the dustbin.</h5>\r\n <h5><i class=\"fas fa-check-square text-success\"></i> Donâ€™t do any sort of activities like watching TV, talking and singing loud that disturbs others.</h5>\r\n <h5><i class=\"fas fa-check-square text-success\"></i> Without the permission of authority or housekeeper students are not allowed to interchange of furniture/fixture or anything from her room to outside or to another room.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> They canâ€™t use othersâ€™ instruments without permission.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i>To stay at night outside the hostel is absolutely prohibited. If someone is accused for doing so her seat will be cancelled without any notice.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> Behave friendly with the roommate. Sick reporting is necessary if you are sick. If the movement of your roommate is unusual than report to the housekeeper or hostel authority.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> All the rules stated above may be changed or some new rules may be added according to the necessity of the institution. </h5>\r\n\r\n</div>\r\n', '20210830055140', 'active', '04:00:02 PM, 27-Sep-2021'),
(4, 1, 'LibraryRules', 'Rules for Library', '<div class=\"w-75 mx-auto p-4 border m-4\" style=\"line-height: 1.5;\">\r\n  <h5 class=\"font-weight-bold\">General Rule</h5>\r\n  <hr>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Use of library card signed by the Principal to gain entrance into the library</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> No books or other library materials shall be taken out of the library without following the borrowing procedures.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Make sure to return the borrowed books in time</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Strict silence, decorum and discipline must be maintained in the library. Use of mobile phone is not allowed.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Smoking, eating, sleeping and talking loudly are strictly prohibited in the library.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Readers should not mark, underline, write, tear pages or otherwise damage the library documents.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Newspapers, magazines and journals must be read only in the library on specific tables and should not be taken to any other reading areas.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> No library material can be taken out of the library without permission. Unauthorized removal of anything belonging to the library will be treated as theft and dealt accordingly.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Anyone  who  violates  the  rules  and  regulations  of  the  library  would  be  liable  to  lose  the privilege  of  library membership and may be debarred from using the library facilities.</h5>\r\n</div>\r\n\r\n<div class=\"w-75 mx-auto p-4 border m-4\">\r\n  <h5 class=\"font-weight-bold\">Library Membership</h5>\r\n  <hr>\r\n  <h5>All faculty, and students of the institute are entitled to become library members and membership is allowed only after submitting a duly filled in and signed membership form. The members are supposed to be conversant with and agreeable to the Library rules.</h5>\r\n </div> \r\n\r\n <div class=\"w-75 mx-auto p-4 border m-4\">\r\n  <h5 class=\"font-weight-bold\">Issue/Return Rules</h5>\r\n  <hr>\r\n   <h5><i class=\"fas fa-check-square text-success\"></i> Books may be kept for 2 weeks.</h5>\r\n   <h5><i class=\"fas fa-check-square text-success\"></i> Borrowers will remain responsible for any loss or damage to books issued them</h5>\r\n   <h5><i class=\"fas fa-check-square text-success\"></i> Reference books are to be used only in library.</h5>\r\n   <h5><i class=\"fas fa-check-square text-success\"></i> No books shall be taken from library without proper entry in Borrowerâ€™s card.</h5>\r\n   <h5><i class=\"fas fa-check-square text-success\"></i> Ordinarily only 3 books will be issued.</h5>\r\n   <h5><i class=\"fas fa-check-square text-success\"></i> Borrowers are requested to check their cards during their books returning time. </h5>\r\n </div> \r\n\r\n<div class=\"w-75 mx-auto p-4 border m-4\">\r\n  <h5 class=\"font-weight-bold\">Fine for late return books/journals</h5>\r\n  <hr>\r\n  <h5>A fine of 5 (five) taka per day per book will be charged from the defaulting members. The collected fine will be deposited in accounts section and proper receipt will be provided to the member. Membership to the newcomers will be given against request and recommendation by the competent authority like office order etc. User(s) has to return all issued books when he/ she is out of station for more than fifteen days.</h5>\r\n </div> \r\n\r\n\r\n<div class=\"w-75 mx-auto p-4 border m-4\">\r\n  <h5 class=\"font-weight-bold\">Renewal of books</h5>\r\n  <hr>\r\n <div>Users can also renew the books again after the completion of charging period, subject to not being requested from some other user.</div>\r\n<br>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> A large library with sufficient seating capacity and books, journals of different disciplines and\r\ninternet facilities are available.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> </h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> </h5>\r\n </div>', '', 'active', '10:37:27 AM, 05-Oct-2021'),
(5, 1, 'IDCard', 'ID CARD RULES', '<div class=\"w-75 mx-auto p-4 border m-4\">\r\n  <h5 class=\"font-weight-bold\">ID CARD Rules</h5>\r\n  <hr>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i></h5>\r\n</div>', '', 'active', '12:29:30 PM, 30-Aug-2021'),
(6, 1, 'CollegeDressCode', 'Dress Code', '<div class=\"w-75 mx-auto p-4 border m-4\">\r\n  <h5 class=\"font-weight-bold\">DRESS CODE</h5>\r\n  <hr>\r\n  <h5 style=\"line-height: 1.5;\"><i class=\"fas fa-check-square text-success\"></i> According to the DG. Nursing, The dress code for female nursing students consists of olive colour kameez, cross belt, cap and black salwar. Male students were directed to wear olive colour shirt, black trousers and black shoes.</h5>\r\n  <h5 style=\"line-height: 1.5;\"><i class=\"fas fa-check-square text-success\"></i> Dress codes are standard practice in many professions. In nursing, however, how nurses dress can influence patient care and satisfaction. Since insurance reimbursements now rely heavily on quality-of-care metrics, dress codes matter more than ever.</h5>\r\n</div>', '20210830063600.jpg', 'active', '02:19:20 PM, 30-Aug-2021'),
(7, 1, 'CulturalClub', 'Cultural Club', '<div class=\"w-75 mx-auto p-4 border m-4 \" style=\"line-height: 1.5;\">\r\n  <h5 class=\"font-weight-bold\">Cultural Club</h5>\r\n  <hr>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> All national and international days are observed accordingly by the college with the celebration of different cultural programs under the cultural club of the institution.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Every year the institution arranges Study tour for the students.</h5>\r\n </div> ', '', 'active', '02:16:33 PM, 30-Aug-2021'),
(8, 1, 'Sports', 'Sports', '<div class=\"w-75 mx-auto p-4 border m-4 text-justify\">\r\n  <h5 class=\"font-weight-bold\">Sports</h5>\r\n  <hr>\r\n  <h5 style=\"line-height: 1.5;\">To keep the body healthy sports are very important. Also, it is an important factor in our education. Most probably KYANC is the only private nursing institution in Bangladesh having such a big play ground for outdoor sports with the facilities of playing different games like basketball, badminton, volleyball etc. It has also the opportunity to play indoor games like carom, table-tennis, chess etc.</h5>\r\n</div>', '', 'active', '02:16:11 PM, 30-Aug-2021'),
(9, 1, 'BloodDClub', 'Blood Donation Club', '<div class=\"w-75 mx-auto p-4 border m-4 text-justify\">\r\n  <h5 class=\"font-weight-bold\">Blood Donation Club</h5>\r\n  <hr>\r\n  \r\n</div>', '20210908081639.JPG', 'active', '02:16:39 PM, 08-Sep-2021'),
(10, 1, 'LanguageClub', 'Language Club', '<div class=\"w-75 mx-auto p-4 border m-4 text-justify\">\r\n  <h5 class=\"font-weight-bold\">Language Club</h5>\r\n  <hr>\r\n  \r\n</div>', '', 'active', '12:54:00 PM, 30-Aug-2021'),
(11, 1, 'Debating', 'Debating Club', '<div class=\"w-75 mx-auto p-4 border m-4 text-justify\">\r\n  <h5 class=\"font-weight-bold\">Debating Club</h5>\r\n  <hr>\r\n  \r\n</div>', '', 'active', '12:56:20 PM, 30-Aug-2021'),
(12, 1, 'HostelFacility', 'Hostel / Accommodation Facility', '<div class=\"mx-auto p-4 border m-4 text-justify\">\r\n  <h5 class=\"font-weight-bold\">Hostel Facility</h5>\r\n  <hr>\r\n  <h5 style=\"line-height: 1.5;\"><i class=\"fas fa-check-square text-success\"></i> Safe and quiet place.</h5>\r\n  <h5 style=\"line-height: 1.5;\"><i class=\"fas fa-check-square text-success\"></i>  	Very homely stay.</h5>\r\n <h5 style=\"line-height: 1.5;\"><i class=\"fas fa-check-square text-success\"></i> Comfortable and well-lit rooms.</h5>\r\n <h5 style=\"line-height: 1.5;\"><i class=\"fas fa-check-square text-success\"></i>  	Allotment of seats is done on the first come first serve basis. </h5>\r\n <h5 style=\"line-height: 1.5;\"><i class=\"fas fa-check-square text-success\"></i>  	Secure accommodation in a well-equipped campus building.</h5>\r\n <h5 style=\"line-height: 1.5;\"><i class=\"fas fa-check-square text-success\"></i>  	24 hours electricity facility.</h5>\r\n <h5 style=\"line-height: 1.5;\"><i class=\"fas fa-check-square text-success\"></i>  	Purified water facility by self water purification plant.</h5>\r\n <h5 style=\"line-height: 1.5;\"><i class=\"fas fa-check-square text-success\"></i>  	Common lounge with television and refrigerator.</h5>\r\n <h5 style=\"line-height: 1.5;\"><i class=\"fas fa-check-square text-success\"></i>  	Common kitchen and functioning near the hostel.</h5>\r\n <h5 style=\"line-height: 1.5;\"><i class=\"fas fa-check-square text-success\"></i>  	Shared and separate toilets. </h5>\r\n <h5 style=\"line-height: 1.5;\"><i class=\"fas fa-check-square text-success\"></i>  	However, hostel accommodation for Students will be provided as long as the seats are available. </h5>\r\n</div>', '20210830082323.jpg', 'active', '02:13:35 PM, 08-Sep-2021'),
(13, 1, 'LibraryFacility', 'Library Facility', '<div class=\"mx-auto p-4 border m-4 text-justify\">\r\n  <h5 class=\"font-weight-bold\">Library Facility</h5>\r\n  <hr>\r\n  <h5 style=\"line-height: 1.5;\">KhwajaYunus Ali Nursing college has an excellent library with a vastarray of books from reputated authors of National and International lavel in medical Sciences, Latest health related magazines, available for reference. The Library also has broadband internet facilities.</h5>\r\n</div>', '20210830082848.jpg', 'active', '02:28:48 PM, 30-Aug-2021'),
(14, 1, 'ComputerFacility', 'Computer Lab Facility', '<div class=\"mx-auto p-4 border m-4 text-justify\">\r\n  <h5 class=\"font-weight-bold\">Compuer Lab Facility</h5>\r\n  <hr>\r\n  <h5 style=\"line-height: 1.5;\"><i class=\"fas fa-check-square lg-3 text-success\"></i> Computer lab with broadband internet connection.</h5>\r\n  <h5 style=\"line-height: 1.5;\"><i class=\"fas fa-check-square lg-3 text-success\"></i> A Computer Lab is used to provide students with the access of many services. It gives our students the access of software library and scope to  acquire practical experiences.</h5>\r\n  <h5 style=\"line-height: 1.5;\"><i class=\"fas fa-check-square lg-3 text-success\"></i> Computer Labs enable students to get training in computer applications. Therefore, once students became graduate, they can use the skills they learned for the betterment of their career. Additionally, computer labs allow equity to the students. Every individual can get access to his computer. Students can work on machines without sharing PCs.</h5>\r\n</div>', '20210830091719.jpg', 'active', '03:17:19 PM, 30-Aug-2021'),
(15, 1, 'LaboratoryFacility', 'Fundamental Nursing Lab', '', '20210830092227.jpg', 'active', '03:22:27 PM, 30-Aug-2021'),
(16, 1, 'LaboratoryFacility', 'Midwifery Lab', '', '20210830092329.jpg', 'active', '03:23:29 PM, 30-Aug-2021'),
(17, 1, 'LaboratoryFacility', 'Anatomy Lab', '', '20210830093423.jpg', 'active', '03:34:23 PM, 30-Aug-2021'),
(18, 1, 'LaboratoryFacility', 'Physiology Lab', '', '20210830093535.jpg', 'active', '03:35:35 PM, 30-Aug-2021'),
(19, 1, 'LaboratoryFacility', 'Nutrition Lab', '', '20210830093615.jpg', 'active', '03:36:15 PM, 30-Aug-2021'),
(20, 1, 'LaboratoryFacility', 'Microbiology Lab', '', '20210830093650.jpg', 'active', '03:36:50 PM, 30-Aug-2021'),
(21, 1, 'CanteenFacility', 'Canteen Facility', '<div class=\"mx-auto p-4 border m-4 text-justify\">\r\n  <h5 class=\"font-weight-bold\">Canteen Facility</h5>\r\n  <hr>\r\n  <h5 style=\"line-height: 1.5;\"> The college is providing canteen facility to the students as well as teaching and non teaching staff of the college; it is capable of catering the demands of the students and can accommodate 30 persons at a time. It has spacious & properly maintained room as well as kitchen; generally the college provides it to any individual on contract basis after proper officialâ€™s formalities. The College canteen also caters to the functions organized in the college programmes like seminars, conferences and workshops.Kitchen staff takes care to provide the students and staff a nutritious and hygienic food at our campus canteens. A variety of hygienic food and snack items includes South and North Indian Meals, Variety Riceâ€™s Chinese Foods Fresh Juices, etc.</h5>\r\n</div>', '20210830094105.jpg', 'active', '03:41:05 PM, 30-Aug-2021'),
(22, 1, 'HealthFacility', 'Health Care Facility', '<div class=\"mx-auto p-4 border m-4\">\r\n  <h5 class=\"font-weight-bold\">Health Care</h5>\r\n  <hr>\r\n  <h5>There is a renowned Khwaja Yunus Ali Medical College and Hospital in same campus of nursing college, where the Clinical Practice Centre is equipped with facilities for training in a variety of skills suitable for beginning practitioners and students. All training rooms are equipped with wash hand basins, data projectors, white boards, flip charts and cameras. The Centre is also equipped with state-of the-art audio-visual equipment and video-conferencing facilities. The hospital has clean operation theaters with central airconditioning both at inpatient and outpatient departments.</h5>\r\n</div>', '20210830094828.jpg', 'active', '03:48:28 PM, 30-Aug-2021'),
(23, 1, 'PlayGroundFacility', 'Play Ground', '<div class=\"mx-auto p-4 border m-4\">\r\n  <h5 class=\"font-weight-bold\">Play Ground</h5>\r\n  <hr>\r\n  <h5 style=\"line-height:1.5;\">The college presently have itâ€™s own lush green playground, where regular sports & games such as volleyball, football and cricket etc are conducted time to time. We have facility for indoor games such as chess, badminton, Table Tennis and Snooker.</h5>\r\n</div>', '20210830094737.jpg', 'active', '03:49:45 PM, 30-Aug-2021'),
(24, 1, 'Auditorium', 'Auditorium', '<div class=\"mx-auto p-4 border m-4\">\r\n  <h5 class=\"font-weight-bold\">Auditorium</h5>\r\n  <hr>\r\n  <h5 style=\"line-height:1.5;\"></h5>\r\n</div>', '20210830100353.jpg', 'active', '03:19:42 PM, 27-Sep-2021'),
(25, 1, 'Campus', 'Khwaja Yunus Ali Nursing College Campus', '<div class=\"w-75 mx-auto p-4 border m-4 text-justify\">\r\n  <h5 class=\"font-weight-bold\">Our Campus</h5>\r\n  <hr>\r\n  <h5 style=\"line-height:1.5\">Khwaja Yunus Ali Nursing College is one of the biggest and most famous Colleges in the country and of course it represents a model for an ideal college. Our College  campus situated near the bank of Jamuna. The College is housed in  three-storied buildings. There is the main gate at the entrance where the gatekeepers control the unauthorized entrance of people and vehicles. The southern building is used for official works. The eastern building is used as the laboratory and the library. Studentâ€™s common room situated on the north side of the campus. Other buildings around the campus are used as classrooms.  A large grassy lawn and a garden in front of the academic buildingâ€™s add to the beauty of the campus.</h5>\r\n</div>', '', 'active', '10:36:06 AM, 05-Oct-2021'),
(26, 1, 'VisionMission', 'Vision & Mission', '<div class=\"w-75 mx-auto p-4 border m-4\">\r\n  <h5 class=\"font-weight-bold\">VISSION</h5>\r\n  <hr>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> To create skilled and knowledgeable nurse to meet the demand of both home and abroad.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Create an opportunity to make the students initiative having international standard education to serve the human being.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> To facilitate the trainee nurses so that they can find out the right pathway of higher education in nursing sector.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> To provide international standard education and facilitate them with modern technology to the students that will help to create skilled manpower who will contribute to make the national economy more sustainable.</h5>\r\n</div>\r\n\r\n<div class=\"w-75 mx-auto p-4 border m-4\">\r\n  <h5 class=\"font-weight-bold\">MISSION</h5>\r\n  <hr>\r\n  <h5 style=\"line-height: 1.5\">We are catalysts for optimizing health through nurse-led care by integrating education, practice, research, and technology. We define health broadly and impact it by addressing policy and social issues through advocacy and leadership. Fueled by our commitment to communities, families, and individuals, we seek partnerships to create innovative solutions that improve health for all.</h5>\r\n</div>', '', 'active', '03:54:51 PM, 23-Sep-2021'),
(27, 1, 'CollegeRules', 'Rules for Nursing College', '<div class=\"w-75 mx-auto p-4 border m-4\">\r\n  <h5 class=\"font-weight-bold\">College Rules</h5>\r\n  <hr>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> For the safety and security of the institution and the students and on top in order to keep a peaceful learning environment students are allowed to meet only their parents and siblings with the permission of the authority in the certain allocated time.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> However students may go out with gate pass which is applicable for the students of every year. Without any health issue students are not allowed to go to Hospital.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> The student who will be absent for consecutive three months from the class without permission she will not be allowed to sit for the regular exam.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> Students will get the library facilities from 9:00 AM to 5:00 PM.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> National and international days observation and cultural programs celebration will be held at college campus with the permission of the authority.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> Students shall not indulge in any political or communal activity which is detrimental to the law and order and/or against the Government and they canâ€™t join any studentâ€™s organization outside the KYANC.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> Students shall treat the authority, employees, staff and patient of the institution with due courtesy at all times.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> They should try to keep every place of the Campus neat and clean. No one will enter into the flower garden or destroy anything of it.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> Strict disciplinary action will be taken against any student found guilty of any personal violence, grouping or involving in any disorderly activities.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> They canâ€™t get admitted to any other institution during the course otherwise they will be expelled from the course if it is proved.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> Studentsâ€™ marital status should be single until they pass in their final exam.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> During the course all the original copies of certificates and academic transcripts will be preserved in KYANC.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> All the rules and regulations provided by Bangladesh nursing and Midwifery council and the rules of the own nursing college should be followed accordingly during the course</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> Studentâ€™s registration should be filled up according to the instructions given by Bangladesh nursing and Midwifery council.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> According to the dress code, students should appear with proper uniform in the clinical practice at hospital on time. If they donâ€™t follow the dress code they will not be permitted to attend clinical practice and will not be allowed to appear in the exam.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> During the class and duty time no ornaments is allowed and everyoneâ€™s cleanliness is must.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> Practical classes, clinical practices and vacation will be determined by the college authority.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> The student who misses the clinical practice she has to submit proper documents in favor of her absence and she must do that clinical practice later on.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> If any student gets less than 60% mark in any exam she should retake that exam. Students have to get 60% marks, they should have 80% class attendance and they must present in clinical practice.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> To protect the reputation of this institution and for the safety of the girls all the rules stated above should be practiced accordingly.</h5>\r\n<h5><i class=\"fas fa-check-square text-success\"></i> All the rules stated above may be changed or some new rules may be added according to the necessity of the institution. </h5>\r\n</div>', '', 'active', '03:24:08 PM, 27-Sep-2021');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(200) DEFAULT NULL,
  `id_status` enum('active','inactive') NOT NULL,
  `posting_date` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`, `id_status`, `posting_date`) VALUES
(1, 'B.Sc in Nursing (Basic)', 'active', '10-10-2021'),
(2, 'Diploma in Nursing Science & Midwifery', 'active', '10-10-2021'),
(3, 'B.Sc in Nursing (Post Basic)', 'active', '10-10-2021'),
(4, 'M.Sc in Nursing (Proposed)', 'active', '10-10-2021'),
(5, 'ALL COURSES', 'active', '10-10-2021'),
(7, 'N/A', 'active', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `erecruitement`
--

CREATE TABLE `erecruitement` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `Job_id` varchar(20) DEFAULT NULL,
  `position` text,
  `title` text,
  `file` varchar(50) DEFAULT NULL,
  `details` text,
  `num_of_post` varchar(2) DEFAULT NULL,
  `age_cal_on` varchar(30) DEFAULT NULL,
  `academic_requirement` text,
  `deadline` varchar(30) DEFAULT NULL,
  `id_status` enum('active','inactive') NOT NULL,
  `posting_date` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `erecruitement`
--

INSERT INTO `erecruitement` (`id`, `user_id`, `Job_id`, `position`, `title`, `file`, `details`, `num_of_post`, `age_cal_on`, `academic_requirement`, `deadline`, `id_status`, `posting_date`) VALUES
(1, 1, '101', 'à¦…à¦§à§à¦¯à¦•à§à¦·/à¦…à¦§à§à¦¯à¦¾à¦ªà¦•/à¦¸à¦¹à¦¯à§‹à¦—à§€ à¦…à¦§à§à¦¯à¦¾à¦ªà¦•/à¦¸à¦¹à¦•à¦¾à¦°à§€ à¦…à¦§à§à¦¯à¦¾à¦ªà¦•/à¦ªà§à¦°à¦­à¦¾à¦·à¦•/à¦•à§à¦²à¦¿à¦¨à¦¿à¦•à§à¦¯à¦¾à¦² à¦ªà§à¦°à¦¶à¦¿à¦•à§à¦·à¦•', 'à¦¨à¦¿à§Ÿà§‹à¦— à¦¬à¦¿à¦œà§à¦žà¦ªà§à¦¤à¦¿-à¦…à¦§à§à¦¯à¦•à§à¦·/à¦…à¦§à§à¦¯à¦¾à¦ªà¦•/à¦¸à¦¹à¦¯à§‹à¦—à§€ à¦…à¦§à§à¦¯à¦¾à¦ªà¦•/à¦¸à¦¹à¦•à¦¾à¦°à§€ à¦…à¦§à§à¦¯à¦¾à¦ªà¦•/à¦ªà§à¦°à¦­à¦¾à¦·à¦•/à¦•à§à¦²à¦¿à¦¨à¦¿à¦•à§à¦¯à¦¾à¦² à¦ªà§à¦°à¦¶à¦¿à¦•à§à¦·à¦•', '20210902101739.pdf', '', '', '', 'à¦¬à¦¾à¦‚à¦²à¦¾à¦¦à§‡à¦¶ à¦¨à¦¾à¦°à§à¦¸à¦¿à¦‚ à¦•à¦¾à¦‰à¦¨à§à¦¸à¦¿à¦² à¦“ à¦‡à¦‰à¦œà¦¿à¦¸à¦¿ à¦à¦° à¦¨à¦¿à§Ÿà¦® à¦…à¦¨à§à¦¯à¦¾à§Ÿà§€', '2021-10-03', 'active', '04:35:02 PM, 02-Sep-2021'),
(25, 1, '102', 'à¦…à¦§à§à¦¯à¦•à§à¦·, à¦…à¦§à§à¦¯à¦¾à¦ªà¦•, à¦¸à¦¹à¦¯à§‹à¦—à§€ à¦…à¦§à§à¦¯à¦¾à¦ªà¦•, à¦¸à¦¹à¦•à¦¾à¦°à§€ à¦…à¦§à§à¦¯à¦¾à¦ªà¦•, à¦ªà§à¦°à¦­à¦¾à¦·à¦•, à¦¨à¦¾à¦°à§à¦¸à¦¿à¦‚à¦• à¦‡à¦¨à¦¸à§à¦Ÿà§à¦°à¦¾à¦•à§à¦Ÿà¦°', 'à¦…à¦§à§à¦¯à¦•à§à¦·, à¦…à¦§à§à¦¯à¦¾à¦ªà¦•, à¦¸à¦¹à¦¯à§‹à¦—à§€ à¦…à¦§à§à¦¯à¦¾à¦ªà¦•, à¦¸à¦¹à¦•à¦¾à¦°à§€ à¦…à¦§à§à¦¯à¦¾à¦ªà¦•, à¦ªà§à¦°à¦­à¦¾à¦·à¦•, à¦¨à¦¾à¦°à§à¦¸à¦¿à¦‚à¦• à¦‡à¦¨à¦¸à§à¦Ÿà§à¦°à¦¾à¦•à§à¦Ÿà¦°', '20210919030336.pdf', '', '', '', '.', '2021-10-22', 'active', '09:03:36 AM, 19-Sep-2021');

-- --------------------------------------------------------

--
-- Table structure for table `facultystaff`
--

CREATE TABLE `facultystaff` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(40) NOT NULL,
  `serial_number` int(5) NOT NULL,
  `mem_id_num` varchar(11) DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `file` varchar(30) DEFAULT NULL,
  `designation` varchar(30) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `qualification` varchar(30) DEFAULT NULL,
  `short_biography` text,
  `research_interest` varchar(200) DEFAULT NULL,
  `research_and_publication` text,
  `academic_info` text,
  `experience` text,
  `linkedin` varchar(200) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `twitter` varchar(150) DEFAULT NULL,
  `facebook` varchar(150) DEFAULT NULL,
  `youtube` varchar(200) DEFAULT NULL,
  `gender` varchar(6) DEFAULT NULL,
  `blood_group` varchar(6) DEFAULT NULL,
  `nid` varchar(20) DEFAULT NULL,
  `id_status` enum('active','inactive') NOT NULL,
  `posting_date` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `facultystaff`
--

INSERT INTO `facultystaff` (`id`, `user_id`, `type`, `serial_number`, `mem_id_num`, `name`, `file`, `designation`, `mobile`, `email`, `qualification`, `short_biography`, `research_interest`, `research_and_publication`, `academic_info`, `experience`, `linkedin`, `website`, `twitter`, `facebook`, `youtube`, `gender`, `blood_group`, `nid`, `id_status`, `posting_date`) VALUES
(6, 1, 'Faculty', 1, '1', 'Mohammad Abu Yousuf', '20210826034352.jpeg', 'Professor', '01621000361', 'yousuf@gmail.com', 'PhD', 'Dr. Mohammad Abu Yousuf received the B.Sc.(Engineering) degree in Computer Science and Engineering from Shahjalal University of Science and Technology, Sylhet, Bangladesh in 1999, the Master of Engineering degree in Biomedical Engineering from Kyung Hee University, South Korea in 2009, and the Ph.D. degree in Science and Engineering from Saitama University, Japan in 2013. In 2003, he joined as a Lecturer in the Department of Computer Science and Engineering, Mawlana Bhashani Science and Technology University, Tangail, Bangladesh. In 2014, he moved to the Institute of Information Technology, Jahangirnagar University. He is now working as Professor at the Institute of Information Technology, Jahangirnagar University, Savar, Dhaka, Bangladesh. His research interests include Medical Image Processing, Human-Robot Interaction, and Computer Vision, Natural Language Processing.\r\n', 'Computer Vision, Human-Robot Interaction, Medical Image processing, Natural Langugae Processing', '<p>1. PARTHA CHAKRABORTY, SABBIR AHMED, MOHAMMAD ABU YOUSUF, AKM AZAD, SALEM A. ALYAMI, AND MOHAMMAD ALI MONI, A Human-Robot Interaction System Calculating Visual Focus of Humanâ€™s Attention Level, IEEE Access, 9, pp.93409-93421, 2021.</p>\r\n<br>\r\n<p>2) Md. Raisul Kibria, Mohammad Abu Yousuf, Context-driven Bengali Text Generation using Conditional Language Model, Statistics, Optimization and Information Computing. (Accepted)., 2021.</p>\r\n<br>\r\n<p>3) Tapotosh Ghosh, Md. Min-Ha-Zul Abedin, Md. Hasan Al Banna, Nasirul Mumenin, and Mohammad Abu Yousuf, Performance Analysis of State of the Art Convolutional Neural Network Architectures in Bangla Handwritten Character Recognition, Pattern Recognition and Image Analysis, 31, 1, pp.60-71, 2021.</p>\r\n<br>\r\n<p>4) Mohammad Masud Khan, Mohammad Golam Sohrab, and Mohammad Abu Yousuf, Customer gender prediction system on hierarchical E-commerce Data, Beni-Suef University Journal of Basic and Applied Sciences, 9, 10, 2020. doi: https://doi.org/10.1186/s43088-020-0035-7.</p>\r\n<br>\r\n<p>5) Ahmed Abdal Shafi Rasel, Mohammad Abu Yousuf, An Efficient Framework for Hand Gesture Recognition based on Histogram of Oriented Gradients and Support Vector Machine, International Journal of Information Technology and Computer Science, 11, 12, pp.50-56, 2019</p>', '<h5><strong>Institute:</strong>Saitama University, Japan</h5>\r\n<h5><strong>Period:</strong> 2010 to 2013</h5>\r\n<h5><strong>Ph.D.</strong></h5>\r\n <br>\r\n<h5><strong>Institute:</strong>Kyung Hee University, South Korea</h5>\r\n<h5><strong>Period:</strong> 2007 to 2009</h5>\r\n<h5><strong>M.Sc. (Engineering)</strong></h5>\r\n <br>\r\n<h5><strong>Institute:</strong>Shajalal University of Science and Technology, Sylhet, Bangladesh</h5>\r\n<h5><strong>Period:</strong> 1995-96 to 1998-99</h5>\r\n<h5><strong>B.Sc. (Engineering) in Computer Science and Engineering</strong></h5>\r\n <br>\r\n<h5><strong>Institute:</strong>Sylhet Cadet College, Sylhet, Bangladesh</h5>\r\n<h5><strong>Period:</strong> 1995</h5>\r\n<h5><strong>H.S.C.</strong></h5>\r\n <br>\r\n<h5><strong>Institute:</strong>Sylhet Cadet College</h5>\r\n<h5><strong>Period:</strong> 1993</h5>\r\n<h5><strong>S.S.C.</strong></h5>\r\n', '<h5><strong>Organization:</strong>Institute of Information Technology (IIT)</h5>\r\n<h5><strong>Position:</strong> Professor</h5>\r\n<h5><strong>Period:</strong>12th December 2019 to till to date</h5>\r\n <br>\r\n<h5><strong>Organization:</strong>Institute of Information Technology (IIT), Jahangirnagar University, Savar, Dhaka</h5>\r\n<h5><strong>Position:</strong> Associate Professor</h5>\r\n<h5><strong>Period:</strong>30th January 2017 - till to date</h5>\r\n <br>\r\n<h5><strong>Organization:</strong>Institute of Information Technology (IIT), Jahangirnagar University, Savar, Dhaka</h5>\r\n<h5><strong>Position:</strong> Assistant Professor</h5>\r\n<h5><strong>Period:</strong>April 25, 2013- October 26, 2014</h5>\r\n<br>\r\n<h5><strong>Organization:</strong>Department of Computer Science & Engineering Mawlana Bhashani Science and Technology University, Tangail.</h5>\r\n<h5><strong>Position:</strong> Lecturer</h5>\r\n<h5><strong>Period:</strong>August 24, 2003 to August 23, 2006</h5>', 'https://www.linkedin.com/login?fromSignIn=true&trk=guest_homepage-basic_nav-header-signin', 'https://sites.google.com/view/miltonkhan', 'https://twitter.com/', 'https://www.facebook.com/', 'https://www.youtube.com/', 'Male', 'A+', '01555555555555555', 'inactive', '10:21:28 AM, 26-Aug-2021'),
(7, 1, 'Faculty', 1, '2', 'Rowshonara Khatun', '20210826042953.jpg', 'Principal', ' +8801915477962', 'principal@kyanc.edu.bd', 'MPH', '', '', '', '', '', '', '', '', '', '', '', '', '', 'active', '11:08:05 AM, 06-Sep-2021'),
(8, 1, 'Faculty', 3, '3', 'Most. Wahida Khatun', '20210826044946.png', 'Vice-Principal', 'N/A', '', 'MPH', '', '', '', '', '', '', '', '', '', '', '', '', '', 'active', '10:49:46 AM, 26-Aug-2021'),
(9, 1, 'Faculty', 3, '3', 'Azmira Begum', '20210826045200.png', 'Professor', 'N/A', '', 'B.sc in Post Basic, MPH', '', '', '', '', '', '', '', '', '', '', '', '', '', 'active', '10:52:00 AM, 26-Aug-2021'),
(10, 1, 'Faculty', 4, '', 'Rawshan Ara', '20210826045011.png', 'Lecturer', 'N/A', '', 'MPH', '', '', '', '', '', '', '', '', '', '', '', '', '', 'active', '10:50:11 AM, 26-Aug-2021'),
(11, 1, 'Faculty', 5, '5', 'Sharmin Khatun', '20210826045017.png', 'Nursing Instructor', 'N/A', '', 'Basic B.SSC, MPH', '', '', '', '', '', '', '', '', '', '', '', '', '', 'active', '10:50:17 AM, 26-Aug-2021');

-- --------------------------------------------------------

--
-- Table structure for table `file_mgt`
--

CREATE TABLE `file_mgt` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `title` text,
  `batch` varchar(15) DEFAULT NULL,
  `semester` varchar(16) DEFAULT NULL,
  `file` varchar(50) DEFAULT NULL,
  `link` varchar(200) DEFAULT NULL,
  `year` varchar(4) DEFAULT NULL,
  `duration` varchar(50) DEFAULT NULL,
  `num_of_seat` varchar(5) DEFAULT NULL,
  `session_start` varchar(15) DEFAULT NULL,
  `published_date` varchar(30) DEFAULT NULL,
  `row_status` enum('active','inactive') NOT NULL,
  `posting_date` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `file_mgt`
--

INSERT INTO `file_mgt` (`id`, `user_id`, `course_id`, `type`, `title`, `batch`, `semester`, `file`, `link`, `year`, `duration`, `num_of_seat`, `session_start`, `published_date`, `row_status`, `posting_date`) VALUES
(6, 1, 5, 'ClassRoutine', '', 'All Batchs', 'Fall-2021', '20210901055203.pdf', '', '', '', '', '', '2021-08-01', 'inactive', '09:01:27 AM, 13-Sep-2021'),
(8, 1, 7, 'Calendar', 'Academic Calendar-2021', '', '', '20210924082920.pdf', '', '', '', '', '', '', 'active', '02:29:20 PM, 24-Sep-2021'),
(9, 1, 7, 'Prospectus', 'College Prospectus 2021', '', '', '20210901055232.pdf', '', '2021', '', '', '', '2021-01-01', 'active', '11:52:32 AM, 01-Sep-2021'),
(10, 1, 7, 'AdmissionCircular', '2020-2021 à¦¶à¦¿à¦•à§à¦·à¦¾à¦¬à¦°à§à¦·à§‡ à¦¨à¦¾à¦°à§à¦¸à¦¿à¦‚ à¦“ à¦®à¦¿à¦¡à¦“à§Ÿà¦¾à¦‡à¦«à¦¾à¦°à¦¿ à¦•à§‹à¦°à§à¦¸à§‡ à¦šà¦²à¦›à§‡à¥¤', '', '', '20210831104108.pdf', 'http://www.bnmc.gov.bd/', '', '', '', '', '', 'inactive', '09:22:34 AM, 05-Oct-2021'),
(11, 1, 2, 'CourseInformation', '', '', '', '', 'Midwifery.php', '', '3 years & 6 weeks internship    ', '30', 'January', '', 'active', '04:54:59 PM, 31-Aug-2021'),
(12, 1, 1, 'CourseInformation', '', '', '', '', 'BscBasic.php', '', '4 years & 6 months internship', '80', 'January', '', 'active', '04:57:03 PM, 31-Aug-2021'),
(13, 1, 3, 'CourseInformation', '', '', '', '', 'BscPostBasic.php', '', '2 years', '30', 'July', '', 'active', '04:57:26 PM, 31-Aug-2021');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(30) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `file` varchar(50) DEFAULT NULL,
  `link` text,
  `id_status` enum('active','inactive') NOT NULL,
  `posting_date` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `user_id`, `type`, `title`, `file`, `link`, `id_status`, `posting_date`) VALUES
(2, 1, 'PhotoGallery', 'Students Group Photo in front of KYANC', '20210829092336.JPG', '', 'active', '03:26:28 PM, 29-Aug-2021'),
(3, 1, 'TourGallery', 'Cox\'s Bazar	', '20210829092827.jpg', '', 'active', '09:56:56 AM, 02-Sep-2021'),
(4, 1, 'TourGallery', 'Cox\'s Bazar	', '20210829093153.jpg', '', 'active', '09:56:52 AM, 02-Sep-2021'),
(5, 1, 'TourGallery', 'Cox\'s Bazar', '20210829093506.png', '', 'active', '09:56:34 AM, 02-Sep-2021'),
(6, 1, 'VideoGallery', 'à¦¡à¦¾. à¦®à§€à¦° à¦®à§‹à¦¹à¦¾à¦®à§à¦®à¦¾à¦¦ à¦†à¦®à¦œà¦¾à¦¦ à¦¹à§‹à¦¸à§‡à¦¨', '', 'https://www.youtube.com/embed/epRWIenp19Y', 'active', '10:53:16 AM, 02-Sep-2021'),
(7, 1, 'VideoGallery', 'Prof. Dr. Rubaiyat Farzana | Khwaja Yunus Ali Medical College and Hospital (KYAMCH)', '', 'https://www.youtube.com/embed/PzieoUAoNm0', 'active', '03:44:41 PM, 29-Aug-2021'),
(9, 1, 'PhotoGallery', 'Group photo of Nursing College\'s Teachers', '20210901104219.jpg', '', 'active', '11:56:12 AM, 03-Sep-2021'),
(11, 1, 'PhotoGallery', 'Microbiology Lab', '20210901105543.jpg', '', 'active', '05:04:35 PM, 01-Sep-2021'),
(12, 1, 'TourGallery', 'Educational Tour-2019', '20210902031623.JPG', '', 'active', '09:55:43 AM, 02-Sep-2021'),
(13, 1, 'PhotoGallery', 'Library', '20210902044642.JPG', '', 'active', '10:46:42 AM, 02-Sep-2021'),
(14, 1, 'VideoGallery', 'KYAMCH', '', 'https://www.youtube.com/embed/bmivsIxycyY', 'active', '10:51:25 AM, 02-Sep-2021'),
(16, 1, 'VideoGallery', 'Document of Group Organization', '', 'https://www.youtube.com/embed/l2UgsFl4oyw', 'active', '03:37:39 PM, 29-Aug-2021'),
(17, 1, 'PhotoGallery', 'Infront of Khwaja Yunus Ali Nursing College', '20210902063314.jpg', '', 'active', '12:33:14 PM, 02-Sep-2021');

-- --------------------------------------------------------

--
-- Table structure for table `governing_body`
--

CREATE TABLE `governing_body` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `serial_number` int(5) DEFAULT NULL,
  `name` varchar(80) DEFAULT NULL,
  `file` varchar(40) DEFAULT NULL,
  `institutional_designation` varchar(50) DEFAULT NULL,
  `institution` varchar(150) DEFAULT NULL,
  `designation` varchar(150) DEFAULT NULL,
  `id_status` enum('active','inactive') NOT NULL,
  `posting_date` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `governing_body`
--

INSERT INTO `governing_body` (`id`, `user_id`, `serial_number`, `name`, `file`, `institutional_designation`, `institution`, `designation`, `id_status`, `posting_date`) VALUES
(2, 1, 2, 'Prof. Dr. Md. Bulbul Hasan', '', 'Principal', 'Pabna Medical College, Pabna', 'Representative from the Rajshahi Medical University', 'active', '11:53:36 AM, 19-Aug-2021'),
(3, 1, 3, 'Prof. Dr. Amirul Hossain Chowdhury', '', 'Principal', 'Shahid M. Monshur Ali Medical College, Sirajgong ', 'Representative from the Rajshahi Medical University', 'active', '04:54:21 PM, 18-Aug-2021'),
(4, 1, 4, 'Deputy Secretary (Purchasing -1)', '', '', '', 'Representative from the Ministry of Health & Family Welfare ', 'active', '04:55:17 PM, 18-Aug-2021'),
(5, 2, 5, 'Proposed', '', '', '', 'Representative from the  department of Health', 'active', '12:15:14 PM, 24-Sep-2021'),
(6, 1, 6, 'Mohammad Yusuf', '', 'Director of Society, KYAMCH ', '', 'Founder Member ', 'active', '04:57:18 PM, 18-Aug-2021'),
(7, 1, 7, 'Prof. Dr. Rubaiyat Farzana Hussain ', '', 'Director of KYAMCH.', '', 'Founder Member ', 'active', '04:58:04 PM, 18-Aug-2021'),
(8, 1, 8, 'Mrs. Husne Ara Hussain', '', 'Member, Board of Trustee, KYAMCH', '', 'Founder Member ', 'active', '04:58:57 PM, 18-Aug-2021'),
(9, 1, 9, 'Mst. Wahida Khatun  ', NULL, 'Vice-Principal, KYANC', '', 'Teachers Representative', 'active', '04:59:57 PM, 18-Aug-2021'),
(10, 1, 10, 'Prof. Azmira Begum', '', 'Professor of KYANC', '', 'Teachers Representative', 'active', '05:01:24 PM, 18-Aug-2021'),
(11, 1, 11, 'Mir. Md Shahriar', '', '', '', 'Guardian Representative', 'active', '05:01:56 PM, 18-Aug-2021'),
(12, 1, 12, 'Md. Shohidul Islam ', '', '', '', 'Guardian Representative', 'active', '05:02:23 PM, 18-Aug-2021'),
(13, 1, 13, 'Mohammad Yunus Khan', NULL, 'Associate Professor', 'MIS Department, Khwaja Yunus Ali Unviersity', 'Educationalist', 'active', '05:07:41 PM, 18-Aug-2021'),
(14, 2, 14, 'Chandra Banu', '', 'Public Health Nurse, Civil Surgeon office, Tangail', 'General Hospital, Sirajganj.', 'Educationalist', 'active', '12:18:51 PM, 24-Sep-2021'),
(15, 1, 15, 'Rowshonara Khatun', '', 'Principal', 'Khwaja Yunus Ali Nursing College', 'Member Secretary', 'active', '03:47:23 PM, 19-Aug-2021'),
(20, 1, 1, 'M.A. Haider Hussain', '', 'Chairman, Board of Trustee, KYAMCH', '', 'Chairman', 'active', '04:08:42 PM, 30-Aug-2021');

-- --------------------------------------------------------

--
-- Table structure for table `home`
--

CREATE TABLE `home` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(30) NOT NULL,
  `serial_number` int(3) NOT NULL,
  `title` text,
  `details` text,
  `file` varchar(50) DEFAULT NULL,
  `link` varchar(200) DEFAULT NULL,
  `id_status` enum('active','inactive') NOT NULL,
  `conference_date` varchar(30) DEFAULT NULL,
  `posting_date` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `home`
--

INSERT INTO `home` (`id`, `user_id`, `type`, `serial_number`, `title`, `details`, `file`, `link`, `id_status`, `conference_date`, `posting_date`) VALUES
(1, 1, 'Carousel', 12, 'Play Ground of Khwaja Yunus Ali Nursing College', '                    ', '20210823030052.jpg', '', 'active', '', '09:18:42 AM, 23-Aug-2021'),
(2, 2, 'Carousel', 6, 'Library of Khwaja Yunus Ali Nursing College', '                    ', '20210823030420.jpg', '', 'active', '', '12:23:11 PM, 24-Sep-2021'),
(3, 1, 'Carousel', 5, 'Khwaja Yunus Ali Nursing College Classroom ', '                    ', '20210823030531.jpg', '', 'active', '', '09:23:14 AM, 23-Aug-2021'),
(5, 1, 'Carousel', 3, 'Inside Pond view of Khwaja Yunus Ali Medical College & Hospital', '                    ', '20210823032036.jpg', '', 'active', '', '09:22:58 AM, 23-Aug-2021'),
(6, 1, 'Carousel', 2, 'The Female Hall of Khwaja Yunus Ali Nursing College', '                    ', '20210823032136.jpg', '', 'active', '', '09:21:36 AM, 23-Aug-2021'),
(7, 1, 'Carousel', 1, 'Academic Building', '                    ', '20210823032228.jpg', '', 'active', '', '09:23:52 AM, 14-Aug-2021'),
(8, 1, 'NIE', 1, 'Centennial birth anniversary of the founding father of Bangladesh', '                    ', '20210823033101.jpg', '', 'active', '', '10:44:32 AM, 05-Oct-2021'),
(9, 1, 'LatestNotice', 2, 'Father of the nation Bangabandhu Sheikh Mujibur Rahman\'s 46th martyrdom anniversary and national mourning day', '                    ', '20210823034239.pdf', '', 'inactive', '', '10:59:18 AM, 05-Oct-2021'),
(10, 2, 'Conferences', 1, 'Breast Feeding Meeting', 'Undernutrition is estimated to be associated with 2.7 million child deaths annually or 45% of all child deaths. Infant and young child feeding is a key area to improve child survival and promote healthy growth and development. The first 2 years of a childâ€™s life are particularly important, as optimal nutrition during this period lowers morbidity and mortality, reduces the risk of chronic disease, and fosters better development overall.                    ', '20210823094029.jpg', '', 'active', '', '01:29:25 PM, 24-Sep-2021'),
(11, 1, 'Notice', 1, 'Father of the Nation Bangabandhu Sheikh Mujibur Rahman\'s 46th Martyrdom Anniversary and Mourning Day', '                    ', '20210823091449.pdf', '', 'active', '', '09:13:04 AM, 05-Oct-2021'),
(14, 1, 'WCU', 1, 'Academic Building', 'Khwaja Yunus Ali Nursing College Academic Building...........................                    ', '20210823100637.jpg', '', 'active', '', '04:06:37 PM, 23-Aug-2021'),
(15, 1, 'WCU', 2, 'Well Stocked Library', '\r\n<div class=\"w-75 mx-auto p-4 border m-4\">\r\n  <h5 class=\"font-weight-bold\">Library Facilities</h5>\r\n  <hr>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Khwaja Yunus Ali Nursing College has an excellent library with a vast array of books from authors of National and International reputation in medical Sciences, latest health related magazines and IT materials available for reference.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Modern library enriched with huge number of books, journals & online resources.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> The Library also has broadband internet facilities and the entire area is secured with CCTV Surveillance.</h5>\r\n </div> ', '20210823102451.jpg', '', 'active', '', '09:04:24 AM, 30-Aug-2021'),
(16, 1, 'WCU', 3, 'Well equipped Studios & Classrooms', 'Well equipped Studios & Classrooms                    ', '20210823102527.jpg', '', 'active', '', '04:25:27 PM, 23-Aug-2021'),
(17, 1, 'WCU', 4, 'Female Hostel ', '<div class=\"w-75 mx-auto p-4 border m-4\">\r\n  <h5 class=\"font-weight-bold\">Hostel Facilities</h5>\r\n  <hr>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Safe and quiet place.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Very homely stay.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Comfortable and well-lit rooms.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Allotment of seats is done on the first come first serve basis.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> 4 students are allocated for a room.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Secure accommodation in a well-equipped campus building.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> 24 hours electricity facility.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Purified water facility by self water purification plant.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Common lounge with television and refrigerator.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Common kitchen and functioning near the hostel.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> Shared and separate toilets.</h5>\r\n  <h5><i class=\"fas fa-check-square text-success\"></i> However, hostel accommodation for Students will be provided as long as the seats are available.</h5>\r\n </div>   ', '20210823102550.jpg', '', 'active', '', '09:10:21 AM, 30-Aug-2021'),
(18, 1, 'WCU', 5, 'A large well-equipped Demonstration Practical Laboratory', 'A large well-equipped Demonstration Practical Laboratory                   ', '20210823102618.jpg', '', 'active', '', '04:26:18 PM, 23-Aug-2021'),
(19, 1, 'WCU', 6, 'Computer lab with broadband internet connection.', 'Computer lab with broadband internet connection.                    ', '20210823102645.jpg', '', 'active', '', '04:26:45 PM, 23-Aug-2021'),
(20, 2, 'WCU', 7, 'Practical Training in Khwaja Yunus Ali Medical College & Hospital.', 'Clinical practice Area  in Khwaja Yunus Ali Medical College & Hospital.     \r\n', '20210823102716.png', '', 'active', '', '11:59:18 AM, 24-Sep-2021'),
(21, 1, 'WCU', 8, 'Permanent Campus', 'The college\'s campus is located at Jamuna River in Sirajganj. It is one of the largest private nursing colleges in Bangladesh.\r\n\r\n           ', '20210823103256.jpg', '', 'active', '', '11:02:05 AM, 24-Aug-2021'),
(22, 1, 'SC', 1, 'DRUG INTERNATIONAL LIMITED', '                    ', '20210824052043.png', 'https://www.drug-international.com/', 'active', '', '11:20:43 AM, 24-Aug-2021'),
(23, 1, 'SC', 2, 'Khwaja Yunus Ali Medical College & Hospital', '                    ', '20210824052137.png', 'https://www.kyamch.org/', 'active', '', '11:21:37 AM, 24-Aug-2021'),
(24, 1, 'SC', 3, 'Khwaja Yunus Ali Medical College', '                    ', '20210824052244.png', 'https://kyamc.edu.bd/', 'active', '', '11:22:44 AM, 24-Aug-2021'),
(25, 1, 'SC', 4, 'Khwaja Yunus Ali University', '                    ', '20210824052402.png', 'https://kyau.edu.bd/kyau/', 'active', '', '11:24:02 AM, 24-Aug-2021'),
(26, 1, 'SC', 5, 'ATI', '                    ', '20210824052458.png', 'https://www.atilimited.net/', 'active', '', '11:24:58 AM, 24-Aug-2021'),
(27, 1, 'SC', 6, 'ATI CERAMICS', '                    ', '20210824052553.png', 'https://aticeramics.com/', 'active', '', '11:25:53 AM, 24-Aug-2021'),
(28, 1, 'SC', 7, 'HARNEST LEVEL IND.', '                    ', '20210824052719.png', 'https://harnest.com/', 'active', '', '11:27:19 AM, 24-Aug-2021'),
(29, 1, 'SC', 8, 'Khwaja Yunus Ali Laboratory School & College', '                    ', '20210824052812.png', 'http://www.kyalsc.edu.bd/', 'active', '', '11:28:12 AM, 24-Aug-2021'),
(30, 1, 'SC', 9, 'M.M. TEA ESTATES LTD.', '                    ', '20210825073413.png', '#', 'active', '', '01:34:13 PM, 25-Aug-2021'),
(32, 1, 'LatestNotice', 1, 'à§¨à§¦à§¨à§¦-à§¨à§¦à§¨à§§ à¦¶à¦¿à¦•à§à¦·à¦¾à¦¬à¦°à§à¦·à§‡ à¦¨à¦¾à¦°à§à¦¸à¦¿à¦‚ à¦“ à¦®à¦¿à¦¡à¦“à§Ÿà¦¾à¦‡à¦«à¦¾à¦°à¦¿ à¦•à§‹à¦°à§à¦¸à§‡ à¦­à¦°à§à¦¤à¦¿  à¦šà¦²à¦›à§‡à¥¤ à¦…à¦¨à¦²à¦¾à¦‡à¦¨à§‡ à¦†à¦¬à§‡à¦¦à¦¨à§‡à¦° à¦²à¦¿à¦‚à¦•', '                    ', '', 'http://www.bnmc.gov.bd/', 'inactive', '', '11:19:19 AM, 26-Aug-2021'),
(33, 1, 'Event', 1, 'test', '                    ', '', '', 'inactive', '', '11:00:33 AM, 06-Sep-2021'),
(35, 1, 'NIE', 1, '.', '                    ', '20210915030825.JPG', '', 'inactive', '', '09:08:25 AM, 15-Sep-2021'),
(36, 2, 'NIE', 2, '.', '                    ', '20210912062747.jpg', '', 'inactive', '', '11:54:45 AM, 14-Sep-2021'),
(37, 1, 'SC', 12, 'KYAMC CANCER CENTER', '                    ', '20210914060056.jpg', '', 'active', '', '12:00:56 PM, 14-Sep-2021'),
(38, 1, 'LatestNotice', 1, 'There is no notice published yet. ', '                    ', '', '', 'active', '', '10:58:02 AM, 05-Oct-2021');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `year_type` varchar(20) DEFAULT NULL,
  `serial_number` int(5) DEFAULT NULL,
  `subject_code` char(8) DEFAULT NULL,
  `subject_name` text,
  `id_status` enum('active','inactive') NOT NULL,
  `posting_date` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `user_id`, `course_id`, `year_type`, `serial_number`, `subject_code`, `subject_name`, `id_status`, `posting_date`) VALUES
(1, 1, 1, 'FirstYear', 2, '', 'Communicative English Paper â€“ I (111)', 'active', '11:24:13 AM, 02-Sep-2021'),
(2, 2, 1, 'SecondYear', 1, '', 'Fundamentals of Nursing-2 (Paper-I) : Fundamentals Nursing & Health Assessment', 'active', '11:46:00 AM, 24-Sep-2021'),
(3, 2, 1, 'ThirdYear', 1, '', 'Medical & Surgical Nursing-2 (Paper I&II)', 'active', '11:45:49 AM, 24-Sep-2021'),
(4, 2, 1, 'FourthYear', 1, '', 'Midwifery (Paper I&II)', 'active', '11:47:13 AM, 24-Sep-2021'),
(7, 1, 2, 'FirstYear', 1, 'D111', 'Behavioral Science', 'active', '04:03:13 PM, 27-Aug-2021'),
(8, 1, 2, 'SecondYear', 1, 'D 231', 'Medical & Surgical Nursing', 'active', '04:03:17 PM, 27-Aug-2021'),
(9, 1, 2, 'ThirdYear', 1, 'D331', 'Midwifery', 'active', '04:03:20 PM, 27-Aug-2021'),
(10, 1, 3, 'FirstYear', 1, '', 'Anatomy & Physiology', 'active', '04:11:19 PM, 27-Aug-2021'),
(11, 1, 3, 'SecondYear', 1, '', 'Comprehensive nursing and pathophysiology ', 'active', '04:11:22 PM, 27-Aug-2021'),
(12, 2, 1, 'FirstYear', 4, '', 'Information & Communication Technology Paper- II ', 'active', '11:45:28 AM, 24-Sep-2021'),
(13, 2, 1, 'FirstYear', 3, '', 'Behavioral Science ', 'active', '11:45:16 AM, 24-Sep-2021'),
(14, 2, 1, 'FirstYear', 1, '', 'Anatomy Paper-I ', 'active', '11:45:03 AM, 24-Sep-2021'),
(15, 2, 1, 'FirstYear', 5, '', 'Physiology Paper-II ', 'active', '11:44:49 AM, 24-Sep-2021'),
(16, 2, 1, 'FirstYear', 6, '', 'Fundamentals of Nursing-I Paper-I ', 'active', '11:44:29 AM, 24-Sep-2021'),
(17, 2, 1, 'FirstYear', 7, '', 'Fundamentals of Nursing-I Paper-II ', 'active', '11:44:19 AM, 24-Sep-2021'),
(18, 2, 1, 'SecondYear', 2, '', 'Fundamental of Nursing-2 (Paper-II): Nutrition', 'active', '11:43:52 AM, 24-Sep-2021'),
(19, 2, 1, 'SecondYear', 3, '', 'Pediatric Nursing', 'active', '11:43:42 AM, 24-Sep-2021'),
(20, 2, 1, 'SecondYear', 4, '', 'Medical & Surgical Nursing â€“1  (Paper-I) : Medical & Surgical Nursing', 'active', '11:43:30 AM, 24-Sep-2021'),
(21, 2, 1, 'SecondYear', 5, '', 'Medical & Surgical Nursing-I (Paper-II) :  Pharmacology', 'active', '11:43:22 AM, 24-Sep-2021'),
(22, 2, 1, 'SecondYear', 6, '', ' Orthopedic Nursing', 'active', '11:43:14 AM, 24-Sep-2021'),
(23, 2, 1, 'ThirdYear', 2, '', 'Community Health Nursing', 'active', '11:43:01 AM, 24-Sep-2021'),
(24, 2, 1, 'ThirdYear', 3, '', 'Psychiatric Nursing', 'active', '11:42:49 AM, 24-Sep-2021'),
(25, 2, 1, 'ThirdYear', 4, '', 'Emergency and Critical Care Nursing', 'active', '11:42:28 AM, 24-Sep-2021'),
(26, 2, 1, 'FourthYear', 2, '', 'Nursing Education & Management  (Paper I&II)', 'active', '11:42:13 AM, 24-Sep-2021'),
(27, 2, 1, 'FourthYear', 3, '', 'Research in Nursing', 'active', '11:41:42 AM, 24-Sep-2021'),
(28, 1, 2, 'FirstYear', 2, 'D112', 'Basic Science', 'active', '12:00:52 PM, 02-Sep-2021'),
(29, 1, 2, 'FirstYear', 3, 'D123', 'Anatomy & Physiology', 'active', '12:01:25 PM, 02-Sep-2021'),
(30, 1, 2, 'FirstYear', 4, 'D124', 'Microbiology and Parasitology', 'active', '12:01:52 PM, 02-Sep-2021'),
(31, 1, 2, 'FirstYear', 5, 'D135', 'Fundamentals of Nursing', 'active', '12:02:40 PM, 02-Sep-2021'),
(32, 1, 2, 'FirstYear', 6, 'D116', 'Communicative English', 'active', '12:03:12 PM, 02-Sep-2021'),
(33, 1, 2, 'FirstYear', 7, 'D117', 'Computer & Information Technology', 'active', '12:03:35 PM, 02-Sep-2021'),
(34, 1, 2, 'SecondYear', 2, 'D 222', 'Pharmacology', 'active', '12:05:11 PM, 02-Sep-2021'),
(35, 1, 2, 'SecondYear', 3, 'D 223', 'Nutrition & Dietetics', 'active', '12:05:41 PM, 02-Sep-2021'),
(36, 1, 2, 'SecondYear', 4, 'D 234', ' Community Health Nursing', 'active', '12:06:24 PM, 02-Sep-2021'),
(37, 1, 2, 'SecondYear', 5, 'D 235', 'Pediatric Nursing', 'active', '12:06:51 PM, 02-Sep-2021'),
(38, 2, 2, 'ThirdYear', 2, 'D332', ' Psychiatric Nursing', 'active', '11:40:40 AM, 24-Sep-2021'),
(39, 1, 2, 'ThirdYear', 3, 'D333', 'Orthopedic Nursing', 'active', '12:07:56 PM, 02-Sep-2021'),
(40, 1, 2, 'ThirdYear', 4, 'D334', 'Leadership & Management', 'active', '12:08:28 PM, 02-Sep-2021'),
(41, 1, 2, 'ThirdYear', 5, 'D335', 'Research Methodology', 'active', '12:09:01 PM, 02-Sep-2021'),
(42, 1, 3, 'FirstYear', 2, '', 'Microbiology and Pathology', 'active', '12:09:31 PM, 02-Sep-2021'),
(43, 1, 3, 'FirstYear', 3, '', 'Comprehensive nursing and pathophysiology', 'active', '12:10:49 PM, 02-Sep-2021'),
(44, 1, 3, 'FirstYear', 4, '', 'Nutrition, Nutritional Assessment and Biochemistry', 'active', '12:11:13 PM, 02-Sep-2021'),
(45, 1, 3, 'FirstYear', 5, '', 'Epidemiology', 'active', '12:11:29 PM, 02-Sep-2021'),
(47, 2, 3, 'FirstYear', 7, '', 'Nursing Education and curriculum development', 'active', '11:54:27 AM, 24-Sep-2021'),
(48, 2, 3, 'FirstYear', 8, '', 'Nursing Administration & Management', 'active', '11:54:52 AM, 24-Sep-2021'),
(49, 2, 3, 'FirstYear', 9, '', 'Nursing Research', 'active', '11:55:10 AM, 24-Sep-2021'),
(50, 2, 3, 'FirstYear', 10, '', 'Study Skills', 'active', '11:55:23 AM, 24-Sep-2021'),
(51, 2, 3, 'SecondYear', 2, '', 'Reproductive Health ', 'active', '11:48:54 AM, 24-Sep-2021'),
(52, 1, 3, 'SecondYear', 3, '', 'Mental Health & Psychiatry Nursing.', 'active', '12:14:10 PM, 02-Sep-2021'),
(53, 1, 3, 'SecondYear', 4, '', 'Nursing Education and curriculum development', 'active', '12:14:35 PM, 02-Sep-2021'),
(54, 1, 3, 'SecondYear', 5, '', 'Health Education & Communication Skills', 'active', '12:15:00 PM, 02-Sep-2021'),
(55, 1, 3, 'SecondYear', 6, '', 'Nursing Administration & Management.', 'active', '12:15:23 PM, 02-Sep-2021'),
(56, 1, 3, 'SecondYear', 7, '', 'Nursing Research', 'active', '12:15:41 PM, 02-Sep-2021'),
(57, 2, 3, 'FirstYear', 6, '', 'Behavioral Science', 'active', '11:53:52 AM, 24-Sep-2021');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_id_num` char(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(60) NOT NULL,
  `user_mobile` varchar(15) NOT NULL,
  `user_department` varchar(60) NOT NULL,
  `user_designation` varchar(30) NOT NULL,
  `user_password` varchar(200) NOT NULL,
  `user_type` varchar(15) NOT NULL,
  `user_status` enum('active','inactive') NOT NULL,
  `user_image` varchar(50) DEFAULT NULL,
  `user_reg_date` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_id_num`, `user_name`, `user_email`, `user_mobile`, `user_department`, `user_designation`, `user_password`, `user_type`, `user_status`, `user_image`, `user_reg_date`) VALUES
(1, '239', 'Milton Khan', 'srmiltonkhan@gmail.com', '01621000361', 'Information Technology', 'Web Developer', '$2y$10$mUU1gzEE2VyxiGcmyfJ5hOF8fvoLi.lvjiEnvoGgycDIqORqbMPkS', 'super_admin', 'active', 'milton.jpg', '2021-06-21'),
(2, '212', 'Amina', 'amina248351@gmail.com', '01880505661', 'IT', 'Sub Assistant Engineer', '$2y$10$OUMp12nQKt7Fg113Gi/55u.AlA9774UeBGf1DltWab0qtOd.dBkW6', 'EndUser', 'active', '', '10:00:12 AM, 02-Sep-2021'),
(8, '101', 'Md. Tarequl Islam', 'engi.tareq@yahoo.com', '01716173279', 'IT', 'Deputy Manager of IT', '$2y$10$LU/F85zE9Eiij71aQjlyUuNSY7AveelxJN0vxNbyLeneE2I0BphWe', 'EndUser', 'active', '20210902035412.jpg', '09:54:12 AM, 02-Sep-2021');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authority`
--
ALTER TABLE `authority`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `authority_unique_key` (`id`),
  ADD KEY `authority_user_fk` (`user_id`);

--
-- Indexes for table `awprojectjournal`
--
ALTER TABLE `awprojectjournal`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `awproj_unique_key` (`id`),
  ADD KEY `awproj_user_fk` (`user_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contactID`),
  ADD UNIQUE KEY `contact_unique_key` (`contactID`),
  ADD KEY `contact_user_fk` (`user_id`);

--
-- Indexes for table `contents`
--
ALTER TABLE `contents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `content_unique_key` (`id`),
  ADD KEY `content_user_fk` (`user_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`),
  ADD UNIQUE KEY `course_unique_key` (`course_id`);

--
-- Indexes for table `erecruitement`
--
ALTER TABLE `erecruitement`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `recruitment_unique_key` (`id`),
  ADD KEY `recruitment_user_fk` (`user_id`);

--
-- Indexes for table `facultystaff`
--
ALTER TABLE `facultystaff`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `faculty_unique_key` (`id`,`mobile`,`email`,`mem_id_num`),
  ADD KEY `faculty_user_fk` (`user_id`);

--
-- Indexes for table `file_mgt`
--
ALTER TABLE `file_mgt`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `file_unique_key` (`id`),
  ADD KEY `file_user_fk` (`user_id`),
  ADD KEY `course_file_fk` (`course_id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `gallery_unique_key` (`id`),
  ADD KEY `gallery_user_fk` (`user_id`);

--
-- Indexes for table `governing_body`
--
ALTER TABLE `governing_body`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `governing_body_unique_key` (`id`),
  ADD KEY `governing_body_user_fk` (`user_id`);

--
-- Indexes for table `home`
--
ALTER TABLE `home`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `home_unique_key` (`id`),
  ADD KEY `home_user_fk` (`user_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sub_unique_key` (`id`),
  ADD KEY `sub_user_fk` (`user_id`),
  ADD KEY `sub_course_fk` (`course_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `useremail` (`user_email`),
  ADD UNIQUE KEY `usermobile` (`user_mobile`),
  ADD UNIQUE KEY `unique_key` (`user_id_num`,`user_email`,`user_mobile`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authority`
--
ALTER TABLE `authority`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `awprojectjournal`
--
ALTER TABLE `awprojectjournal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `contactID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contents`
--
ALTER TABLE `contents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `erecruitement`
--
ALTER TABLE `erecruitement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `facultystaff`
--
ALTER TABLE `facultystaff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `file_mgt`
--
ALTER TABLE `file_mgt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `governing_body`
--
ALTER TABLE `governing_body`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `home`
--
ALTER TABLE `home`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `authority`
--
ALTER TABLE `authority`
  ADD CONSTRAINT `authority_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `awprojectjournal`
--
ALTER TABLE `awprojectjournal`
  ADD CONSTRAINT `awproj_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `contact`
--
ALTER TABLE `contact`
  ADD CONSTRAINT `contact_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `contents`
--
ALTER TABLE `contents`
  ADD CONSTRAINT `content_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `erecruitement`
--
ALTER TABLE `erecruitement`
  ADD CONSTRAINT `recruitment_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `facultystaff`
--
ALTER TABLE `facultystaff`
  ADD CONSTRAINT `faculty_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `file_mgt`
--
ALTER TABLE `file_mgt`
  ADD CONSTRAINT `course_file_fk` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `file_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `gallery`
--
ALTER TABLE `gallery`
  ADD CONSTRAINT `gallery_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `governing_body`
--
ALTER TABLE `governing_body`
  ADD CONSTRAINT `governing_body_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `home`
--
ALTER TABLE `home`
  ADD CONSTRAINT `home_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `sub_course_fk` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sub_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
