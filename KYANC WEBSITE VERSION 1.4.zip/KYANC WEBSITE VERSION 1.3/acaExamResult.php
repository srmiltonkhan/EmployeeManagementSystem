<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
      <div class="text-center mt-4">
      <h4>Examination Result</h4>
      <br>
    </div>
<?php
$query = "SELECT * FROM file_mgt INNER JOIN courses ON courses.course_id = file_mgt.course_id WHERE type = 'AcademicResult' AND row_status = 'active' ORDER BY id DESC";    
  $stat = $pdo_conn->prepare($query);
  $stat->execute();
  $rowCount = $stat->rowCount();
  $allfilemgt = '';
  if ($rowCount >0) {
     foreach ($stat->fetchAll() as $row) {   
      $date = $row['published_date'];
      $str_date = strtotime($date);
      $date_format = date('d-M-Y', $str_date);
      $allfilemgt .='<tr>'.    
                  '<td>'.$row['course_name'].'</td>'.
                  '<td>'.$row['batch'].'</td>'.
                  '<td>'.$row['title'].'</td>'.
                  '<td>'.$row['semester'].'</td>'.
                  '<td class="text-center"><a href="admin/Files/WebContentsFiles/'.$row['file'].'" target="_blank" title="click to download"> <i class="fas fa-file-pdf"></i></a></td>'.
                  '<td>'.$date_format.'</td>'
                .'</tr>';
     }  
   }else{
    $temp_error = $error = 'There is no Result published!';;
   }   
  $allfilemgt_rslt =  $allfilemgt;
?>
    <div class="table-responsive">
      <table class="table table-bordered table-sm w-90 mx-auto">
        <thead>
          <th>Course</th>
          <th>Batch</th>
          <th>Exam name</th>
          <th>Semester</th>
          <th>Download File</th>
          <th>Publish Date</th>
        </thead>
        <tbody>
          <?php echo $allfilemgt_rslt; ?>
        </tbody>
      </table>
      <p class="text-center text-danger"><?php  echo $temp_error;?> </p>
    </div>
<?php $webContentsClass->footerSection();?>