<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
<div class="bgTransparent">
  <img src="admin/Files/WebFixedFiles/kyanc_bg.jpg" alt="Transparent Image">
  <div class="transparentTitle">
    <h1>ABOUT KYANC</h1>
  </div>
</div>
    <div class="text-center mt-4">
      <h4>ABOUT US</h4>
       <hr>
    </div>
    <div class="aboutkyanc w-90 mx-auto text-justify">
    	<p>'Nursing' is such novel professions where one can earn enough for one's better living as well as get spiritual satisfaction simultaneously. The scope and opportunity for nursing profession, in home and abroad, is gradually increasing. Besides fulfilling internal need for nurses they also can earn foreign currencies by providing their services abroad and can play an important role in the national economy. But unfortunately government initiatives for nurses are too insufficient to create a good number of quality nurses. This is why Dr. Mir Mohammad Amjad Hussain, one of the closest followers of the great saint "Khwaja Enayetpuri" (R.), took initiatives and has established Khwaja Yunus Ali Nursing College</p>
    	<br>
    	<p>Women are generally neglected, especially in our society, as they are neither well educated nor well established and basically in most of the cases this group is being treated as the inferior one as they are economically vulnerable and does not make any remarkable financial contribution to the family. This is why, the philosophy of the Khwaja Yunus Ali Nursing College is to provide quality nursing education to this women group so that they can become skilled manpower, can earn enough to support their family needs, can change their lifestyle and can live with dignity and honor</p>
    </div>
    <div class="text-center mt-4">
      <h4>ANECDOTES OF KHWAJA ENAYETPURI (R)</h4>
        <hr>
    </div> 
    <div class="w-90 mx-auto ke">
    	<img src="admin/Files/WebFixedFiles/KhwajaEnayetpuri.jpg">
    </div>      
    <div class="text-center mt-4">
      <h4>ACHIEVEMENT OF KYANC</h4>
       <hr>
    </div> 
     <div class="aboutkyanc w-90 mx-auto mb-3">
    	<p><i class="fas fa-check-square"> Successfully three Programs are being run by this college one is Diploma in Nursing Science & Midwifery, B.Sc. in Nursing Basic & B.Sc. in Nursing Post Basic.</i></p>
    	<p><i class="fas fa-check-square"> Rate of Success 99%.</i></p>
    	<p><i class="fas fa-check-square"> Result on B.Sc. in Nursing (Post Basic) on 2017, Five students are take place on merit list.</i></p>
    	<p><i class="fas fa-check-square"> Diploma in Nursing Science & Midwifery BNMC exam Students were taking place in merit list.</i></p>
    	<p><i class="fas fa-check-square"> Students of KYANC continuing their job in reputed organization in home and abroad.</i></p>
    	<p><i class="fas fa-check-square"> Result on B.Sc. in Nursing (Post Basic) on 2016, four students are taking place on merit list.</i></p>
    	<p><i class="fas fa-check-square"> A large amount of students of KYANC get a chance of govt. service.</i></p>
    </div>   
<?php $webContentsClass->footerSection();?>