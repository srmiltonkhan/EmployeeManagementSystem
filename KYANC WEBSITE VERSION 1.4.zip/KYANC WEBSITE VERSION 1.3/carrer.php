<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
    <div class="text-center mt-4">
      <h4 class="text-uppercase">E-Recruitement</h4>
        <hr class="w-75 mx-auto">
    </div>
 <?php
  $query = "SELECT * FROM erecruitement WHERE id_status = 'active' ORDER BY id DESC";    
  $stat = $pdo_conn->prepare($query);
  $stat->execute();
  $rowCount = $stat->rowCount();
  $erecruitement = '';
  $cv= '';
  $alert= '';
  if ($rowCount >0) {
     foreach ($stat->fetchAll() as $row) {  
    $date = $row['deadline'];
    $date_foramt = strtotime($date); 
    $deadline = date('d-M-Y',$date_foramt);
      $erecruitement .='<tr>'.    
                  '<td>'.$row['Job_id'].'</td>'.
                  '<td>'.$row['position'].'</td>'.
           		  '<td>'.$row['title'].'<a href="admin/Files/WebContentsFiles/'.$row['file'].'" target="_blank" title="click to download"> details</a></td>'.
                  '<td>'.$row['num_of_post'].'</td>'.
                  '<td>'.$row['age_cal_on'].'</td>'.
                  '<td>'.$row['academic_requirement'].'</td>'.
                  '<td>'.$deadline.'</td>'
                .'</tr>';
     }  
     $cv = "<h5 class='text-danger'>N.B. : Please, send your cv to kyanc2013@gmail.com</h5>";
   }else{
   	$alert =  "<p class='text-danger text-center'>There is no circular published !</p>";
   }   
  $erecruitement_rslt =  $erecruitement;
?>   
    <div class="table-responsive w-90 mx-auto CareerTable mb-3">
		<table class="table table-sm table-bordered">
			<thead>
				<th width="10%">Job Id</th>
				<th width="15%">Position</th>
				<th width="35%">Title</th>
				<th width="5%">No of Post</th>
				<th width="10%">Age Calculated On</th>
				<th width="15%">Educational Requirement</th>
				<th width="10%">Deadline</th>
			</thead>
			<tbody>
			<?php echo $erecruitement_rslt;
			?>
			</tbody>
		</table>
		<?php echo $cv;?>
	</div>
	<div class="w-90 mx-auto">
			<?php echo $alert;?>
	</div>
<?php $webContentsClass->footerSection();?>