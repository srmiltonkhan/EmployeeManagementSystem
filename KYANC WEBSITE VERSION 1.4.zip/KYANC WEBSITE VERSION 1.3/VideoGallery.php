<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>

    <div class="text-center mt-4">
      <h4 class="text-uppercase">Video Gallery</h4>
        <hr class="w-75 mx-auto">
    </div>
    <div class="row">
          <?php
$query = "SELECT * FROM gallery WHERE type = 'VideoGallery' and id_status = 'active' ORDER BY id";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$videoGallery = '';
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
    $videoGallery .='
      <div class="col-sm-4 videoGallery mb-3">
          <iframe src="'.$row['link'].'" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          
          <div class="text-center"><b>'.$row['title'].'</b></div>
        </div> ';
   }  
 }   
echo $videoGallery;
?>	
    </div>
<?php $webContentsClass->footerSection();?>