<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
      <div class="text-center mt-4">
      <h4 class="text-uppercase">Academic Calendar</h4>
        <hr class="w-75 mx-auto">
    </div>
    <?php
$query = "SELECT * FROM file_mgt INNER JOIN courses ON courses.course_id = file_mgt.course_id WHERE type = 'Calendar' AND row_status = 'active' ORDER BY id DESC";   
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$allfilemgt = '';
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {  
         $date = $row['published_date'];
      $date_format = date('d-M-Y', strtotime($date)); 
    $allfilemgt .='<tr>'.    
                '<td>'.$row['title'].'</td>'.
                '<td class="text-center"><a href="admin/Files/WebContentsFiles/'.$row['file'].'" target="_blank" title="click to download"> <i class="fas fa-file-pdf"></i></a></td>'
                .'<td>'.$date_format.'</td>'
              .'</tr>';
   }  
 }else{
   $temp_error = "No Academic Calendar published!";
 }   
$allfilemgt_rslt =  $allfilemgt;
?>
    <div class="table-responsive">
      <table class="table table-bordered table-sm w-90 mx-auto">
        <div class="text-right countNumber"><b>Total Academic Calendar:</b><?php echo $rowCount; ?></div>
        <thead>
          <th>Title</th>
          <th>Download File</th>
          <th>Publication Date</th>
        </thead>
        <tbody>
          <?php echo $allfilemgt_rslt; ?>
        </tbody>
      </table>
       <p class="text-center text-danger"><?php  echo $temp_error;?> </p>
    </div>
<?php $webContentsClass->footerSection();?>