<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();


?>
 <?php echo $latestnews;?>
  <!-- Banner Section Start   -->
        <?php
        // create function of query from DB
        function make_query($pdo_conn){
        $query = "SELECT * FROM home WHERE type = 'Carousel' and id_status = 'active' ORDER BY serial_number ASC LIMIT 12";
         return $query;
        }
        //Make make_slide_indicators slide Function
        function make_slide_indicators($pdo_conn){
         $output = ''; 
         $count = 0;
         $query =  make_query($pdo_conn);
         $stat = $pdo_conn->prepare($query);
         $stat->execute();
         foreach ($stat->fetchAll() as $row) {
          if($count == 0){
            $output .= '<li data-target="#dynamic_slide_show" data-slide-to="'.$count.'" class="active"></li>';
           }else{
            $output .= '<li data-target="#dynamic_slide_show" data-slide-to="'.$count.'"></li>';
           }
            $count = $count + 1;
         }
           return $output;
        }
        //Make slide Function
        function make_slides($pdo_conn){
         $output = '';
         $count = 0;
         $query =  make_query($pdo_conn);
         $stat = $pdo_conn->prepare($query);
         $stat->execute();
         foreach ($stat->fetchAll() as $row){
            if($count == 0){
              $output .= '<div class="carousel-item active">';
             }else{
              $output .= '<div class="carousel-item">';
             }
              $output .= '<img src="admin/Files/WebContentsFiles/'.$row["file"].'" alt="'.$row["file"].'" style=" width: 100%; max-width: 1920px;height: auto;"><div class="carousel-caption overlay_banner">
               <h4>'.$row["title"].'</h4>
                           </div>
                          </div>';
             $count = $count + 1;
            }
             return $output;
          }
        ?>           
   <div class="row">
     <div class="col">
        <div class="carousel_border container_img">
              <div id="dynamic_slide_show" class="carousel slide carousel-fade" data-ride="carousel">
                <ul class="carousel-indicators">
                  <?php echo make_slide_indicators($pdo_conn);?>
                </ul>
                <div class="carousel-inner">
                  <?php echo make_slides($pdo_conn); ?>
                </div>
                <a class="carousel-control-prev" href="#dynamic_slide_show" data-slide="prev">
                  <span class="carousel-control-prev-icon"></span>
                </a>
                <a class="carousel-control-next" href="#dynamic_slide_show" data-slide="next">
                  <span class="carousel-control-next-icon"></span>
                </a>
            </div>
        </div>              
     </div>
   </div>
 <!-- Banner Section End   -->
 <!-- Welcom Section Start -->
<div class="mt-2 w-75 mx-auto p-2">
    <div class="text-center mt-2">
      <h4>WELCOME TO KHWAJA YUNUS ALI NURSING COLLEGE</h4>
      <hr>
    </div>
    <div class="welcomeContent text-justify  p-3">
      <h5 style="line-height: 1.5;">To fulfill the holy Prophecy of the great saint Hazrat Khwaja Yunus Ali (R) Khwaja Yunu Ali Nursing College at Enayetpur started its journey since 2005. Dr. M.M. Amjad Hussain established Khwaja Yunus Ali Nursing College to create excellent, efficient nurses with dignity because he realized that the nation needed their services. Khwaja Yunus Ali Nursing College is approved by republic of Bangladesh government ministry of health and family welfare under Bangladesh Nursing & Midwifery council and Rajshahi medical University.</h5>
      <h5 style="line-height: 1.5;">Enayetpur is situated in Sirajganj district which is 147 KM. away from Dhaka and 22 KM. from the Jamuna Bridge, the junction of northern and southern part of the country. This college is affiliated with the Medical University of Rajshahi for B.Sc. in Nursing (Post basic), B. Sc in Nursing (Basic) and Diploma in Nursing Science and Midwifery with BNMC (Bangladesh Nursing and Midwifery Council) Dhaka. The course and curriculum are governed by the regulations of Bangladesh Nursing & Midwifery Council (BNMC).</h5>
      <h5 style="line-height: 1.5;">The institute is the center for all professional diploma in nursing, B.Sc. in nursing (Post basic) and B.Sc. in nursing (Basic). All the exams are held under medical university of Rajshahi & BNMC at KYANC. The nursing course is running according to the BNMC approved curriculum. The qualified, experienced faculty members are engaged in conducting the courses. This is the only institution in private sector having echo-friendly academic environment within a vast campus in the country in a completely rural area. The college has 500 bedded teaching hospital with modern healthcare equipment for the students and it has also a cancer institute for clinical practices as well.</h5>
    </div>
</div>

<!-- Welcom Section End -->
<!-- KEY FEATURES START-->
<div class="mt-2 w-75 mx-auto p-2">
    <div class="text-center mt-2">
      <h4>KEY FEATURES</h4>
        <hr>
    </div>
    <div class="feature text-justify mt-5">
      <h5><i class="fas fa-check-square text-success"></i> An international standard nursing education institute.</h5>
      <h5><i class="fas fa-check-square text-success"></i> On campus tertiary level hospital.</h5>
      <h5><i class="fas fa-check-square text-success"></i> Qualified and experienced  as well as dedicated faculty members.</h5>
      <h5><i class="fas fa-check-square text-success"></i> Spacious class rooms equipped with modern technology.</h5>
      <h5><i class="fas fa-check-square text-success"></i> Modern Bio-medical labs with sophisticated instruments.</h5>
      <h5><i class="fas fa-check-square text-success"></i> Latest technology based computer lab and library.</h5>
      <h5><i class="fas fa-check-square text-success"></i> Opportunities of practical training in a reputed and  specialized hospital.</h5>
      <h5><i class="fas fa-check-square text-success"></i> The well-equipped campus building with safe accommodation arrangements for students.</h5>
      <h5><i class="fas fa-check-square text-success"></i> 24 hours electricity  supply and purify water facility.</h5>
      <h5><i class="fas fa-check-square text-success"></i> The campus is on the bank of the river jamuna with eye catching natural beauty.</h5>
      <h5><i class="fas fa-check-square text-success"></i> The cost of education is affordable for all.</h5>
      <h5><i class="fas fa-check-square text-success"></i> Using the latest technology teaching in special way.</h5>
    </div>
</div>
<!-- KEY FEATURES END-->
<!-- International Event Banner -->
   <?php
        //create function
        function make_query_ent_banner($pdo_conn){
        $query_ent_banner = "SELECT * FROM home WHERE type = 'NIE' and id_status = 'active' ORDER BY serial_number DESC LIMIT 10";
         return $query_ent_banner;
        }
        //Make indicators slide Function
        function make_slide_indicators_ent_banner($pdo_conn){
         $output_ent_banner = ''; 
         $count_ent_banner = 0;
         $query_ent_banner =  make_query_ent_banner($pdo_conn);
         $stat_ent_banner = $pdo_conn->prepare($query_ent_banner);
         $stat_ent_banner->execute();
         foreach ($stat_ent_banner->fetchAll() as $row) {
          if($count_ent_banner == 0){
           $output_ent_banner .= '
           <li data-target="#dynamic_slide_show_ent_banner" data-slide-to="'.$count_ent_banner.'" class="active"></li>';
          }else{
           $output_ent_banner .= '<li data-target="#dynamic_slide_show_ent_banner" data-slide-to="'.$count_ent_banner.'"></li>';
          }
          $count_ent_banner = $count_ent_banner + 1;
         }
         return $output_ent_banner;
        }
        //Make slide Function
        function make_slides_ent_banner($pdo_conn){
         $output_ent_banner = '';
         $count_ent_banner = 0;
         $query_ent_banner =  make_query_ent_banner($pdo_conn);
         $stat_ent_banner = $pdo_conn->prepare($query_ent_banner);
         $stat_ent_banner->execute();
         foreach ($stat_ent_banner->fetchAll() as $row) {
            if($count_ent_banner == 0){
              $output_ent_banner .= '<div class="carousel-item active">';
          }else{
              $output_ent_banner .= '<div class="carousel-item">';
          }
             $output_ent_banner .= '<img src="admin/Files/WebContentsFiles/'.$row["file"].'" alt="'.$row["file"].'" style=" width: 100%; max-width: 1920px;height: auto;"><div class="carousel-caption overlay_banner"><h4>'.$row["title"].'</h4>
           </div>
          </div>';
          $count_ent_banner = $count_ent_banner + 1;
         }
          return $output_ent_banner;
        }
      ?>           
   <div class="row mt-4 mx-auto p-2 internationalEvent">
     <div class="col">
       <div class="text-center">
          <h4>PROGRAMS & EVENTS</h4>
           <hr>
       </div>
        <div class="container_img mt-5">
         <div id="dynamic_slide_show_ent_banner" class="carousel slide" data-ride="carousel">
            <ul class="carousel-indicators">
               <?php echo make_slide_indicators_ent_banner($pdo_conn);?>
            </ul>
            <div class="carousel-inner">
                 <?php echo make_slides_ent_banner($pdo_conn);?>
            </div>
            <a class="carousel-control-prev" href="#dynamic_slide_show_ent_banner" data-slide="prev">
              <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" href="#dynamic_slide_show_ent_banner" data-slide="next">
              <span class="carousel-control-next-icon"></span>
            </a>
          </div>
        </div>  
     </div>
   </div>
    <!-- International Event Banner -->
<!-- NOTICE BOARD Start -->
<div class="row mt-5 w-75 mx-auto p-2">
  <div class="col">
    <div class="text-center">
      <h4>NOTICE</h4>
       <hr>
    </div>
<?php
$query = "SELECT * FROM home WHERE type = 'Notice' and id_status = 'active' ORDER BY id DESC LIMIT 8";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$notice = '';
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
    $file = '';
    if ($row['file'] != '') {
      $file = '<a href="admin/Files/WebContentsFiles/'.$row['file'].'" target="_blank" title="click to download"> <i class="fas fa-file-pdf"></i></a>';
    }else{
      $file = '';
    }
    $notice .='<tr>'.
                '<td>'.$row['serial_number'].'</td>'.      
                '<td class="news-item">'.$row['title'].'</td>'.
                '<td>'.$file.'</td>'.
                '<td>'.$row['posting_date'].'</td>'
              .'</tr>';
   }  
 } else{
   $temp_error= $error;
 }  
$notice_board =  $notice;
?>
  <div class='card notice mt-3'>
    <div class='card-header'>
      <div class='text-center'>
        <h5><i class='fas fa-newspaper'></i> NOTICE BOARD</h5>
      </div>
    </div>
    <div class='card-body'>
          <div class='row'>
            <div class='col'>
              <div class="table-responsive">
              <table class="table table-bordered table-sm">
                <thead>
                  <tr>
                    <td width="10%">SL</td>
                    <td width="60%">Title</td>
                    <td width="10%">File</td>
                    <td width="20%">Posted Date</td>
                  </tr>
                </thead>
                <tbody class='notice_board_slider'>              
                      <?php  echo $notice_board;?>                                                                                  
                </tbody>  
                         
               </table>
               <p class="text-center text-danger"><?php  echo $temp_error;?> </p>
              </div>
            </div>
        </div>
    </div>
    <div class='card-footer'>
    </div>
  </div>      
</div>
</div>
<!-- NOTICE BOARD END -->

<!-- EVENT BOARD Start -->
<div class="row mt-5 w-75 mx-auto p-2">
  <div class="col">
    <div class="text-center">
      <h4>EVENT</h4>
       <hr>
    </div>
<?php
$query = "SELECT * FROM home WHERE type = 'Event' and id_status = 'active' ORDER BY id DESC LIMIT 8";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$notice = '';
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
    $file = '';
    if ($row['file'] != '') {
      $file = '<a href="admin/Files/WebContentsFiles/'.$row['file'].'" target="_blank" title="click to download"> <i class="fas fa-file-pdf"></i></a>';
    }else{
      $file = '';
    }
    $notice .='<tr>'.
                '<td>'.$row['serial_number'].'</td>'.      
                '<td class="news-item">'.$row['title'].'</td>'.
                '<td>'.$file.'</td>'.
                '<td>'.$row['posting_date'].'</td>'
              .'</tr>';
   }  
 } else{
   $temp_error= $error;
 }  
$notice_board =  $notice;
?>
  <div class='card notice mt-3'>
    <div class='card-header'>
      <div class='text-center'>
        <h5><i class='fas fa-newspaper'></i> EVENT</h5>
      </div>
    </div>
    <div class='card-body'>
          <div class='row'>
            <div class='col'>
              <div class="table-responsive">
              <table class="table table-bordered table-sm">
                <thead>
                  <tr>
                    <td width="10%">SL</td>
                    <td width="60%">Title</td>
                    <td width="10%">File</td>
                    <td width="20%">Posted Date</td>
                  </tr>
                </thead>
                <tbody class='notice_board_slider'>              
                      <?php  echo $notice_board;?>                                                                                  
                </tbody>  
                         
               </table>
               <p class="text-center text-danger"><?php  echo $temp_error;?> </p>
              </div>
            </div>
        </div>
    </div>
    <div class='card-footer'>
    </div>
  </div>      
</div>
</div>
<!-- EVENT BOARD END -->

<!-- RECENT CONFERENCES & MEETING -->
 <div class="mx-auto" style="width: 90%;">
    <div class="text-center mt-5">
      <h4>CONFERENCES & MEETING</h4>
       <hr>
    </div>
      <div class="logo-slider confCarouselJS mt-3 ">
      <?php
          $query = "SELECT * FROM home WHERE type = 'Conferences' and id_status = 'active' ORDER BY serial_number ASC LIMIT 10"; 
          $stat = $pdo_conn->prepare($query);
          $stat->execute();
          $confrowCount = $stat->rowCount();
          $conferencs = '';
      ?>
      <?php       
          if($confrowCount > 0){
              foreach ($stat->fetchAll() as $row) {
                $conferencs .='
              <div class="item">
                <div class="conference">
                    <div class="confimage">
                        <a href="conference_view.php?id='.$row['id'].'" target="_blank"><img class="confimg" src="admin/Files/WebContentsFiles/'.$row['file'].'" alt="'.$row['title'].'"></a>
                    </div>
                    <div class="confTitleDate">
                      <div class="confTleDt">
                          <div class="conTle">
                              <p><b>'.$row['title'].'</b></p>
                              <p><a href="conference_view.php?id='.$row['id'].'">Click</a></p>
                          </div>
                          <div class="conDate">
                              <p>'.$row['conference_date'].'</p>
                          </div>                  
                      </div>
                     </div> 
                </div>
              </div>
                ';
              }
            }
              else{
                echo "<p class='text-center text-danger'>There is no conferenc & Meeting Record!</p>";
              }
                echo $conferencs;
                ?>
        </div>
 </div>

<!-- RECENT CONFERENCES & MEETING -->  

 
 <!-- Our Courses Start -->
<div class="mt-5 mx-auto p-2 w-90">
    <div class="text-center mt-2">
      <h4>OUR COURSES</h4>
    <hr>
    </div>
    <div class="row mt-3">
      <div class="col">
        <div class="centerCourse">
          <a href="Midwifery.php">
          <div class="square bg-primary">
            <div class="squareBook">
                <div><i class="fas fa-book fa-4x"></i></div>   
            </div>
            <p>Diploma in Nursing Science and Midwifery</p>   
          </div>
          </a>
        </div>        
      </div>
       <div class="col">
        <div class="centerCourse">
          <a href="BscBasic.php">
          <div class="square bg-success">
            <div class="squareBook">
                <div><i class="fas fa-book fa-4x"></i></div>   
            </div>
            <p>B.Sc in Nursing (Basic)</p>   
          </div>
          </a>
        </div>        
      </div>
      <div class="col">
        <div class="centerCourse">
          <a href="BscPostBasic.php">
          <div class="square bg-info">
            <div class="squareBook">
                <div><i class="fas fa-book fa-4x"></i></div>   
            </div>
            <p>B.Sc in Nursing (Post Basic)</p>   
          </div>
          </a>
        </div>        
      </div>
      <div class="col">
        <div class="centerCourse">
          <a href="MscNursing.php">
          <div class="square bg-danger">
            <div class="squareBook">
                <div><i class="fas fa-book fa-4x"></i></div>   
            </div>
            <p>M.Sc in Nursing (Proposed)</p>   
          </div>
          </a>
        </div>        
      </div>                 
    </div>
</div>    
 <!-- Our Courses End-->
<!-- WHY CHOOSE US START -->
<div class="mt-5 w-75 mx-auto p-2" style="width: 90%;">
    <div class="text-center">
      <h4>WHY CHOOSE US</h4>
        <hr>
    </div>
    <div class="whyChooseUs">
   <div class="row mt-5">  
     <?php
          $query = "SELECT * FROM home WHERE type = 'WCU' and id_status = 'active' ORDER BY serial_number ASC LIMIT 8"; 
          $stat = $pdo_conn->prepare($query);
          $stat->execute();
          $rowCountWCU = $stat->rowCount();
          $WCU = '';

          if ($rowCountWCU > 0) {
            foreach ($stat->fetchAll() as $row) {
             $title = $row['title'];
            $WCU .= ' 
            <div class="col-sm-3 academicBuilding">
               <img src="admin/Files/WebContentsFiles/'.$row['file'].'" class="view" data-id='.$row['id'].'>
               <p class="text-center">'.$row['title'].'</p>           
           </div> 

            ';
            }
          }else{
            echo "There is no Record!";
          }
         echo $WCU;
      ?>
       </div>
</div>
</div> 
        <div class="modal fade" id="view_modal">
          <div class="modal-dialog modal-xl modal-dialog-centered">
            <div class="modal-content">
            
              <!-- Modal Header -->
              <div class="modal-header">
                <h4 class="modal-title">Information</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
              
              <!-- Modal body -->
              <div class="modal-body modalImg">
                  <div id="view_data_modal"></div>
              </div>
              
              <!-- Modal footer -->
              <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
              </div>
              
            </div>
          </div>
        </div> 
<script type="text/javascript">
 $(document).ready(function(){
          $('.view').click(function(){
              var id = $(this).data('id');
              $.ajax({
                  url: 'wcuView.php',
                  type: 'post',
                  data: {id: id},
                  success: function(data){ 
                      $('#view_modal').modal('show'); 
                      $('#view_data_modal').html(data);      
                  }
              });
          });
        });
</script>
<!-- WHY CHOOSE US END -->
<div class="mt-5 w-75 mx-auto p-2"">
    <div class="text-center mt-2">
      <h4>LEGAL STATUS</h4>
      <hr>
    </div>

  <div class="legalCarousel mt-5">
    <div class="legalslide-track">
      <div class="legalCarouselSlide">
        <img src="admin/Files/WebContentsFiles/ROB.png"><br>
         <p><a href="https://bangladesh.gov.bd/index.php" target="_blank">Approved by Bangladesh Government</a></p> 
      </div>
      <div class="legalCarouselSlide">
        <img src="admin/Files/WebContentsFiles/RMU.png">
        <p><a href="https://www.rmu.edu.bd/" target="_blank">Affiliated with Rajshahi Medical University,Rajshahi, Bangladesh</a></p>
      </div>
      <div class="legalCarouselSlide">
        <img src="admin/Files/WebContentsFiles/BMC.png">
        <p></p> 
        <p><a href="http://www.bnmc.gov.bd/" target="_blank">Approved by Bangladesh Nursing and Midwifery Council</a></p>
      </div>   
      <div class="legalCarouselSlide">
        <img src="admin/Files/WebContentsFiles/ROB.png"><br>
        <p><a href="https://bangladesh.gov.bd/index.php" target="_blank">Approved by Bangladesh Government</a></p> 
      </div>
      <div class="legalCarouselSlide">
        <img src="admin/Files/WebContentsFiles/RMU.png">
        <p><a href="https://www.rmu.edu.bd/" target="_blank">Affiliated with Rajshahi Medical University,Rajshahi, Bangladesh</a></p>
      </div>
      <div class="legalCarouselSlide">
        <img src="admin/Files/WebContentsFiles/BMC.png">
         <p><a href="http://www.bnmc.gov.bd/" target="_blank">Approved by Bangladesh Nursing and Midwifery Council</a></p>
      </div>         
      </div>      
    </div>
  </div>

  
 </div>   
<!-- Inifinite Brand Concern Carousel -->
<div class="row mt-5 w-75 mx-auto p-2">
  <div class="col">
    <div class="text-center">
      <h4>OUR SISTER CONCERN</h4>
       <hr>
    </div>
<div class="logo-slider sisterconJS mt-3 mb-5">
  <?php
    $query = "SELECT * FROM home WHERE type = 'SC' and id_status = 'active' ORDER BY id ASC LIMIT 20"; 
    $stat = $pdo_conn->prepare($query);
    $stat->execute();
    $rowCount = $stat->rowCount();

    $sisterConcern = '';
      if($rowCount > 0){
        foreach ($stat->fetchAll() as $row) {
          $sisterConcern .= '<div class="item"><a href="'.$row['link'].'" target="_blank"><img class="brandcarousel" src="admin/Files/WebContentsFiles/'.$row['file'].'" alt="'.$row['title'].'"></a></div>';
        }
      }else{
        echo "There is no record!";
      }
        echo $sisterConcern;
      ?>      
  </div>  
 </div>
  </div>
<!-- Inifinite Brand Concern Carousel -->
<?php $webContentsClass->footerSection();?>