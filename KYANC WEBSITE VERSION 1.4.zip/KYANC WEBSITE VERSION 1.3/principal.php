<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
<?php
$query = "SELECT * FROM authority WHERE authority_type = 'Principal' and id_status = 'active' ORDER BY id ASC";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$authority = '';
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
        $name = $row['name'];
        $quotes = $row['quotes'];
        $file = $row['file'];
        $designation = $row['designation'];
        $messeage = $row['messeage'];
   }  
 }   
?>
    <div class="authority">
      <img src="admin\Files\WebContentsFiles\<?php echo $file; ?>" alt="<?php echo $file; ?>">
      <h3 class="text-center mt-4"><?php echo $name;?></h3>
      <p class="text-center">  <?php echo $designation;?></p>
      <h4 class="w-75 text-center mx-auto">Khwaja Yunus Ali Nursing College</h4>
      <div class="text-justify mt-4 mb-4 mx-auto w-75">
          <?php echo $messeage;?>
      </div>
    </div>
<?php $webContentsClass->footerSection();?>