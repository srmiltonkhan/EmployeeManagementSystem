<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
<?php 
if (isset($_GET['id']) && !empty(trim($_GET['id']))) {
  $query = "SELECT * FROM home WHERE id = '".$_GET["id"]."'";
  $statement = $pdo_conn->prepare($query);
  $statement->execute();
  $result = $statement->fetchAll();
  foreach ($result as $row) {
    $title = $row['title']; 
    $file = $row['file']; 
    $details = $row['details']; 
	}
  }
?>
<div>
	<div>
		<img class="rounded mx-auto d-block img-thumbnail w-50" src="admin/Files/WebContentsFiles/<?php echo $file;?>" alt="<?php echo $title; ?>">
	</div>
	<div class="p-3">
		<div class="text-center">
			<h3><?php echo $title; ?></h3>
		</div>
		<div class="text-justify">
			<p><?php echo $details; ?></p>
		</div>
	</div>



<?php $webContentsClass->footerSection();?>