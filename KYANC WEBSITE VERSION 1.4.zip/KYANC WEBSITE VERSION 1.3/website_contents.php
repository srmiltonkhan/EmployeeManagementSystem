<?php 
/**
 * Website Content Class
 */
class webContentsClass {
    public function headerSection(){
        $headerSection ='
        <!DOCTYPE html>
        <html lang="en" dir="ltr">
        <head>
            <meta charset="utf-8">
            <title>Khwaja Yunus Ali Nursing College</title>
            <link rel="shortcut icon" href="admin/Files/favicon/kyanc.ico">
            <meta charset="utf-16">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="admin/vendor/bootstrap/css/bootstrap.min.css">
                  <link rel="stylesheet" type="text/css" href="admin/css/lightbox.min.css">
            <link rel="stylesheet" href="admin/css/custom.css">
            <link href="admin/vendor/fontawesome/css/all.css" rel="stylesheet">
            <link rel="stylesheet" type="text/css" href="admin/css/slick.min.css">
            <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css">    
            <script src="admin/vendor/jquery/jquery.min.js"></script>
            <script type="text/javascript" src="admin/js/lightbox-plus-jquery.min.js"></script>
            <script src="admin/vendor/jquery/newsbox.min.js"></script>
            <script src="admin/vendor/popper.js/popper.min.js"></script>
            <script src="admin/vendor/bootstrap/js/bootstrap.min.js"></script>          
            <script src="admin/js/newsboxslider.js"></script>
            <script src="admin/js/slick.min.js"></script>
            <script src="admin/js/WebsiteCustom.js"></script>
            <script>
              $(".icon").click(function(){
                $("span").toggleClass("cancel");
              });
            </script>  
        </head> 
        ';
             echo $headerSection;
    }
   

public function navigationSection(){
        $navigationSection = '
        <body>
  <!-- Full Body Section Start -->
  <div class="webcontainer">
    <nav class="headerTemplate sticky-top" style="display:flex;">
      <!-- Header Section Start -->
      <div class="lgnamTmplt" style="display: flex;">
        <div class="logo">
           <img src="admin/Files/WebFixedFiles/kyanclogo.png" alt="kyanc logo">
        </div>   
        <div class="webtitle">           
          <h1>Khwaja Yunus Ali Nursing College</h1>
          <h5 class="founder">FOUNDER: DR. MIR MOHAMMAD AMJAD HUSSAIN</h5>
          <h5><a href="contact.php"><i class="fas fa-map-marker"></i> Enayetpur, Chauhali Sirajganj-6751, Bangladesh</a></h5>
        </div>
      </div>
      <div style="flex-grow:1; width: 100%;" class="contMenuSec">
       <div style="float: right;">
         <div class="contact">
             <h5><b>Contact:</b> +8801915477962 &nbsp;<b>E-mail: </b> kyanc2013@gmail.com,info@kyanc.edu.bd &nbsp;<a href="https://www.facebook.com/kyanc0/" target="_blank"><i class="fab fa-facebook-f text-primary"></i></a> &nbsp; <a href="#"><i class="fab fa-twitter text-primary"></i></a> &nbsp;<a href="https://www.youtube.com/watch?v=l2UgsFl4oyw&ab_channel=MILTONKHAN" target="_blank"><i class="fab fa-youtube text-danger">&nbsp;</i> </a>&nbsp;<span><a href="carrer.php">Career</a></span></h5>
         </div>
         <!-- Navigation Section Start Section -->
          <div class="navigation">
            <label for="btn" class="icon">
              <span class="fa fa-bars"></span>
            </label>
            <input type="checkbox" id="btn">
                <ul>
                  <li><a href="index.php">HOME</a></li>
                  <li>
                    <label for="btn-2" class="show">ABOUT US +</label>
                    <a href="#">ABOUT US <i class="fas fa-angle-down"></i></a>
                    <input type="checkbox" id="btn-2">
                    <ul>
                      <li><a href="background.php">Background of KYANC</a></li>
                      <li>
                        <label for="btn-22" class="show">Message +</label>
                        <a href="#">Message <span><i class="fas fa-angle-right"></i></span></a>
                        <input type="checkbox" id="btn-22">
                        <ul>
                          <li><a href="founder.php">Founder</a></li>
                          <li><a href="chairman.php">Chairman</a></li>
                          <li><a href="director.php">Director of Society</a></li>
                          <li><a href="directorSociety.php">Director</a></li>
                          <li><a href="principal.php">Principal</a></li>
                        </ul>
                      </li>
                      <li><a href="vission.php">Vision and Mission</a></li>               
                      <li><a href="AwardAcheivement.php">Awards & Acheivement</a></li>
                    </ul>
                  </li>  
                  <li>
                    <label for="btn-3" class="show">ACADEMIC +</label>
                    <a href="#">ACADEMIC <i class="fas fa-angle-down"></i></a>
                    <input type="checkbox" id="btn-3">
                    <ul>
                      <li><a href="ourcampus.php">Our Campus</a></li>
                      <li>
                        <label for="btn-311" class="show">Courses +</label>
                        <a href="#">Courses <span><i class="fas fa-angle-right"></i></span></a>
                        <input type="checkbox" id="btn-311">
                        <ul>
                          <li><a href="Midwifery.php" style="line-height: 22px; display:table;">Diploma in Nursing<br>Science and Midwifery</a></li>
                          <li><a href="BscBasic.php">B.Sc in Nursing (Basic)</a></li>
                          <li><a href="BscPostBasic.php" style="line-height: 22px;">B.Sc in Nursing (Post Basic)</a></li>
                          <li><a href="MscNursing.php">M.Sc in Nursing(Proposed)</a></li>
                        </ul>
                      </li>
                      <li><a href="faculty.php">Faculty Members</a></li>
                      <li>
                        <label for="btn-321" class="show">College +</label>
                        <a href="#">College Facilities <span><i class="fas fa-angle-right"></i></span></a>
                        <input type="checkbox" id="btn-321">
                        <ul>
                          <li><a href="hostel.php">Hostel</a></li>
                          <li><a href="library.php">Library</a></li>
                          <li><a href="computerlab.php">Computer Lab</a></li>
                          <li><a href="Laboratories.php">Laboratory</a></li>
                          <li><a href="canteen.php">Canteen</a></li>
                          <li><a href="healthcare.php">Health Care</a></li>
                          <li><a href="playground.php">Play Ground</a></li>
                          <li><a href="auditorium.php">Auditorium</a></li>
                        </ul>
                      </li>                       
                      <li><a href="acaClassRoutine.php"> Class Routine</a></li>
                      <li><a href="acaExamRoutine.php"> Exam Routine</a></li>
                      <li><a href="acaExamResult.php"> Result</a></li>
                      <li>
                        <label for="btn-333" class="show">Rules & Regulation +</label>
                        <a href="#">Rules & Regulation <span><i class="fas fa-angle-right"></i></span></a>
                        <input type="checkbox" id="btn-333">
                        <ul>
                        <li><a href="CollegeRules.php">College Rules</a></li>
                          <li><a href="clgdress.php">College Dress Code</a></li>
                          <li><a href="IdentityCard.php">Identity Card</a></li>
                          <li><a href="LibraryRules.php">Rules for Library Use</a></li>
                          <li><a href="HostelRules.php">Rules for Hostel</a></li>
                        </ul>
                      </li>        
                      <li><a href="ProjectResearch.php">Project & Research</a></li>           
                      <li><a href="Journal.php">Journal</a></li>           
                      <li><a href="iqac.php">IQAC</a></li>           
                    </ul>
                  </li>               
                  <li>
                    <label for="btn-4" class="show">ADMINISTRATION +</label>
                    <a href="#">ADMINISTRATION <i class="fas fa-angle-down"></i></a>
                    <input type="checkbox" id="btn-4">
                    <ul>
                      <li><a href="GoverningBody.php">Governing Body</a></li>
                      <li><a href="NoticeEvent.php">Notice/Event</a></li>
                      <li><a href="academicCalender.php">Academic Calendar</a></li>    
                      <li><a href="collegeProspectus.php">College Prospectus</a></li>
                      <li>
                        <label for="btn-411" class="show">Extra-Curriculum+</label>
                        <a href="#">Extra-Curriculum<span><i class="fas fa-angle-right"></i></span></a>
                        <input type="checkbox" id="btn-411">
                        <ul>
                          <li><a href="languageClub.php">Language Club</a></li>
                          <li><a href="CulturalClub.php">Cultural Club</a></li>
                          <li><a href="bloodDonation.php">Blood Donation Club</a></li>
                          <li><a href="sports.php">Sports</a></li>
                          <li><a href="debating.php">Debating</a></li>
                        </ul>
                      </li>              
                      <li>
                        <label for="btn-421" class="show">Gallery +</label>
                        <a href="#">Gallery <span><i class="fas fa-angle-right"></i></span></a>
                        <input type="checkbox" id="btn-421">
                        <ul>
                          <li><a href="photoGallery.php">Photo Gallery</a></li>
                          <li><a href="VideoGallery.php">Video Gallery</a></li>
                          <li><a href="TourGallery.php">Tour Gallery</a></li>
                        </ul>
                      </li>             
                    </ul>
                  </li>
                  <li>
                    <label for="btn-5" class="show">ADMISSION +</label>
                    <a href="#">ADMISSION <i class="fas fa-angle-down"></i></a>
                    <input type="checkbox" id="btn-5">
                    <ul>
                      <li><a href="AdmissionCircular.php">Admission Circular</a></li>
                      <li><a href="admissionininfo.php">Admission info</a></li>
                      <li><a href="CourseInformation.php">Course Info</a></li>
                      <li><a href="faq.php">FAQ</a></li>
                    </ul>
                  </li>        
                  <li><a href="contact.php">CONTACT</a></li>
                </ul>                     
              </div>
             </div>    
            </div>                      
            </nav>
<!-- Content Section Start -->
<div class="content">
  <div class="container-fluid">            
        ';
        echo $navigationSection;
    }
public function footerSection(){
  $footerSection = '
  </div>
</div>
<!-- Body Section End -->
  <!-- Fotter Section Start -->
        <div class="footer">
           <div class="container-fluid">
             <div class="row p-3 footerlink">
                <div class="col-sm-4" >
                  <p>USEFUL LINK</p>
                  <hr>
                  <a href="http://www.bnmc.gov.bd" target="_blank"><i class="fas fa-globe-asia"></i> Bangladesh Nursing and Midwifery Council</a><br>
                  <a href="https://hsd.gov.bd/" target="_blank"><i class="fas fa-globe-asia"></i> Ministry of Health and Family Welfare</a><br>
                  <a href="https://dghs.gov.bd/index.php/en/home" target="_blank"><i class="fas fa-globe-asia"></i> Directorate General of Health Services</a><br>
                 

                  <a href="https://mofa.gov.bd" target="_blank"><i class="fas fa-globe-asia"></i> Ministry of Foreign Affairs</a><br>
                  <a href="https://www.rmu.edu.bd/" target="_blank"><i class="fas fa-globe-asia"></i> Rajshahi Medical University</a><br>
                  <a href="https://www.banglajol.info/index.php/index" target="_blank"><i class="fas fa-globe-asia"></i> Medical Journals of Bangladesh</a><br>
                  <a href="https://bangladesh.gov.bd/index.php" target="_blank"><i class="fas fa-globe-asia"></i> Bangladesh Government</a><br>
                </div>  
                <div class="col-sm-4">
                  <p>SISTER CONCERNS</p>
                  <hr>
                   <a href="https://www.drug-international.com" target="_blank"><i class="fas fa-globe-asia"></i> Drug International Limited</a><br>
                   <a href="https://kyamch.org/newsite" target="_blank"><i class="fas fa-globe-asia"></i> Khwaja Yunus Ali Medical College & Hospital</a><br>
                   <a href="https://kyamc.edu.bd" target="_blank"><i class="fas fa-globe-asia"></i> Khwaja Yunus Ali Medical College</a><br>
                   <a href="https://kyau.edu.bd/kyau/" target="_blank"><i class="fas fa-globe-asia"></i> Khwaja Yunus Ali University</a><br>
                   <a href="http://www.kyalsc.edu.bd/" target="_blank"><i class="fas fa-globe-asia"></i> Khwaja Yunus Ali Laboratory School & College</a><br>
                   <a href="https://www.atilimited.net/" target="_blank"><i class="fas fa-globe-asia"></i> Advance Technology Innovation(ATI) Limited</a><br>
                   <a href="https://aticeramics.com" target="_blank"><i class="fas fa-globe-asia"></i> ATI Ceramics Limited</a><br>
                   <a href="#" target="_blank"><i class="fas fa-globe-asia"></i> M.M. Tea Estates Limited</a><br>
                   <a href="https://harnest.com" target="_blank"><i class="fas fa-globe-asia"></i> Harnest Label Industries</a><br>
                   <a href="#" target="_blank"><i class="fas fa-globe-asia"></i> Taj Filter</a><br>
                </div>  
                <div class="col-sm-4">
                  <p>CONTACT</p>
                  <hr>
                  <div class="address">
                    <p><i class="fas fa-university"></i> Khwaja Yunus Ali Nursing College</p>
                    <p><i class="fas fa-map-marker"></i> Enayetpur, Chauhali Sirajganj-6751, Bangladesh</p>
                    <p><i class="fas fa-mobile-alt"></i> +8801915-477962, +8801915-477930</p>
                    <p><i class="fas fa-mobile-alt"></i> +8801915-477962</p>
                    <p><i class="fas fa-phone"></i> +880 247318041-9</p>
                    <p><i class="fas fa-fax"></i> +880 247318040</p>
                    <p><i class="fas fa-envelope"></i> info@kyanc.edu.bd</p>
                    <p><i class="fas fa-clock"></i> Monday to Saturday</p>
                    <p><a href="https://kyanc.edu.bd:2096/"><i class="fas fa-envelope-open-text"></i> Webmail</a></p>                  
                  </div>
                </div>                                  
            </div>
          
            <div class="row pt-2 pb-2 copyright">
              <div class="col-sm-6">
                <p>COPYRIGHT © 2005-2021 ALL RIGHTS RESERVED BY KYANC</p>
              </div>
              <div class="col-sm-6">
                <p class="text-right">DEVELOPED & MAINTAINED BY KYAU   <a href="https://sites.google.com/view/miltonkhan" target="_blank">IT OFFICE</a></p>
              </div>              
            </div>
           </div>
        </div>
       <!-- Footer Section End  -->
    </div>
  <!-- Full Body Section End -->    
  
 </body>
</html>
';
echo $footerSection;
}

public function facility(){
  $facility = '  <div class="col-sm-3">
    <div class="facilitySideNav mt-5">
      <ul>
        <a href="hostel.php"><li>Hostel</li></a>
        <a href="library.php"><li>Library</li></a>
        <a href="computerlab.php"><li>Computer Lab</li></a>
        <a href="Laboratories.php"><li>Laboratory</li></a>
        <a href="canteen.php"><li>Canteen</li></a>
        <a href="healthcare.php"><li>Health Care</li></a>
        <a href="playground.php"><li>Play Ground</li></a>
        <a href="auditorium.php"><li>Auditorium</li></a>
    </div>
  </div>';
  echo $facility;
}
 
public function courses(){
  $courses = '
    <div class="col-sm-3">
        <div class="facilitySideNav mt-1">
          <ul>
            <a href="Midwifery.php"><li>Diploma in Nursing Science and Midwifery</li></a>
            <a href="BscBasic.php"><li>B.Sc in Nursing (Basic)</li></a>
            <a href="BscPostBasic.php"><li>B.Sc in Nursing (Post Basic)</li></a>
            <a href="MscNursing.php"><li>M.Sc in Nursing (Proposed)</li></a>
        </div>
    </div>
  ';
  echo $courses;
}

}

?>

<?php 
    include('admin/db_config.php');
    $query = "SELECT * FROM home WHERE type = 'LatestNotice' and id_status = 'active' ORDER BY serial_number ASC LIMIT 5"; 
    $stat = $pdo_conn->prepare($query);
    $stat->execute();
    $rowCount = $stat->rowCount();
    $latest_news = ''; 
    if($rowCount > 0){
      foreach ($stat->fetchAll() as $row) {
        $latest_news .= ' '.'<i class="fas fa-bell text-success"></i> ';
        $latest_news .= ' <label>'.$row['title'].'</label>';
        if ($row['file'] != NULL) {
            $latest_news .= '<a href="admin/Files/WebContentsFiles/'.$row['file'].'" target="_blank" title="click to download"> Download</a>'.'.';
        }
        $latest_news .= ' '.'<a href="'.$row['link'].'" target="_blank">'.$row['link'].'</a>';
      }
    }
    // Header Marquee Title
    $latest_news_marquee = $latest_news;
$latestnews = "
   <div class='row'>
     <div class='col-sm-2'>
       <p class='news'>Latest Notice</p>
     </div>
     <div class='col-sm-10'>
        <marquee behavior='scroll' direction='left' onmouseover = 'this.stop();' onmouseout = 'this.start();'>
        <p class='headline'>$latest_news_marquee</p> 
        </marquee>
     </div>             
   </div>
";

?>

 