<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
  <div class="contactContainer w-75 mx-auto">
  	<h4 class="text-center text-uppercase">Location of Khwaja Yunus Ali Nursing College</h4>
    <hr class="mx-auto">
    <div class="LiveMap border">
     <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3638.3879782597123!2d89.70116971473774!3d24.22820548435602!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39fde0a892827625%3A0x3a6cf7bd40b214d!2sKhwaja%20Yunus%20Ali%20Nursing%20College!5e0!3m2!1sen!2sbd!4v1630643566973!5m2!1sen!2sbd" width="800" height="600" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    </div>
  	<div class="LacationInBDMap mt-5">
  		<div class="row">
  			<div class="col-md-6">
        <div class="mx-auto p-4 border text-justify">
        <h5 class="font-weight-bold text-uppercase">KYANC Location in Bangladesh Map</h5>
        <hr>
          <h5 style="line-height: 1.5"><i class="fas fa-check-square text-success"></i> Enayetpur is the holy birth place of the Great Saint of this sub-continent Hazrat Khwaja Yunus Ali (R.)</h5>
          <h5 style="line-height: 1.5"><i class="fas fa-check-square text-success"></i> Enayetpur is one of the most renowned  villages in Bangladesh.</h5>
          <h5 style="line-height: 1.5"><i class="fas fa-check-square text-success"></i> Enayetpur is situated near the Jamuna river.</h5>
          <h5 style="line-height: 1.5"><i class="fas fa-check-square text-success"></i> About 137 kilometers northwest of Dhaka, near the Jamuna bridge linking northern and southern part of the country.</h5>
        </div>
        <div class="mx-auto p-4 border text-justify mt-5">
        <h5 class="font-weight-bold text-uppercase">KYANC ADDRESS</h5>
        <hr>
          <div class="address">
            <p><i class="fas fa-university text-success"></i> Khwaja Yunus Ali Nursing College</p>
            <p><i class="fas fa-map-marker text-success"></i> Enayetpur, Chauhali Sirajganj-6751, Bangladesh</p>
            <p><i class="fas fa-mobile-alt text-success"></i> +8801915-477962, +8801915-477930</p>
            <p><i class="fas fa-mobile-alt text-success"></i> +8801915-477962</p>
            <p><i class="fas fa-phone text-success"></i> +880 247318041-9</p>
            <p><i class="fas fa-fax text-success"></i> +880 247318040</p>
            <p><i class="fas fa-envelope text-success"></i> info@kyanc.edu.bd, kyanc2013@gmail.com</p>              
          </div>        
      </div>
  			</div>
  			<div class="col-md-6 mapImg">
  				<img src="admin/Files/WebFixedFiles/map.jpg">
  			</div>
  		</div>
  	</div>
 <?php
  $query = "SELECT * FROM contact WHERE contactType = 'ContactPage' and ContactStatus = 'active' ORDER BY contactID DESC";    
  $stat = $pdo_conn->prepare($query);
  $stat->execute();
  $rowCount = $stat->rowCount();
  $contact = '';
  if ($rowCount >0) {
     foreach ($stat->fetchAll() as $row) {   
      $contact .='<tr>'.    
                  '<td>'.$row['DepartmentOffice'].'</td>'.
                  '<td>'.$row['Mobile'].'</td>'.
                  '<td>'.$row['WhatsApp'].'</td>'.
                  '<td>'.$row['Phone'].'</td>'.
                  '<td>'.$row['Email'].'</td>'.
                  '<td>'.$row['Fax'].'</td>'
                .'</tr>';
     }  
   }   
  $contact_rslt =  $contact;
?>   
   <div class="contactInfo mt-5 mb-5">
      <h5 class="text-uppercase">Contact Details</h5>
      <div class="table-responsive">
        <table class="table table-bordered table-sm">
          <thead>
            <th>Department/Office</th>
            <th>Mobile</th>
            <th>WhatsApp</th>
            <th>Phone</th>
            <th>E-mail</th>
            <th>Fax</th>
          </thead>
          <tbody>
            <?php echo $contact_rslt;?>
          </tbody>
        </table>
      </div>
   </div>
  </div>
<?php $webContentsClass->footerSection();?>