<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
  <div class="text-center mt-4">
	<h4>PROJECT & RESEARCH</h4>
  <hr class="w-50 mx-auto">
 </div>
 <?php
$query = "SELECT * FROM awprojectjournal WHERE type = 'ProjectResearch' and id_status = 'active' ORDER BY serial_number ASC";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$ProjectResearch = '';

if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
      $file='';
      if ($row['file'] != '') {
      $file = '<a href="admin/Files/WebContentsFiles/'.$row['file'].'" target="_blank" title="click to download"><i class="fas fa-file-pdf"></i></a>';
      }else{
      $file='';
      }

    $ProjectResearch .='<tr>'.     
                '<td>'.$row['title'].'</td>'.
                '<td>'.$row['details'].'</td>'.
                '<td class="text-center">'.$file.'</td>'.
                '<td><a href="'.$row['link'].'" target="_blank">'.$row['link'].'</a></td>'.
                '<td>'.$row['award_date'].'</td>'
              .'</tr>';
   }  
 }else{
  $temp_error = $error;
 }   
$ProjectResearchtRslt =  $ProjectResearch;
?>
 <div class="table-responsive w-75 mx-auto">
 	<table class="table table-bordered table-sm">
 		<thead>
 			<th>Project Title</th>
 			<th>Description</th>
 			<th>Download</th>
 			<th>Published Link</th>
      <th>Publish Date</th>      
 		</thead>
 		<tbody>
 			<?php echo $ProjectResearchtRslt;?>
 		</tbody>
 	</table>
  <?php echo $temp_error;?>
 </div>
<?php $webContentsClass->footerSection();?>





