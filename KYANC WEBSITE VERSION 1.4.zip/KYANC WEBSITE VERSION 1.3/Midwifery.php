<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
	<div class="text-center mt-4">
		<h4>Diploma in Nursing Science and Midwifery</h4>
		<hr class="w-75 mx-auto">
	</div>
	<div class="row">
		<?php $webContentsClass->courses(); ?>
		<div class="col-sm-9">
			<ul class="p-3">
				<li class="p-2">Diploma in Nursing Science and Midwifery students’ under the rules of Bangladesh Nursing and Midwifery Council (BNMC).</li>
				<li class="p-2">The candidates must have passed both SSC & HSC within 2 years from any education board in Bangladesh and from discipline (Science, commerce, Humanistic, Madrasha, Technical etc).</li>
				<li class="p-2">The candidates must have a cumulative GPA (Both SSC & HSC) Total 6.00 but not less than GPA 2.50 in either SSC or HSC Examination.</li>
			</ul>
			<br>
		</div>
	</div>
	<div class="text-center mt-4">
		<h4>Subjects of Diploma Nursing Science & Midwifery</h4>
		<hr class="w-75 mx-auto">
	</div>
  <?php
$query = "SELECT * FROM subjects  WHERE course_id='2' AND year_type = 'FirstYear' and id_status = 'active' ORDER BY serial_number ASC";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$subject = '';
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
    $subject .='<tr>'.     
                '<td>'.$row['serial_number'].'</td>'.
                '<td>'.$row['subject_code'].'</td>'.
                '<td>'.$row['subject_name'].'</td>'
              .'</tr>';
   }  
 }   
$subjectRslt =  $subject;
?>	
	<div class="table-responsive FirstYear w-75 mx-auto">
		<div class="text-center"><h4 class="text-primary">First Year</h4></div>
		<table class="table table-sm table-bordered">
			<thead>
				<th width="10%">SL</th>
				<th width="20%">Subject Code</th>
				<th width="80%">Subject Name</th>
			</thead>
			<tbody>
				<?php echo $subjectRslt;?>
			</tbody>
		</table>
	</div>
<?php
$query = "SELECT * FROM subjects  WHERE course_id='2' AND year_type = 'SecondYear' and id_status = 'active' ORDER BY serial_number ASC";     
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$SecondSubject = '';

if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
    $SecondSubject .='<tr>'.     
                '<td>'.$row['serial_number'].'</td>'.
                '<td>'.$row['subject_code'].'</td>'.
                '<td>'.$row['subject_name'].'</td>'
              .'</tr>';
   }  
 }   
$SecondSubjectRslt =  $SecondSubject;

?>	
	<div class="table-responsive FirstYear w-75 mx-auto">
		<div class="text-center"><h4 class="text-primary">Second Year</h4></div>
		<table class="table table-sm table-bordered">
			<thead>
				<th width="10%">SL</th>
				<th width="20%">Subject Code</th>
				<th width="80%">Subject Name</th>
			</thead>
			<tbody>
				<?php echo $SecondSubjectRslt;?>
			</tbody>
		</table>
	</div>
<?php
$query = "SELECT * FROM subjects  WHERE course_id='2' AND year_type = 'ThirdYear' and id_status = 'active' ORDER BY serial_number ASC";     
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$ThirdSubject = '';

if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
    $ThirdSubject .='<tr>'.     
                '<td>'.$row['serial_number'].'</td>'.
                '<td>'.$row['subject_code'].'</td>'.
                '<td>'.$row['subject_name'].'</td>'
              .'</tr>';
   }  
 }   
$ThirdSubjectRslt =  $ThirdSubject;

?>	
	<div class="table-responsive FirstYear w-75 mx-auto">
		<div class="text-center"><h4 class="text-primary">Third Year</h4></div>
		<table class="table table-sm table-bordered">
			<thead>
				<th width="10%">SL</th>
				<th width="20%">Subject Code</th>
				<th width="80%">Subject Name</th>
			</thead>
			<tbody>
				<?php echo $ThirdSubjectRslt;?>
			</tbody>
		</table>
	</div>

<?php $webContentsClass->footerSection();?>

