<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
    <div class="text-center mt-4">
      <h4 class="text-uppercase">Photo Gallery</h4>
        <hr class="w-75 mx-auto">
    </div>
  
    <div class="gallery row w-90 mx-auto pb-2">
<?php
$query = "SELECT * FROM gallery WHERE type = 'PhotoGallery' and id_status = 'active' ORDER BY id DESC";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$allfilemgt = '';
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
    $allfilemgt .='
        <div class="col-md-4">
          <a href="admin/Files/WebContentsFiles/'.$row['file'].'" data-lightbox="mygallery"><img src="admin/Files/WebContentsFiles/'.$row['file'].'" class="border" alt="'.$row['title'].'"></a>
          <div class="text-center font-weight-bold"><p>'.$row['title'].'</p></div>
          <hr>
        </div>
    ';
   }  
 }   
 echo $allfilemgt;
?>      
</div>
<?php $webContentsClass->footerSection();?>

