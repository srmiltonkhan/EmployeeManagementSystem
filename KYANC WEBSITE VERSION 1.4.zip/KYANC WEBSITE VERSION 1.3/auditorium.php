<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
<div class="row w-90 mx-auto">
<?php $webContentsClass->facility(); ?>
<?php
$query = "SELECT * FROM contents WHERE type = 'Auditorium' and id_status = 'active' ORDER BY id";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row){ 
      $content_title = $row['content_title'];
      $content = $row['content'];
      $file = $row['file'];
     }
}
?>
  <div class="col-sm-9">
	    <div class="faciligyImg mx-auto mt-5">
	    	<img src="admin/Files/WebContentsFiles/<?php echo $file;?>">
	    </div>
<?php echo $content;?>	
  </div>	
</div>
<?php $webContentsClass->footerSection();?>


