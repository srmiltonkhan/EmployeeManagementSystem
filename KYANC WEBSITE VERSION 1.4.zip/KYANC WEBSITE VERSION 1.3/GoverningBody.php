<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
<div class="text-center mt-4">
<h4 class="text-uppercase">Governing Body</h4>
	<hr class="w-50 mx-auto">
</div>
 <?php
$query = "SELECT * FROM governing_body WHERE id_status = 'active' ORDER BY serial_number ASC";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$GoverningBody = '';

if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
    $file= '';
    if ($row['file'] !='') {
      $file= '<img src="admin/Files/WebContentsFiles/'.$row['file'].'"';
    }else{
       $file= '';
    }
    $GoverningBody .='<tr>'. 
                 '<td class="text-center">'.$row['serial_number'].'</td>'.    
                '<td class="GoveningBodyImg">'.$file.'</td>'
                .'<td><b>'.$row['name'].'</b><br>'.$row['institutional_designation'].'<br>'.$row['institution'].'</td>'
                .'<td>'.$row['designation'].'</td>'
              .'</tr>';
   }  
 }   
$GoverningBodyRslt =  $GoverningBody;
?>
<div class="table-responsive w-50 mx-auto governing_table">
	<table class="table table-bordered table-sm">
		<thead>
      <th width="10%">SL</th>
			<th width="20%">Profile Photos</th>
			<th width="40%">Name</th>
			<th width="40%">Designation</th>
		</thead>
		<tbody>
			<?php echo $GoverningBodyRslt;?>
		</tbody>
	</table>
</div>
<?php $webContentsClass->footerSection();?>

