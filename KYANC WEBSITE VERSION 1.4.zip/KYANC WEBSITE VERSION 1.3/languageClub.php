<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
<?php
$query = "SELECT * FROM contents WHERE type = 'LanguageClub' and id_status = 'active' ORDER BY id";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row){ 
      $content_title = $row['content_title'];
      $content = $row['content'];
      $file = $row['file'];
     }
}
?>
<div class="bgTransparent">
  <img src="admin/Files/WebContentsFiles/<?php echo $file;?>" onerror="this.onerror=null; this.src='admin/Files/WebFixedFiles/kyanc_bg.jpg'" alt=''>
  <div class="transparentTitle">
    <h1><?php echo $content_title;?></h1>
  </div>
</div>
<?php echo $content;?>
<?php $webContentsClass->footerSection();?>