<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
      <div class="text-center mt-4">
      <h4 class="text-uppercase">Course Information</h4>
        <hr class="w-75 mx-auto">
    </div>
    <?php
$query = "SELECT * FROM file_mgt INNER JOIN courses ON courses.course_id = file_mgt.course_id WHERE type = 'CourseInformation' AND row_status = 'active' ORDER BY id DESC";  
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$CourseInformation = '';
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
    $CourseInformation .='<tr>'.    
                '<td><a href="'.$row['link'].'" title="Please,see details">'.$row['course_name'].'</a></td>'.
                '<td>'.$row['duration'].'</td>'.
                '<td>'.$row['num_of_seat'].'</td>'.
                '<td>'.$row['session_start'].'</td>'
              .'</tr>';
   }  
 }   
$CourseInformationRslt =  $CourseInformation;
?>
    <div class="table-responsive">
    	<table class="table table-bordered table-sm w-90 mx-auto">
        <div class="text-right countNumber"><b>Total Courses:</b><?php echo $rowCount; ?></div>
    		<thead>
    			<th>Courses</th>
    			<th>Duration</th>
    			<th>Number of Seat</th>
    			<th>Session Start</th>
    		</thead>
    		<tbody>
    			<?php echo $CourseInformationRslt; ?>
    		</tbody>

    	</table>

    </div>
<?php $webContentsClass->footerSection();?>