
<?php
function horizontalline() {
  echo ' 
        <div class="text-center">
                    <div class="horizontalline" style="display: flex;">
                        <div style="width: 100%;">
                             <hr class="hr1">
                        </div>
                        <div>
                           <span class="dot"></span>
                        </div>
                        <div style="flex-grow:1; width: 100%;">
                              <hr class="hr2">
                        </div>
                    </div>
               </div>';
}
  $error ='<p class="text-center text-danger">There is no record!</p>';
  $temp_error = '';
?>
