<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
      <div class="text-center mt-4">
      <h4 class="text-uppercase">Notice & Event</h4>
        <hr class="w-75 mx-auto">
    </div>
    <?php
$query = "SELECT * FROM home WHERE type = 'Notice' and id_status = 'active' ORDER BY serial_number";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$NoticeEvent = '';
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   
    $NoticeEvent .='<tr>'.    
                '<td>'.$row['serial_number'].'</td>'.
                '<td>'.$row['title'].'</td>'.
                '<td class="text-center"><a href="admin/Files/WebContentsFiles/'.$row['file'].'" target="_blank" title="click to download"> <i class="fas fa-file-pdf"></i></a></td>'.
                '<td>'.$row['posting_date'].'</td>'
              .'</tr>';
   }  
 }   
$NoticeEventRslt =  $NoticeEvent;
?>
    <div class="table-responsive">
    	<table class="table table-bordered table-sm w-90 mx-auto">
        <div class="text-right countNumber"><b>Total Class Routine:</b><?php echo $rowCount; ?></div>
    		<thead>
          <th>SL</th>
    			<th>Notice Title</th>
    			<th>Download</th>
    			<th>Publish Date</th>

    		</thead>
    		<tbody>
    			<?php echo $NoticeEventRslt; ?>
    		</tbody>

    	</table>

    </div>
<?php $webContentsClass->footerSection();?>