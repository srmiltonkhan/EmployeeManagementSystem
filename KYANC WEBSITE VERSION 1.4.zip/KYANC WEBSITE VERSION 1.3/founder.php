<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>

<?php
$query = "SELECT * FROM authority WHERE authority_type = 'Founder' and id_status = 'active' ORDER BY id ASC";    
$stat = $pdo_conn->prepare($query);
$stat->execute();
$rowCount = $stat->rowCount();
$authority = '';
if ($rowCount >0) {
   foreach ($stat->fetchAll() as $row) {   

        $name = $row['name'];
        $quotes = $row['quotes'];
        $file = $row['file'];
        $designation = $row['designation'];
        $messeage = $row['messeage'];

   }  
 }   
?>  
    <div class="founderPg">
      <img src="admin\Files\WebContentsFiles\<?php echo $file; ?>" alt="founder">
      <h3 class="text-center mt-4"><?php echo $name;?></h3>
      <p class="text-center"><?php echo $designation;?></p>
      <p class="text-center">(1925-2012)</p>
      <h4 class="w-75 text-center fondquote">"<?php echo $quotes;?>"</h4>
      <div class="text-justify mt-4 mb-4 mx-auto w-75">
      <p><?php echo $messeage;?></p>
      </div>
    </div>

<?php $webContentsClass->footerSection();?>