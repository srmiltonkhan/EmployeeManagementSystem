<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
  <div class="w-90 mx-auto">


    <h3>বিএসসি ইন নার্সিং (বেসিক)” এবং ডিপ্লোমা ইন নার্সিং সায়েন্স এন্ড মিডওয়াইফারি” কোর্সের ভর্তির জন্য প্রয়োজনীয় তথ্য
</h3>
    <hr>
    <p>নার্সিং ও মিডওয়াইফারি অধিদপ্তর, ঢাকা এর আওয়াতাধীন সকল সরকারি ও বেসরকারী নার্সিং কলেজ / ইনস্টিটিউট এ নার্সিং কোর্সে এমবিবিএস/মেডিকেল এর অনুরূপ ভর্তি পরীক্ষা অনুষ্ঠিত হয়ে আসছে।  </p>
    <hr>
 <div class="text-center mb-4"><b>এ জন্য সরকারী ভর্তি বিজ্ঞপ্তি প্রকাশের পর নিয়মনুযায়ী:-</b></div>
 <div class="border p-5 admission_info w-75 mx-auto">
    <h5 class="font-weight-bold text-uppercase">অনলাইনে আবেদন করার নিয়ম</h5>
    <hr>
    <ul style="list-style: none">
        <li><i class="fas fa-check-square text-success"></i> অনলাইনে আবেদন করে ভর্তি পরীক্ষায় অংশগ্রহন করতে হবে এবং অনুষ্ঠিত পরীক্ষায় পাশ নম্বর নূন্যতম 40 থাকতে হবে।</li>
        <li><i class="fas fa-check-square text-success"></i> অনলাইনে ফরম পূরণ ও ভর্তি সংক্রান্ত বিস্তারিত তথ্য ওয়েবসাইট (<a href="http://bnmc.teletalk.com.bd/">bnmc.teletalk.com.bd</a>) হতে জানা যাবে।</li>
        <li><i class="fas fa-check-square text-success"></i> ভর্তি বিজ্ঞপ্তি নার্সিং ও মিডওয়াইফারি অধিদপ্তর এর ওয়েবসাইট (www.dgnm.gov.bd) এবং বাংলাদেশ নার্সিং ও মিডওয়াইফারি কাউন্সিল এর ওয়েভ সাইট (www.bnmc.gov.bd) এ পাওয়া যাবে।</li>
        <li><i class="fas fa-check-square text-success"></i> অন্যথায় কোন নার্সিং প্রতিষ্ঠানে ভর্তি হওয়া যাবে না।</li>
    </ul>
 </div>
     <div class="text-center mt-4 mb-4">
      <h4 class="text-uppercase text-uppercase">Admission Information & Procedure</h4>
    </div>
    
<div class="w-75 mx-auto p-4 border m-4 text-justify">
  <h5 class="font-weight-bold text-uppercase">Admission Criteria</h5>
  <hr>
  <h5 style="line-height: 1.5;">Admission to KYA Nursing College for the three-year Diploma-in Nursing Science & Midwifery Course, and two-year B.Sc-in-Nursing (Post Basic) & four years B. Sc in Nursing (Basic) course degree are open to all individual and meeting the selection criteria laid down in the concerned college prospectus.</h5>
</div>


<div class="w-75 mx-auto p-4 border m-4 text-justify">
  <h5 class="font-weight-bold text-uppercase">Eligibility</h5>
  <hr>
  <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> Eligibility criteria of admission for Bangladeshi students are set by DGNM</h5>
  <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> The candidates must be a permanent citizen of Bangladesh.</h5>
  <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> Candidates must be sound in both physically and mentally.</h5>
</div>

<div>
    <h4 class="text-center text-uppercase">Course wise Eligibility</h4>
</div>

<div class="w-75 mx-auto p-4 border m-4 text-justify">
  <h5 class="font-weight-bold text-uppercase">Diploma in Nursing Science and Midwifery</h5>
  <hr>
   <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> The candidates must have passed both SSC & HSC within 2 years from any education board in Bangladesh and from discipline (Science, commerce, Humanistic, Madrasha, Technical etc).</h5>
   <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> The candidates must have a cumulative GPA (both SSC & HSC) Total 6.00 but not less than GPA 2.50 in either SSC or HSC examination.</h5>
 <h5 class="font-weight-bold text-uppercase mt-5">B.Sc in Nursing (Basic)</h5>
  <hr>
   <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> The candidates must have passed SSC and HSC within 2 years from Science group with Biology.</h5>
   <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> The candidates must have a cumulative GPA (both SSC & HSC) Total 7.00 but not less than GPA 3.00 in either SSC or HSC and both Examination have to have GPA 3.00 in Biology.</h5>


    <h5 class="font-weight-bold text-uppercase mt-5">B. Sc in Nursing (Post Basic)</h5>
  <hr>
     <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> The candidates must have completed diploma in Nursing Science & Midwifery and also must have registration, certificate from the BNMC.</h5>
</div>



 <div class="w-75 mx-auto p-4 border m-4 text-justify">
  <h5 class="font-weight-bold text-uppercase">Admissioon Examination Syllabus</h5>
  <hr>
  <table class="table table-bordered table-sm">
            <thead>
                <th>SL</th>
                <th>Subject</th>
                <th>MCQ</th>
                <th>Mark</th>
            </thead>
            <tbody>
                <tr>
                    <td class="text-center">1</td>
                    <td>Bangla</td>
                    <td>20</td>
                    <td>20</td>
                </tr>
                <tr>
                    <td class="text-center">2</td>
                    <td>English</td>
                    <td>20</td>
                    <td>20</td>
                </tr>
                <tr>
                    <td class="text-center">3</td>
                    <td>General Mathmatics</td>
                    <td>20</td>
                    <td>20</td>
                </tr> 
                <tr>
                    <td class="text-center">4</td>
                    <td>General Khowlege</td>
                    <td>20</td>
                    <td>20</td>
                </tr> 
                <tr>
                    <td class="text-center">5</td>
                    <td>Primary Health care</td>
                    <td>10</td>
                    <td>10</td>
                </tr>  
                <tr>
                    <td class="text-center">6</td>
                    <td>Geography</td>
                    <td>10</td>
                    <td>10</td>
                </tr> 
                <tr>
                    <td class="text-center">7</td>
                    <td>Viva-voce</td>
                    <td>25</td>
                    <td>25</td>
                </tr>
                <tr class="">
                    <td></td>
                    <td><b>Total Mark</b></td>
                    <td></td>
                    <td><b>125</b></td>
                </tr>                                                                                           
            </tbody>
        </table>
</div>





 <div class="w-75 mx-auto p-4 border m-4 text-justify">
  <h5 class="font-weight-bold text-uppercase">Final list of candidates for admission</h5>
  <hr>
  <h5 style="line-height: 1.5;">List of finally selected candidates will be duly notified on the college notice board and our website- www.kyanc.edu.bd. The selected candidates will have to obtain admission by the announced date and time. Otherwise, their selection will be cancelled and the place will be filled up from merit list of the waiting candidate</h5>
</div>


 <div class="w-75 mx-auto p-4 border m-4 text-justify">
  <h5 class="font-weight-bold text-uppercase">Medical Examination for physical fitness</h5>
  <hr>
  <h5 style="line-height: 1.5;">The selected candidates have to appear a medical board for their physical fitness examination. Principal of Khwaja Yunus Ali Nursing College will form the medical examination board.</h5>
</div>

 <div class="w-75 mx-auto p-4 border m-4 text-justify">
  <h5 class="font-weight-bold text-uppercase">Documents to be submitted by the candidates at the time of admission:</h5>
  <hr>
 <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> Photocopy of SSC & HSC examination mark sheets/Academic transcript</h5>
 <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> Photocopy of SSC & HSC/equivalent examination certificate/testimonial</h5>
 <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> 2 copies of recent passport size colour photographs</h5>
 <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> Nationality /Birth certificate from appropriate authority</h5>
 <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> Copy of admission test admit card</h5>
 <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> Copy of admission test result</h5>
 <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> School & College leaving certificate from the head of institution</h5>
</div>

<div class="w-75 mx-auto p-4 border m-4 text-justify">
  <h5 class="font-weight-bold text-uppercase">Quota & Facilities</h5>
  <hr>
  <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> 5% quota for the poor & meritorious students as per the government rules.</h5>
  <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> 2% freedom fighters quota.</h5>
  <h5 style="line-height: 1.5;"><i class="fas fa-check-square text-success"></i> Interest free Loan facilities for poor & meritorious students. (for diploma course)</h5>
</div>

  </div>  
<?php $webContentsClass->footerSection();?>






