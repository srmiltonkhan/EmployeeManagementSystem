<?php 
  include 'website_contents.php';
  $webContentsClass = new webContentsClass();
  include 'function.php';
  $webContentsClass->headerSection();
  $webContentsClass->navigationSection();
  echo $latestnews;?>
  <h1>This course is proposed</h1>
<?php $webContentsClass->footerSection();?>